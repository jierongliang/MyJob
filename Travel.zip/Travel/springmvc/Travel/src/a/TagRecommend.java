package a;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
/**
 * Servlet implementation class TagRecommend
 */
@WebServlet("/TagRecommend")
public class TagRecommend extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TagRecommend() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static Connection connection;
   	static {
   		connection = DatabaseUtil.getDBConnection();
   	}
   	private String selectStr = "select * from scenecenter where sceneid = ?",
   			preStr = "select * from scene100 where sceneid in (";
   	private PreparedStatement select,statement;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = response.getWriter();
		String sceneid = request.getParameter("sceneid");
		try {
			StringBuilder builder = new StringBuilder();
			select = connection.prepareStatement(selectStr);
			select.setString(1, sceneid);
			ResultSet set = select.executeQuery();
			ArrayList<String> result = new ArrayList<>();
			if (set.next()) {
				String tagrecommend = set.getString("tagrecommend");
				JSONArray array = new JSONArray(tagrecommend);
				for (int i = 0; i < array.length(); i++) {
					JSONArray array2 = array.getJSONArray(i);
					double a = array2.getDouble(0);
					String b = array2.getString(1);
					result.add(b);
				}
			}
			for (int i = 0; i < result.size(); i++) {
				builder.append(" ?");
	               if (i != result.size() - 1)
	            	   builder.append(" ,");
			}
			builder.append(" )");
			PreparedStatement statement = connection.prepareStatement(preStr+builder.toString());
			for (int j = 1; j <=result.size(); j++) {
				statement.setString(j, result.get(j-1));
			}
			ResultSet set2 = statement.executeQuery();
			ArrayList<TC> tcs = new ArrayList<>();
			String name,tags,cityname,provincename,address;
			TC tc;
			while (set2.next()) {
				name = set2.getString("name");
				tags = set2.getString("tags");
				cityname = set2.getString("cityname");
				provincename = set2.getString("provincename");
				address = set2.getString("address");
				tc = new TC(name,tags,cityname,provincename,address);
				tcs.add(tc);
			}
//			System.out.println("tc size"+tcs.size());
			JSONArray array = new JSONArray(tcs);
			writer.write(array.toString());
			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

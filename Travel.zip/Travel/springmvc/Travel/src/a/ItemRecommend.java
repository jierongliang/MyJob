package a;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Servlet implementation class ItemRecommend
 */
@WebServlet("/ItemRecommend")
public class ItemRecommend extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ItemRecommend() {
		super();
		// TODO Auto-generated constructor stub
	}
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String selectStr = "select itemrec from user where username = ?",
			selectStr2 = "SELECT *,a.`thumbimg`,a.name,a.`address`,a.`score`,a.`commentNum`,b.`citydis`,b.`provincedis`\r\n" + 
					"FROM scene100 AS a,scenecenter AS b\r\n" + 
					"WHERE a.`sceneid` = b.`sceneid` AND a.`sceneid` IN (";
	private PreparedStatement select;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String username = request.getParameter("username");
		try {
			select = connection.prepareStatement(selectStr);
			select.setString(1, username);
			ResultSet set = select.executeQuery();
			String userrec = "";
			if(set.next()) {
				userrec = set.getString("itemrec");
				ArrayList<String> sceneids = new ArrayList<>();
				HashMap<String, Double> scoremap = new HashMap<>();
				JSONObject object = new JSONObject(userrec);
				for (String string : object.keySet()) {
					scoremap.put(string, object.getDouble(string));
					sceneids.add(string);
				}
//				ArrayList<String> sceneids = new ArrayList<>();
//				String[] aStrings = userrec.split("A");
//				Double s;
//				String id;
//				String[] temp;
//				HashMap<String, Double> scoremap = new HashMap<>();
//				for (int i = 0; i < aStrings.length; i++) {
//					temp = aStrings[i].split("B");
//					id = temp[1];
//					s = Double.parseDouble(temp[0]);
//					sceneids.add(id);
//					scoremap.put(id, s);
//				}
//				for (String string : scoremap.keySet()) {
//					System.out.println(string+" "+scoremap.get(string));
//				}
//				JSONArray array = new JSONArray(userrec);
//				
//				ArrayList<String> sceneids = new ArrayList<>();
//				
//				String temp;
//				for (int i = 0; i < array.length(); i++) {
////					temp = array.getJSONArray(i).getString(1);
//					temp = array.getString(i);
//					System.out.print(temp);
//					String string = temp.split("|")[1];
//					sceneids.add(string);
//					System.out.print(string);
//				}
				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < sceneids.size(); i++) {
					builder.append(" ?");
					if (i != sceneids.size() - 1)
						builder.append(" ,");
				}
				builder.append(" )");
				PreparedStatement statement = connection.prepareStatement(selectStr2+builder.toString());
				for (int j = 1; j <=sceneids.size(); j++) {
					statement.setString(j, sceneids.get(j-1));
				}
				ResultSet set2 = statement.executeQuery();
				String name,address,score,thumbimg,provincename,sceneid;
				int commentNum;
				double citydis,prodis;
				UC uc;
				Scene scene;
				ArrayList<Scene> scenes = new ArrayList<>();
				ArrayList<UC> ucs = new ArrayList<>();
//						s = new ArrayList<>();
				double predictscore;
				while (set2.next()) {
					name = set2.getString("name");
					sceneid = set2.getString("sceneid");

					provincename = set2.getString("provincename");

					thumbimg = set2.getString("thumbimg");
					address = set2.getString("address");
					score = set2.getString("score");
					commentNum = set2.getInt("commentNum");
					citydis = set2.getDouble("citydis");
					prodis = set2.getDouble("provincedis");
					predictscore = scoremap.get(sceneid);
					scene = new Scene(name,address,score,thumbimg,provincename,sceneid,commentNum,citydis,prodis,predictscore);
					scenes.add(scene);
					System.out.print("add pscore"+predictscore);

				}
				Collections.sort(scenes,new PredictScoreComparator());
				JSONArray array2 = new JSONArray(scenes);
				PrintWriter writer = response.getWriter();
				writer.write(array2.toString());
				writer.flush();
				writer.close();
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

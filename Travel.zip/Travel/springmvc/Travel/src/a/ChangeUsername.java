package a;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.print.attribute.standard.RequestingUserName;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




/**
 * Servlet implementation class ChangeUsername
 */
@WebServlet("/ChangeUsername")
public class ChangeUsername extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeUsername() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String selectStr = "select username from user",
			updateStr = "update user set username = ? where username = ?";
	private PreparedStatement select,update;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public static boolean isEmpty(String username1,String username2) {
    	if( (username1!=null) && (username2!=null)) {
    		if((username1.length()>0) && (username2.length()>0))
    			return false;
    	}
    	return true;
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String before = request.getParameter("before");
		String after = request.getParameter("after");
		PrintWriter writer = response.getWriter();
		if(isEmpty( before, after))
			return ;
		try {
			select = connection.prepareStatement(selectStr);
			ResultSet set = select.executeQuery();
			ArrayList<String> exists = new ArrayList<>();
			while (set.next()) {
				exists.add(set.getString("username"));
			}
			if (exists.contains(after)) {
				writer.print("fail");
			}
			else {
				update = connection.prepareStatement(updateStr);
				update.setString(1, after);
				update.setString(2, before);
				int count = update.executeUpdate(),i=0;
				while(count!=1) {
					if (i==10) 
						break;
					count = update.executeUpdate();
					i++;
				}
				if (count==1) {
					writer.print("success");
					rename(before,after);
				} else {
					writer.print("fail");
				}
			}
			

			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	private void rename(String before, String after) {
		// TODO �Զ����ɵķ������
		String path = "D:/Apache/Apache24/htdocs/";
		File f1 = new File(path+before),
				f2 = new File(path+after);
		
		f1.renameTo(f2);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

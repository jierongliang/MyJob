package a;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Servlet implementation class SceneDetail
 */
@WebServlet("/SceneDetail")
public class SceneDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SceneDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String selectStr = "select * from scene100 where sceneid = ?";
	private PreparedStatement select;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String sceneid = request.getParameter("sceneid");
		try {
			select = connection.prepareStatement(selectStr);
			select.setString(1, sceneid);
			ResultSet set = select.executeQuery();
			String name,address,star,time,traffic,price,score,
			officialweb,phone,cityname,provincename,description;
			int commentNum;
			String temp;
			ArrayList<String> imgUrl=new ArrayList<>(),tags=new ArrayList<>(),
					features=new ArrayList<>();
			Scene scene;
			JSONArray array;
			while (set.next()) {
				name = set.getString("name");
				address = set.getString("address");
				star = set.getString("star");
				if ((star==null)||(star.length() ==0)  ) {
					star = "无星级";
				}
				time = set.getString("time");
				if ((time==null) || (time.length()==0)  ) {
					time = "无开放时间";
				}
				traffic = set.getString("traffic");
				if ((traffic==null) || (traffic.length()==0)) {
					traffic = "无交通";
				}
				price = set.getString("price");
				if ((price==null) ||(price.length() ==0)  ) {
					price = "无价格";
				}
				score = set.getString("score");
				officialweb = set.getString("officialweb");
				if ((officialweb==null) ||(officialweb.length() ==0)  ) {
					officialweb = "无官网";
				}
				phone = set.getString("phone");
				if ((phone==null) ||(phone.length() ==0)  ) {
					phone = "无电话";
				}
				cityname = set.getString("cityname");
				provincename = set.getString("provincename");
				description = set.getString("description");
				if ((description==null) ||(description.length() ==0)  ) {
					phone = "无描述";
				}
				commentNum = set.getInt("commentNum");
				temp = set.getString("imgUrl");
				array = new JSONArray(temp);
				for (int i = 0; i < array.length(); i++) {
					String a = array.getString(i);
					imgUrl.add(a);
				}
				temp = set.getString("tags");
				array = new JSONArray(temp);
				for (int i = 0; i < array.length(); i++) {
					String a = array.getString(i);
					tags.add(a);
				}
				
				scene = new Scene(name, address, star, time, traffic,
						price, score, officialweb, phone, cityname, provincename, 
						description, sceneid, commentNum, imgUrl, tags);
				PrintWriter writer = response.getWriter();
				JSONObject object = new JSONObject(scene);
				writer.write(object.toString());
				writer.flush();
				writer.close();
			}
			
			
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

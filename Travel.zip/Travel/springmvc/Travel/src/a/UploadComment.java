package a;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
/**
 * Servlet implementation class UploadComment
 */
@WebServlet("/UploadComment")
public class UploadComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UploadComment() {
		super();
		// TODO Auto-generated constructor stub
	}
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String insertStr = "insert into comment (sceneid,name,time,commenttext,"
			+ "score,imgs) values (?,?,?,?,?,?)",
			selectStr = "select * from comment where sceneid = ? and name = ?";
	private PreparedStatement insert,select;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = response.getWriter();
		String sceneid = request.getParameter("sceneid");
		String name = request.getParameter("name");
		String score = request.getParameter("score");
		String time = request.getParameter("time");
		String commenttext = request.getParameter("commenttext");
		String imgs = request.getParameter("imgs");
		try {
			if (queryExists(sceneid,name)) {
				writer.write("exist");
				writer.flush();
				writer.close();
				return ;
			}
			insert = connection.prepareStatement(insertStr);
			insert.setString(1, sceneid);
			insert.setString(2, name);
			insert.setString(3, time);
			insert.setString(4, commenttext);
			insert.setDouble(5, Double.parseDouble(score));
			insert.setString(6, imgs);
			int count = insert.executeUpdate(),i=0;
			
			while(count!=1) {
				if (i==10) 
					break;
				count = insert.executeUpdate();
				i++;
			}
			if (count==1) {
				writer.print("success");
			} else {
				writer.print("fail");
			}
			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	private boolean queryExists(String sceneid, String name) {
		// TODO �Զ����ɵķ������
		try {
			select = connection.prepareStatement(selectStr);
			select.setString(1, sceneid);
			select.setString(2, name);
			ResultSet set = select.executeQuery();
			int row = 0;
			while (set.next()) {
				row++;
			}
			if (row >0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return false;
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

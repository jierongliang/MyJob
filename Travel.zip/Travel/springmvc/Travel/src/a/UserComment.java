package a;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
/**
 * Servlet implementation class UserComment
 */
@WebServlet("/UserComment")
public class UserComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserComment() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String selectStr = "select * from comment where name =  ?";
	private PreparedStatement select;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String username = request.getParameter("username");
		try {
			select = connection.prepareStatement(selectStr);
			select.setString(1, username);
			ResultSet set = select.executeQuery();
			String sceneid = null,name,time,commenttext;
			double score;
			String imgs;
			Comment comment;
			ArrayList<Comment> comments = new ArrayList<>();
			while (set.next()) {
				sceneid = set.getString("sceneid");
				name = set.getString("name");
				time = set.getString("time");
				commenttext = set.getString("commenttext");
				score = set.getDouble("score");
				imgs = set.getString("imgs");
				comment = new Comment(sceneid,name, time, commenttext, score, imgs);
				comments.add(comment);
			}
			PrintWriter writer = response.getWriter();
			JSONArray array = new JSONArray(comments);
			writer.write(array.toString());
			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

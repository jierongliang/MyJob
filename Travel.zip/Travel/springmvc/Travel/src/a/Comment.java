package a;

import java.util.ArrayList;

public class Comment {
		private String sceneid,name,time,commenttext;
		private double score;
		
		private String imgs;

		

		public Comment(String sceneid, String name, String time, String commenttext, double score, String imgs) {
			super();
			this.sceneid = sceneid;
			this.name = name;
			this.time = time;
			this.commenttext = commenttext;
			this.score = score;
			this.imgs = imgs;
		}

		public Comment(String name, String time, String commenttext, double score, String imgs) {
			super();
			this.name = name;
			this.time = time;
			this.commenttext = commenttext;
			this.score = score;
			this.imgs = imgs;
		}

		public String getImgs() {
			return imgs;
		}

		public void setImgs(String imgs) {
			this.imgs = imgs;
		}

		public Comment() {
			super();
		}

		public String getSceneid() {
			return sceneid;
		}

		public void setSceneid(String sceneid) {
			this.sceneid = sceneid;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getTime() {
			return time;
		}

		public void setTime(String time) {
			this.time = time;
		}

		public String getCommenttext() {
			return commenttext;
		}

		public void setCommenttext(String commenttext) {
			this.commenttext = commenttext;
		}

		public double getScore() {
			return score;
		}

		public void setScore(double score) {
			this.score = score;
		}

		
		
		
}

package dao;

import java.util.List;
import model.Citycenters;
import org.apache.ibatis.annotations.Param;

public interface CitycentersMapper {
    int deleteByPrimaryKey(@Param("name") String name, @Param("provincename") String provincename);

    int insert(Citycenters record);

    Citycenters selectByPrimaryKey(@Param("name") String name, @Param("provincename") String provincename);

    List<Citycenters> selectAll();

    int updateByPrimaryKey(Citycenters record);
    List<Citycenters> select(Citycenters record);
}
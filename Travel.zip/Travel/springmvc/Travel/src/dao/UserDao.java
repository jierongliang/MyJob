package dao;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import model.User;
@Repository("userdao")
public class UserDao implements UserMapper {
	@Resource(name = "sqlSession")
	private SqlSession session;
	@Override
	public int deleteByPrimaryKey(String username) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(User record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public User selectByPrimaryKey(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(User record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Map<String, String> map) {
		// TODO Auto-generated method stub
		return session.update("dao.UserMapper.update",map);
	}
	@Override
	public User login(User user) {
		// TODO Auto-generated method stub
		return session.login("dao.UserMapper.login",user);
	}

}

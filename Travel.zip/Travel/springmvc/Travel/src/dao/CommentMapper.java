package dao;

import java.util.List;
import model.Comment;
import org.apache.ibatis.annotations.Param;

public interface CommentMapper {
    int deleteByPrimaryKey(@Param("sceneid") String sceneid, @Param("name") String name);

    int insert(Comment record);

    Comment selectByPrimaryKey(@Param("sceneid") String sceneid, @Param("name") String name);

    List<Comment> selectAll();
    List<Comment> select(String sceneid);

    int updateByPrimaryKey(Comment record);

	int uploadComment(Comment comment);

	List<Comment> selectUser(String userid);
}
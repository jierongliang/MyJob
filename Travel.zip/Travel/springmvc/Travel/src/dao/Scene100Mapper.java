package dao;

import java.util.List;
import java.util.Map;

import model.Scene100;

import org.apache.ibatis.annotations.Param;

public interface Scene100Mapper {
    int deleteByPrimaryKey(@Param("name") String name, @Param("cityname") String cityname);

    int insert(Scene100 record);

    Scene100 selectByPrimaryKey(@Param("name") String name, @Param("cityname") String cityname);
    Scene100 selectByID(String sceneid);

    List<Scene100> selectAll();
    List<Scene100> selectItem(List<String> ids);
    List<Scene100> query(Map<String, String> param);

    int updateByPrimaryKey(Scene100 record);
}
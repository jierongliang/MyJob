package dao;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import model.Citycenters;
@Repository("citydao")
public class CityCentersDao implements CitycentersMapper{
	@Resource(name = "sqlSession")
	private SqlSession session;
	@Override
	public int deleteByPrimaryKey(String name, String provincename) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(Citycenters record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Citycenters selectByPrimaryKey(String name, String provincename) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Citycenters> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(Citycenters record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Citycenters> select(Citycenters record) {
		// TODO Auto-generated method stub
		return session.selectList("dao.CitycentersMapper.select",record);
	}

}

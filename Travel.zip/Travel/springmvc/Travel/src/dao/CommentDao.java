package dao;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import model.Comment;

@Repository("commentdao")
public class CommentDao implements CommentMapper {
	@Resource(name = "sqlSession")
	private SqlSession session;
	@Override
	public int deleteByPrimaryKey(String sceneid, String name) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(Comment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Comment selectByPrimaryKey(String sceneid, String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comment> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(Comment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Comment> select(String sceneid) {
		// TODO Auto-generated method stub
		return session.selectList("dao.CommentMapper.select",sceneid);
	}
	@Override
	public int uploadComment(Comment comment ) {
		// TODO Auto-generated method stub
		return session.insert("dao.CommentMapper.uploadComment",comment);
	}
	@Override
	public List<Comment> selectUser(String userid) {
		// TODO Auto-generated method stub
		return session.selectList("dao.CommentMapper.selectUser",userid);
	}

}

package f;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class vsv {

	public static void main(String[] args) {
		ArrayList<String> tags = new ArrayList<>();
		// TODO �Զ����ɵķ������
		File file = new File("g:/tagscount.txt");
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			String line;
			StringBuilder builder = new StringBuilder();
			String tag;
			
			PrintWriter writer = new PrintWriter(new File("g:/a.txt"), "UTF-8");
			while ((line = reader.readLine())!=null) {
				tag = line.split(" ")[0];
				builder.append(tag+" ");
				tags.add(line.split(" ")[0]);
//				System.out.println(line.split(" ")[0]);
			}
			System.out.println(builder.toString());
			writer.print(builder.toString());
			writer.flush();
			writer.close();
//			for (String string : tags) {
//				System.out.print(string);
//			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

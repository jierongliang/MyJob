package f;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import org.json.JSONObject;






public class gfgf {

	public static void main(String[] args) {
		File file = new File("g:/latlng.txt");
		// TODO �Զ����ɵķ������
		BufferedReader reader;
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String line = reader.readLine();
			JSONObject object = new JSONObject(line);
			for (String string : object.keySet()) {
				JSONObject object1 = object.getJSONObject(string);
				System.out.println(string);
				for (String string2 : object1.keySet()) {
					System.out.println(string2+" "+object1.getFloat(string2));
				}
			}
		} catch (FileNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

	}

}

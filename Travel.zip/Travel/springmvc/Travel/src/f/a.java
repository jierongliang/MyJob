package f;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import a.DatabaseUtil;
public class a {
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private static String selectStr = "SELECT a.sceneid,a.`latitude`,a.`longitude`,b.`latitude`,b.`longitude`\r\n" + 
			"FROM scenecenter AS a ,provincecenter AS b\r\n" + 
			"WHERE  a.`provincename` = b.`provincename` AND a.`provincedis` IS NULL";
	private static String string = "select * from scenecenter where sceneid = ?",
			string3 = "select * from scene100 where sceneid in (";
	private static String updateStr = "update scenecenter set provincedis = ?  where sceneid = ?";
	private static PreparedStatement select;
	private static PreparedStatement selectPS,selectname;
	private static PreparedStatement update;
	public static void updateData(String sceneid,double citydis) {
		try {
			update.setString(2, sceneid);
			update.setDouble(1, citydis);
			int count = update.executeUpdate();
			int i =0;
			while(count!=1) {
				if (i==10) 
					break;
				count = update.executeUpdate();
				i++;
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		try {
			StringBuilder builder = new StringBuilder();
			selectPS = connection.prepareStatement(string);
			String sceneid = "10003";
			selectPS.setString(1, sceneid);
			ResultSet set = selectPS.executeQuery();
			ArrayList<String> result = new ArrayList<>();
			if (set.next()) {
				String tagrecommend = set.getString("tagrecommend");
				JSONArray array = new JSONArray(tagrecommend);
				for (int i = 0; i < array.length(); i++) {
					JSONArray array2 = array.getJSONArray(i);
					double a = array2.getDouble(0);
					String b = array2.getString(1);
					result.add(b);
					System.out.println(a+" "+b);
				}
			}
			for (int i = 0; i < result.size(); i++) {
				builder.append( " ?");
	               if (i != result.size() - 1)
	            	   builder.append( ",");
			}
			builder.append(" )");
			System.out.println(string3+builder.toString());
			PreparedStatement statement = connection.prepareStatement(string3+builder.toString());
			for (int j = 1; j <=result.size(); j++) {
				statement.setString(j, result.get(j-1));
				
			}
			ResultSet set2 = statement.executeQuery();
			ArrayList<String> names = new ArrayList<>();
			while (set2.next()) {
				names.add(set2.getString("name"));
			}
			for (String string : names) {
				System.out.println(string);
			}
			
			
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
//		try {
//			select = connection.prepareStatement(selectStr);
//			update = connection.prepareStatement(updateStr);
//			ResultSet set = select.executeQuery();
//			String sceneid;
//			double la1,la2,lo1,lo2;
//			double distance;
//			while (set.next()) {
//				sceneid = set.getString(1);
//				la1 = Double.parseDouble(set.getString(2));
//				lo1 = Double.parseDouble(set.getString(3));
//				la2 = Double.parseDouble(set.getString(4));
//				lo2 = Double.parseDouble(set.getString(5));
//				distance = calculateLineDistance(lo1, la1, lo2, la2);
//				updateData(sceneid, distance);
//			}
//		} catch (SQLException e) {
//			// TODO �Զ����ɵ� catch ��
//			e.printStackTrace();
//		}
	}
	public static double calculateLineDistance(double longitude1, double latitude1,
			double longitude2, double latitude2) {
            try {
                double var2 = longitude1;
                double var4 = latitude1;
                double var6 = longitude2;
                double var8 = latitude2;
                var2 *= 0.01745329251994329D;
                var4 *= 0.01745329251994329D;
                var6 *= 0.01745329251994329D;
                var8 *= 0.01745329251994329D;
                double var10 = Math.sin(var2);
                double var12 = Math.sin(var4);
                double var14 = Math.cos(var2);
                double var16 = Math.cos(var4);
                double var18 = Math.sin(var6);
                double var20 = Math.sin(var8);
                double var22 = Math.cos(var6);
                double var24 = Math.cos(var8);
                double[] var28 = new double[3];
                double[] var29 = new double[3];
                var28[0] = var16 * var14;
                var28[1] = var16 * var10;
                var28[2] = var12;
                var29[0] = var24 * var22;
                var29[1] = var24 * var18;
                var29[2] = var20;
                return (Math.asin(Math.sqrt((var28[0] - var29[0]) * (var28[0] - var29[0]) + (var28[1] - var29[1]) * (var28[1] - var29[1]) + (var28[2] - var29[2]) * (var28[2] - var29[2])) / 2.0D) * 1.27420015798544E7D);
            } catch (Throwable var26) {
                var26.printStackTrace();
                return 0.0F;
            }
    }
}

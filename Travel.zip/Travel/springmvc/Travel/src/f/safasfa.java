package f;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import a.DatabaseUtil;

public class safasfa {
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private  static String selectStr = "SELECT * FROM scenecenter,scene100\r\n" + 
			"WHERE scenecenter.`sceneid`=scene100.`sceneid` AND scene100.`provincename`='�㶫'";
	private static String selectStr2 = "SELECT * FROM scenecenter,scene100\r\n" + 
			"WHERE scenecenter.`sceneid`=scene100.`sceneid` "
			+ "AND scene100.`provincename`=?   \r\n" + 
			"AND scene100.`cityname` = ? ";
	private static String selectStr1 = "SELECT a.`sceneid`,a.`name`,a.`thumbimg`,a.`tags`,"
			+ "a.`commentNum`,a.`score`,a.`star`" + 
			",b.`provincedis`,b.`citydis`,b.`latitude`,b.`longitude` "
			+ "FROM scene100 AS a,scenecenter AS b" + 
			"WHERE a.`sceneid` = b.`sceneid` AND a.`cityname` = ? "
			+ "AND a.`provincename` = ?  AND a.`tags` IS NOT NULL ";
	private static PreparedStatement select;
	public static void main(String[] args) {
		try {
			select = connection.prepareStatement(selectStr);
			
			ResultSet set = select.executeQuery();
			while(set.next()) {
				double latitude = set.getDouble("latitude");
				double longitude = set.getDouble("longitude");
				System.out.println(""+latitude+longitude);
			}
		}catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}

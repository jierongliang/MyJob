package controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import dao.CommentDao;
import dao.UserDao;
import model.Comment;

@RestController
public class CommentController {
	@Resource(name="commentdao")
	private CommentDao commentDao;
	@GetMapping("/template1")
	public String function1() {
		return "";
	}
	@GetMapping("/SceneComment")
	public List<Comment> sceneComment(String sceneid) {
		return commentDao.select(sceneid);
	}
	@GetMapping("/UploadComment")
	public String  uploadComment(Comment comment) {
		int i =  commentDao.uploadComment(comment);
		if (i==1) {
			return "success";
		}
		return "fail";
	}
	
	@GetMapping("/UserComment")
	public List<Comment> userComment(String username) {
		return commentDao.selectUser(username);
	}
}

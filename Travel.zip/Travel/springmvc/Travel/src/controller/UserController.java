package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.python.core.PyFunction;
import org.python.core.PyString;
import org.python.util.PythonInterpreter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;

import dao.SceneDao;
import dao.UserDao;
import model.Scene100;
import model.User;

@RestController
public class UserController {
	@Resource(name="userdao")
	private UserDao userdao;
	@Resource(name="scenedao")
	private SceneDao scenedao;
	@GetMapping("/template1")
	public String function1() {
		return "";
	}
	@GetMapping("/updateUserRecommend")
	public String updateUserRecommend(String username) {
		updateRecommend(username, "1");
		return "success";
	}
	@GetMapping("/updateItemRecommend")
	public String updateItemRecommend(String username) {
		updateRecommend(username, "2");
		return "success";
	}
	@GetMapping("/updateSlopeoneRecommend")
	public String updateSlopeoneRecommend(String username) {
		updateRecommend(username, "3");
		return "success";
	}
	public String updateRecommend(String username,String type) {
		PythonInterpreter interpreter = new PythonInterpreter();
		interpreter.execfile("E:/PythonWorkSpace/djangotest/mysite/travel/recommend.py");
		PyFunction pyFunction ;
		if (type.equals("1") ) {
			pyFunction =  interpreter.get("updateDetailUserRecommend", PyFunction.class);
			pyFunction.__call__(new PyString(username));
		}
		else if (type.equals("2") ) {
			pyFunction =  interpreter.get("updateDetailItemRecommend", PyFunction.class);
			pyFunction.__call__(new PyString(username));
		}
		else if (type.equals("3") ) {
			pyFunction =  interpreter.get("updateSlopeoneRecommend", PyFunction.class);
			pyFunction.__call__(new PyString(username));
		}
		return "";
	}
	@GetMapping("/ChangeUsername")
	public String changeUsername(String before,String after) {
		User user = userdao.selectByPrimaryKey(before);
		if (user!=null) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("before", before);
			map.put("after", after);
			int count = userdao.update(map);
			if (count == 1) {
				return "success";
			}
		}
		return "fail";
	}
	
	@GetMapping("/UserRecommend")
	public List<Scene100> userRecommend(String username) {
		User user = userdao.selectByPrimaryKey(username);
		String item = user.getItemrec();
		List<String> items = JSON.parseArray(item, String.class);
		List<Scene100> scene100s = scenedao.selectItem(items);
		return scene100s;
	}
	@GetMapping("/ItemRecommend")
	public List<Scene100> itemRecommend(String username) {
		User user = userdao.selectByPrimaryKey(username);
		String item = user.getItemrec();
		List<String> items = JSON.parseArray(item, String.class);
		List<Scene100> scene100s = scenedao.selectItem(items);
		return scene100s;
	}
	@GetMapping("/Slopeone")
	public List<Scene100> slopeone(String username) {
		User user = userdao.selectByPrimaryKey(username);
		String item = user.getItemrec();
		List<String> items = JSON.parseArray(item, String.class);
		List<Scene100> scene100s = scenedao.selectItem(items);
		return scene100s;
	}
	
	@GetMapping("/TagRecommend")
	public List<Scene100> tagRecommend(String sceneid) {
		User user = userdao.selectByPrimaryKey(sceneid);
		String item = user.getItemrec();
		List<String> items = JSON.parseArray(item, String.class);
		List<Scene100> scene100s = scenedao.selectItem(items);
		return scene100s;
	}
	@GetMapping("/login")
	public String login(String username,String password) {
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		User tempUser = userdao.login(user);
		if (tempUser!=null) {
			return "success";
		}
		return "fail";
	}
	@GetMapping("/Register")
	public String register(String username,String password) {
		User user = userdao.selectByPrimaryKey(username);
		if (user!=null) {
			User user2 = new User();
			user2.setUsername(username);
			user2.setPassword(password);
			int count = userdao.insert(user);
			if (count == 1) {
				return "success";
			}
			return "fail";
		}
		return "fail";
		
	}
	public void uploadSingleImage(HttpServletRequest request, HttpServletResponse response) {
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletContext servletContext = request.getServletContext();
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> items;
		String username="";
		String type = "";
		PrintWriter writer=null;
		try {
			writer = response.getWriter();
			items = upload.parseRequest(request);
			for (FileItem item : items) {
				if (item.isFormField()) {
					String temp = item.getFieldName();
					if (temp.equals("type")) {
						type = item.getString();
					}
					else {
						 username = item.getString();
					}
			       
			      
			    } else {
			    	String path = "D:/Apache/Apache24/htdocs";
					//name = ��Ƭ��
					String name = item.getName();
					//fieldname = filename
					String fieldName = item.getFieldName();
					System.out.println(2+name+fieldName);
					File file = new File(path+"/"+username+"/"+name);
					if(!file.exists()) {
						item.write(file);
						
					}
					String temp = "";
					if (name.endsWith(".jpg")) {
						temp = ".jpg";
					}
					else if (name.endsWith("jpeg")) {
						temp = ".jpeg";
					}
					else if (name.endsWith("png")) {
						temp = ".png";
					}
					else if (name.endsWith("gif")) {
						temp = ".gif";
					}
					String aString = "";
					if (type.equals("icon")) {
						aString = "usericon";
					}
					else if (type.equals("background")) {
						aString = "background";
					}
					File file2 = new File(path+"/"+username+"/"+aString+".jpg");
					if (!file2.exists()) {
						file2.createNewFile();
					}
					FileInputStream inputStream = new FileInputStream(file);
					FileOutputStream outputStream = new FileOutputStream(file2, false);
					int a;
					while((a = inputStream.read()) != -1) {
						outputStream.write(a);
					}
					writer.print("success");
					writer.flush();
					outputStream.close();
					inputStream.close();
					
			    }
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
			writer.print("fail");
			writer.flush();
			
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			writer.print("fail");
			writer.flush();
		}finally {
			
			writer.close();
			
		}
		
	}


}

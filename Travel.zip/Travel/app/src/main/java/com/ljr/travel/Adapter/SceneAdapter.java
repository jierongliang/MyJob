package com.ljr.travel.Adapter;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.amap.api.maps.model.LatLng;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.Activity.SceneDetailActivity;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;
import java.util.List;
public class SceneAdapter  extends RecyclerView.Adapter<SceneAdapter.ViewHolder>{
    private List<Scene> sceneList;
    private AppCompatActivity activity;
    private boolean flag;
    private double latitude,longitude;
    private LatLng latLng;
    public SceneAdapter(List<Scene> sceneList, AppCompatActivity activity) {
        this.sceneList = sceneList;
        this.activity = activity;
    }
    public SceneAdapter(List<Scene> sceneList, AppCompatActivity activity, boolean flag, LatLng latLng) {
        this.sceneList = sceneList;
        this.activity = activity;
        this.flag = flag;
        this.latLng = latLng;
    }
    public double getLatitude() {
        return latitude;
    }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    public LatLng getLatLng() {
        return latLng;
    }
    public void setLatLng(LatLng latLng) {
        this.latLng = latLng;
    }
    public boolean isFlag() {
        return flag;
    }
    public void setFlag(boolean flag) {
        this.flag = flag;
    }
    public List<Scene> getSceneList() {
        return sceneList;
    }
    public void setSceneList(List<Scene> sceneList) {
        this.sceneList = sceneList;
    }
    public AppCompatActivity getActivity() {
        return activity;
    }
    public void setActivity(AppCompatActivity activity) {
        this.activity = activity;
    }
    static class ViewHolder extends RecyclerView.ViewHolder{
        private RImageView sceneimg;
        private RTextView scenename,scenestar,scenescore,scenecommentNum,
                sceneDistanceDistrict,sceneDistanceProvince,sceneDistanceCustom;
        private LinearLayout layoutdefault,layoutcustom;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            sceneimg = (RImageView) itemView.findViewById(R.id.scene_thumbimg);
            scenename = (RTextView) itemView.findViewById(R.id.scene_name);
            scenestar = (RTextView) itemView.findViewById(R.id.scene_star);
            scenescore = (RTextView) itemView.findViewById(R.id.scene_score);
            scenecommentNum = (RTextView) itemView.findViewById(R.id.scene_commentNum);
            sceneDistanceDistrict = (RTextView) itemView.findViewById(R.id.scene_distance_district);
            sceneDistanceProvince = (RTextView) itemView.findViewById(R.id.scene_distance_province);
            layoutdefault = (LinearLayout) itemView.findViewById(R.id.scene_defaultlayout);
            layoutcustom = (LinearLayout) itemView.findViewById(R.id.scene_customlayout);
            sceneDistanceCustom = (RTextView) itemView.findViewById(R.id.scene_distance_custom);
        }
    }
    @NonNull
    @Override
    public SceneAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.scene_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                Scene scene = sceneList.get(position);
                String sceneid = scene.getSceneid();
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(activity, SceneDetailActivity.class);
                        intent.putExtra("sceneid",sceneid);
                        activity.startActivity(intent);
                    }
                });
//                Toast.makeText(v.getContext(), "click"+scene, Toast.LENGTH_SHORT).show();
            }
        };
        holder.scenecommentNum.setOnClickListener(listener);
        holder.sceneDistanceDistrict.setOnClickListener(listener);
        holder.sceneDistanceProvince.setOnClickListener(listener);
        holder.sceneimg.setOnClickListener(listener);
        holder.scenename.setOnClickListener(listener);
        holder.scenestar.setOnClickListener(listener);
        holder.scenescore.setOnClickListener(listener);
        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull SceneAdapter.ViewHolder holder, int position) {
        Scene scene = sceneList.get(position);
        Glide.with(activity)
                .load(scene.getThumbimg())
                .override(115, 150)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(holder.sceneimg);
        holder.scenename.setText(scene.getName());
        String star = scene.getStar();
        if(star.length()>0){
            holder.scenestar.setVisibility(View.VISIBLE);
            holder.scenestar.setText(star+"A");
        }
        holder.scenescore.setText(scene.getScore()+"分");
        holder.scenecommentNum.setText(scene.getCommentNum()+"条评论");
        if (!flag) {
            holder.layoutdefault.setVisibility(View.VISIBLE);
            holder.layoutcustom.setVisibility(View.GONE);
            holder.sceneDistanceDistrict.setText("距离市中心"+BaseUtil.formadDistance(scene.getDistanceDis()));
            holder.sceneDistanceProvince.setText("距离省中心"+BaseUtil.formadDistance(scene.getDistancePro()));
        }
        else{
            holder.layoutcustom.setVisibility(View.VISIBLE);
            holder.layoutdefault.setVisibility(View.GONE);
            LatLng scenelatlng = new LatLng(scene.getLatitude(),scene.getLongitude());
            holder.sceneDistanceCustom.setText("距离自定义位置"+BaseUtil.formadDistance(BaseUtil.calculateDistance(scenelatlng,latLng)));
        }
    }
    @Override
    public int getItemCount() {
        return sceneList.size();
    }
}

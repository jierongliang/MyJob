package com.ljr.travel.Activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.kongzue.dialog.v3.MessageDialog;
import com.kongzue.dialog.v3.TipDialog;
import com.ljr.travel.MainActivity;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpCallbackListener;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.RImageView;
import com.unstoppable.submitbuttonview.SubmitButton;

import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends AppCompatActivity {
    @BindView(R.id.back)
    RImageView back;
    @BindView(R.id.iv_tip)
    TextView ivTip;
    @BindView(R.id.iv_userNameIcon1)
    ImageView ivUserNameIcon1;
    @BindView(R.id.register_username)
    EditText registerUsername;
    @BindView(R.id.iv_passwordIcon1)
    ImageView ivPasswordIcon1;
    @BindView(R.id.register_pwd1)
    EditText registerPwd1;
    @BindView(R.id.iv_passwordIcon2)
    ImageView ivPasswordIcon2;
    @BindView(R.id.register_pwd2)
    EditText registerPwd2;
    //    @BindView(R.id.register_btn)
//    Button registerBtn;
    private static final String TAG = "RegisterActivity";
    @BindView(R.id.register_btn2)
    SubmitButton registerBtn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.back)
    public void onBackClicked() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public String validateForm(String username, String password, String passwordVa) {
        if ((!TextUtils.isEmpty(username)) && (!TextUtils.isEmpty(password)) && (!TextUtils.isEmpty(passwordVa))) {
            if (password.equals(passwordVa))
                return "正确";
            return "两次密码填写不同,请认真填写";
        }
        return "请完整填写表单";
    }

    @OnClick(R.id.register_btn2)
    public void onRegisterBtn2Clicked() {
        String username = registerUsername.getText().toString(),
                password = registerPwd1.getText().toString(),
                passwordVa = registerPwd2.getText().toString();
        final String str = validateForm(username, password, passwordVa);
        if (!str.equals("正确")) {
            registerBtn2.doResult(false);
            BaseUtil.showCustomTipDialog(RegisterActivity.this, str, TipDialog.TYPE.WARNING);
            BaseUtil.resetBtn(RegisterActivity.this, registerBtn2, 2000);
            return;
        }
        HttpUtil.register(App.registeradd, new HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                String result = response;
                switch (result) {
                    case "success":
                        Log.d(TAG, "onResponse: " + "success");
                        BaseUtil.setBtnState(RegisterActivity.this, registerBtn2, true);
                        BaseUtil.showCustomMessageDialog(RegisterActivity.this, "提示", "注册成功");
                        BaseUtil.resetBtn(RegisterActivity.this, registerBtn2, 2000);
                        break;
                    case "fail":
                    case "exist":
                        Log.d(TAG, "onResponse: " + result);
                        BaseUtil.setBtnState(RegisterActivity.this, registerBtn2, false);
                        BaseUtil.showCustomMessageDialog(RegisterActivity.this, "提示", "注册失败");
                        BaseUtil.resetBtn(RegisterActivity.this, registerBtn2, 2000);
                        break;
                    default:
                        ;
                }
            }

            @Override
            public void onError(Exception e) {
                Log.d(TAG, "onError: " + e.getMessage());
                BaseUtil.setBtnState(RegisterActivity.this, registerBtn2, false);
                BaseUtil.showCustomMessageDialog(RegisterActivity.this, "提示", "注册失败");
                BaseUtil.resetBtn(RegisterActivity.this, registerBtn2, 2000);
            }
        }, username, password);
    }
}

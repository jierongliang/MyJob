package com.ljr.travel.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.jaredrummler.materialspinner.MaterialSpinner;
import com.ljr.travel.R;
import com.ljr.travel.Util.HttpUtil;
import com.suke.widget.SwitchButton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import lib.kingja.switchbutton.SwitchMultiButton;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class LocateActivity extends AppCompatActivity {
    @BindView(R.id.province_spinner)
    MaterialSpinner provinceSpinner;
    @BindView(R.id.district_spinner)
    MaterialSpinner districtSpinner;
    private static final String TAG = "LocateActivity";
    @BindView(R.id.maintag_spinner)
    MaterialSpinner maintagSpinner;
    @BindView(R.id.subtag_spinner)
    MaterialSpinner subtagSpinner;
    //    @BindView(R.id.switch_button)
//    SwitchButton switchButton;
    private ArrayList<String> subtags = new ArrayList<>();
    private ArrayList<String> districts = new ArrayList<>();
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String[] provinces = new String[]{"浙江", "广东", "江苏", "上海", "山东", "北京", "四川", "福建", "云南",
            "河南", "辽宁", "安徽", "湖北", "河北", "广西", "台湾", "湖南", "陕西", "江西", "重庆",
            "海南", "香港", "贵州", "山西", "内蒙古", "黑龙江", "天津", "甘肃", "新疆", "澳门", "吉林", "西藏", "青海", "宁夏"};
    private String[] maintags = new String[]{"全部", "自然风光&自然景观", "建筑人文&历史建筑",
            "城市观光", "场馆院所&展馆展览", "演出演艺", "主题乐园&动植物园", "特色"};
    private String[] s1 = new String[]{"全部", "山岳/山岭", "森林", "温泉", "湖泊", "山川", "瀑布", "峡谷", "园林"
            , "洞穴", "草原", "海滨", "江河", "海岛", "礁石/岩石", "泉", "池塘", "雪山",
            "喷泉", "火山", "冰川", "石窟", "沙漠", "热带雨林", "海峡/峡湾", "冰川遗迹"},
            s2 = new String[]{"全部", "名胜古迹", "古迹", "寺庙", "古建筑", "名人故居", "民俗村", "古城", "遗址"
                    , "学府", "古镇", "道观/道场", "古塔", "宫殿", "陵墓", "祠堂", "教堂", "小镇",
                    "古城墙", "古楼", "军事遗址", "石碑", "古道", "纪念碑", "古都", "军事基地"},
            s3 = new String[]{"全部", "特色街区", "广场", "游轮游船", "高空景观", "美食街", "购物街", "观景台", "影视基地"
                    , "酒吧街", "影视城", "艺术区", "创意园区", "大学", "摩天轮", "酒庄/酒厂", "灯塔",
                    "电视塔"},
            s4 = new String[]{"全部", "博物馆", "展览馆", "纪念馆", "滑雪场", "科技馆", "图书馆", "运动场馆", "美术馆"
                    , "蜡像馆", "体育馆", "音乐厅", "骑马场", "歌剧院", "体育场", "赌场", "古代军事博物馆", "电影院"},
            s5 = new String[]{"全部", "城市公园", "主题公园", "休闲公园", "湿地公园", "郊野公园", "植物园", "水上乐园", "海洋馆"
                    , "动物园", "水族馆", "游乐园", "儿童乐园", "室内乐园", "冰雪世界"},
            s6 = new String[]{"度假村", "农家乐", "农场", "5A景区", "4A景区", "3A景区", "2A景区", "1A景区"
                    , "国家级文物保护单位", "国家级风景名胜区", "国家级森林公园", "国家公园", "国家级地质公园", "国家级自然保护区"
                    , "自然保护区", "省/市级文物保护单位", "省/市级风景名胜区", "省/市级自然保护区", "世界文化遗产", "世界级地质公园"
                    , "世界自然遗产", "世界生态圈保护区", "世界文化与自然双重遗产", "世界文化景观",};
    private String[] all = new String[]{"全部"};
    private SwitchMultiButton switchMultiButton;
    private boolean customlocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locate);
        ButterKnife.bind(this);
        initialSpinner();
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        customlocation = sharedPreferences.getBoolean("customlocation", false);
        switchMultiButton = (SwitchMultiButton) findViewById(R.id.switch_location);
        initialLocation();
//        switchButton.setChecked(sharedPreferences.getBoolean("customlocation",false));
    }

    private void initialLocation() {
        switchMultiButton.setText("默认位置", "自定义位置");
        if (this.customlocation) {
            switchMultiButton.setSelectedTab(1);
        }
        switchMultiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (customlocation && (switchMultiButton.getSelectedTab() == 1)) {
                    Intent intent = new Intent(LocateActivity.this, MapActivity.class);
                    intent.putExtra("data", 2);
                    startActivity(intent);
                    finish();
                }
            }
        });
        switchMultiButton.setOnSwitchListener(new SwitchMultiButton.OnSwitchListener() {
            @Override
            public void onSwitch(int position, String tabText) {
                if (position == 0) {
                    editor.putBoolean("customlocation", false);
                    editor.apply();
                } else if (position == 1) {
                    editor.putBoolean("customlocation", true);
                    editor.apply();
                    Intent intent = new Intent(LocateActivity.this, MapActivity.class);
                    intent.putExtra("data", 2);
                    startActivity(intent);
                    finish();
                }
            }
        });

//        switchButton.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
//                editor.putBoolean("customlocation",isChecked);
//                editor.apply();
//                if (isChecked) {
//                    Intent intent = new Intent(LocateActivity.this, MapActivity.class);
//                    startActivity(intent);
//                }
//            }
//        });
    }

    public void initialSpinner() {
        provinceSpinner.setItems(provinces);
        provinceSpinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                HttpUtil.changeDistricts(App.changeDisadd, item, new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Log.d(TAG, "onFailure: " + e.toString());
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        String result = response.body().string();
                        Log.d(TAG, "onResponse: " + result);
                        try {
                            JSONArray array = new JSONArray(result);
                            ArrayList<String> subs = new ArrayList<>();
                            subs.add("全省");
                            String district;
                            for (int i = 0; i < array.length(); i++) {
                                district = array.getString(i);
                                subs.add(district);
                            }
                            districts.clear();
                            districts.addAll(subs);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    districtSpinner.setItems(subs);
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
//        districtSpinner.setItems(all);
//        subtagSpinner.setItems(all);
        maintagSpinner.setItems(maintags);
        maintagSpinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                if (item.equals("全部")) {
                    subtags.clear();
                    subtags.add("全部");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("自然风光&自然景观")) {
                    subtags.clear();
                    for (String s : s1) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("建筑人文&历史建筑")) {
                    subtags.clear();
                    for (String s : s2) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("城市观光")) {
                    subtags.clear();
                    for (String s : s3) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("场馆院所&展馆展览")) {
                    subtags.clear();
                    for (String s : s4) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("演出演艺")) {
                    String[] ss = new String[]{"全部"};
                    subtags.clear();
                    for (String s : ss) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("主题乐园&动植物园")) {
                    subtags.clear();
                    for (String s : s5) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                } else if (item.equals("特色")) {
                    subtags.clear();
                    for (String s : s6) {
                        subtags.add(s);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            subtagSpinner.setItems(subtags);
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        int proIndex = provinceSpinner.getSelectedIndex();
        String provincename = provinces[proIndex];
        int disIndex = districtSpinner.getSelectedIndex();
        String districtsname = "";
        if (districts.size() >= (disIndex + 1)) {
            districtsname = districts.get(disIndex);
        }
        int mIndex = maintagSpinner.getSelectedIndex();
        editor.putString("province", provincename);
        editor.putString("district", districtsname);
        switch (mIndex) {
            case 0:
                editor.putString("maintag", "");
                break;
            case 1:
                editor.putString("maintag", "自然风光&自然景观");
                break;
            case 2:
                editor.putString("maintag", "建筑人文&历史建筑");
                break;
            case 3:
                editor.putString("maintag", "城市观光");
                break;
            case 4:
                editor.putString("maintag", "场馆院所&展馆展览");
                break;
            case 5:
                editor.putString("maintag", "演出演艺");
                break;
            case 6:
                editor.putString("maintag", "主题乐园&动植物园");
                break;
            case 7:
                editor.putString("maintag", "");
                break;
            default:
                break;
        }
        int sIndex = subtagSpinner.getSelectedIndex();
        String item = "";
        if (subtags.size() >= (sIndex + 1)) {
            item = subtags.get(sIndex);
        }
        if (item.equals("全部")) {
            editor.putString("subtag", "");
        } else {
            editor.putString("subtag", item);
        }
        editor.apply();
        Intent intent = new Intent(this, SceneActivity.class);
        startActivity(intent);
    }
}

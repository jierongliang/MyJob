package com.ljr.travel.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.amap.api.maps.model.LatLng;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.Activity.SceneDetailActivity;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;
import com.sackcentury.shinebuttonlib.ShineButton;

import java.util.ArrayList;
import java.util.List;

public class CardPagerAdapter extends PagerAdapter {
    private ArrayList<Scene> scenes;
    private Activity activity;
    private boolean flag;
    private boolean showdislike;
    private LatLng latLng;
    private List<String> likescenes, dislikescenes;
    private static final String TAG = "CardPagerAdapter";



    @Override
    public int getCount() {
//        if (!showdislike) {
//            return scenes.size()-dislikescenes.size();
//        }
        return scenes.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Scene scene = scenes.get(position);
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.cardview_item, null, false);
        RImageView cardThumbimg = (RImageView) view.findViewById(R.id.card_thumbimg);
        RTextView cardName = (RTextView) view.findViewById(R.id.card_name);
        RTextView cardAddress = (RTextView) view.findViewById(R.id.card_address);
        RTextView cardScore = (RTextView) view.findViewById(R.id.card_score);
        RTextView cardCommentNum = (RTextView) view.findViewById(R.id.card_commentNum);
        RTextView cardDistance = (RTextView) view.findViewById(R.id.card_distance);
        RTextView cardNumber = (RTextView) view.findViewById(R.id.card_number);
        ShineButton cardDislike = (ShineButton) view.findViewById(R.id.card_dislike);
        ShineButton cardLike = (ShineButton) view.findViewById(R.id.card_like);
        cardLike.init(activity);
        cardDislike.init(activity);
        Glide.with(activity)
                .load(scene.getThumbimg())
                .override(200, 100)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(cardThumbimg);
        cardName.setText(scene.getName());
        cardAddress.setText(scene.getAddress());
        cardScore.setText(scene.getScore() + "分");
//        cardScore.setText(scene.getPredictscore()+"分");
        cardCommentNum.setText(scene.getCommentNum() + "条评论");
        if (flag) {
            LatLng scenelatlng = new LatLng(scene.getLatitude(), scene.getLongitude());
            cardDistance.setText("距离自定义位置" + BaseUtil.formadDistance(BaseUtil.calculateDistance(scenelatlng, latLng)));
        } else {
            cardDistance.setText("距离市中心" + BaseUtil.formadDistance(scene.getDistanceDis()) + "\n距离省中心" + BaseUtil.formadDistance(scene.getDistancePro()));
        }
        int temp = position + 1;
        cardNumber.setText(temp + "/" + scenes.size());
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scene scene = scenes.get(position);
                String sceneid = scene.getSceneid();
                Intent intent = new Intent(activity, SceneDetailActivity.class);
                intent.putExtra("sceneid", sceneid);
                activity.startActivity(intent);
            }
        });
        String sceneid = scene.getSceneid();
        if (likescenes.contains(sceneid)) {
            cardLike.setChecked(true);
        } else if (dislikescenes.contains(sceneid)) {
            cardDislike.setChecked(true);
        }
        cardLike.setOnCheckStateChangeListener(new ShineButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(View view, boolean checked) {
                String sceneid = scene.getSceneid();
                if (checked) {
                    if (!likescenes.contains(sceneid)) {
                        likescenes.add(sceneid);
                    }
                    if (cardDislike.isChecked() && dislikescenes.contains(sceneid)) {
                        dislikescenes.remove(sceneid);
                        cardDislike.setChecked(false);
                    }
                } else {
                    if (likescenes.contains(sceneid)) {
                        likescenes.remove(sceneid);
                    }
                }
//                Log.d(TAG, "onCheckedChanged: "+sceneid+" checked"+checked+" like"+likescenes+"\n dislike"+dislikescenes);
            }
        });
        cardDislike.setOnCheckStateChangeListener(new ShineButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(View view, boolean checked) {
                String sceneid = scene.getSceneid();
                if (checked) {
                    if (!dislikescenes.contains(sceneid)) {
                        dislikescenes.add(sceneid);
                    }
                    if (cardLike.isChecked() && likescenes.contains(sceneid)) {
                        likescenes.remove(sceneid);
                        cardLike.setChecked(false);
                    }
                } else {
                    if (dislikescenes.contains(sceneid)) {
                        dislikescenes.remove(sceneid);
                    }
                }
//                Log.d(TAG, "onCheckedChanged: "+sceneid+" checked"+checked+" like"+likescenes+"\n dislike"+dislikescenes);
            }
        });
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getItemPosition(Object object) {
//        TextView textView = (TextView) object;
//        String text = textView.getText().toString();
//        int index = scenes.indexOf(text);
//        if (index >= 0) {
//            backk index;
//        }
        return POSITION_NONE;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return scenes.get(position).getName();
    }



    public List<String> getLikescenes() {
        return likescenes;
    }

    public boolean isShowdislike() {
        return showdislike;
    }

    public void setShowdislike(boolean showdislike) {
        this.showdislike = showdislike;
    }

    public void setLikescenes(List<String> likescenes) {
        this.likescenes = likescenes;
    }

    public List<String> getDislikescenes() {
        return dislikescenes;
    }

    public void setDislikescenes(List<String> dislikescenes) {
        this.dislikescenes = dislikescenes;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public void setLatLng(LatLng latLng) {
        this.latLng = latLng;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public CardPagerAdapter(ArrayList<Scene> scenes, Activity activity) {
        this.scenes = scenes;
        this.activity = activity;
    }

    public CardPagerAdapter(ArrayList<Scene> scenes) {
        this.scenes = scenes;
    }

    public ArrayList<Scene> getScenes() {
        return scenes;
    }

    public void setScenes(ArrayList<Scene> scenes) {
        this.scenes = scenes;
    }
}

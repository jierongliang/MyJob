package com.ljr.travel.Activity;

import android.app.Application;
import android.content.Context;
import android.widget.ImageView;

import com.assionhonty.lib.assninegridview.AssNineGridView;
import com.bumptech.glide.Glide;
import com.guoxiaoxing.phoenix.core.listener.ImageLoader;
import com.guoxiaoxing.phoenix.picker.Phoenix;
import com.kongzue.dialog.util.DialogSettings;

import com.kongzue.dialog.util.DialogSettings;
import com.ljr.travel.Bean.GlideImageLoader;

public class App extends Application {
    public static String ipaddress = "192.168.0.101";
    public static String registeradd = "http://" + ipaddress + ":8080/Travel/Register";
    public static String loginadd = "http://" + ipaddress + ":8080/Travel/Login";
    public static String changeusernameadd = "http://" + ipaddress + ":8080/Travel/ChangeUsername";
    public static String uploadImgadd = "http://" + App.ipaddress + ":8080/Travel/UploadSingleImage";
    public static String changeDisadd = "http://" + App.ipaddress + ":8080/Travel/ChangeDistrict";
    public static String querySceneadd = "http://" + App.ipaddress + ":8080/Travel/QueryScene";
    public static String querySceneDetailadd = "http://" + App.ipaddress + ":8080/Travel/SceneDetail";
    public static String querySceneCommentadd = "http://" + App.ipaddress + ":8080/Travel/SceneComment";
    public static String uploadCommentAddress = "http://" + App.ipaddress + ":8080/Travel/UploadComment";
    public static String queryTagRecommend = "http://" + App.ipaddress + ":8080/Travel/TagRecommend";
    public static String queryUserRecommend = "http://" + App.ipaddress + ":8080/Travel/UserRecommend";
    public static String queryItemRecommend = "http://" + App.ipaddress + ":8080/Travel/ItemRecommend";
    public static String querySlopeoneRecommend = "http://" + App.ipaddress + ":8080/Travel/Slopeone";
    public static String queryComment = "http://" + App.ipaddress + ":8080/Travel/UserComment";
    public static String updateTag = "http://" + App.ipaddress + ":8080/Travel/UpdateTag";
    public static String updateUserRecommend = "http://" + App.ipaddress + ":8080/Travel/updateUserRecommend";
    public static String updateItemRecommend = "http://" + App.ipaddress + ":8080/Travel/updateItemRecommend";
    public static String updateSlopeoneRecommend = "http://" + App.ipaddress + ":8080/Travel/updateSlopeoneRecommend";

    @Override
    public void onCreate() {
        super.onCreate();
        AssNineGridView.setImageLoader(new GlideImageLoader());
        Phoenix.config()
                .imageLoader(new ImageLoader() {
                    @Override
                    public void loadImage(Context mContext, ImageView imageView
                            , String imagePath, int type) {
                        Glide.with(mContext)
                                .load(imagePath)
                                .into(imageView);  
                    }

                });

//        DialogSettings.isUseBlur = (boolean);                   //是否开启模糊效果，默认关闭
        DialogSettings.style = (DialogSettings.STYLE.STYLE_KONGZUE);          //全局主题风格，提供三种可选风格，STYLE_MATERIAL, STYLE_KONGZUE, STYLE_IOS
        DialogSettings.theme = (DialogSettings.THEME.LIGHT);          //全局对话框明暗风格，提供两种可选主题，LIGHT, DARK
        DialogSettings.tipTheme = (DialogSettings.THEME.LIGHT);       //全局提示框明暗风格，提供两种可选主题，LIGHT, DARK
//        DialogSettings.titleTextInfo = (TextInfo);              //全局标题文字样式
//        DialogSettings.contentTextInfo = (TextInfo);            //全局正文文字样式
//        DialogSettings.buttonTextInfo = (TextInfo);             //全局默认按钮文字样式
//        DialogSettings.buttonPositiveTextInfo = (TextInfo);     //全局焦点按钮文字样式（一般指确定按钮）
//        DialogSettings.inputInfo = (InputInfo);                 //全局输入框文本样式
//        DialogSettings.backgroundColor = (ColorInt);            //全局对话框背景颜色，值0时不生效
//        DialogSettings.cancelable = (boolean);                  //全局对话框默认是否可以点击外围遮罩区域或返回键关闭，此开关不影响提示框（TipDialog）以及等待框（TipDialog）
//        DialogSettings.cancelableTipDialog = (boolean);         //全局提示框及等待框（WaitDialog、TipDialog）默认是否可以关闭
//        DialogSettings.DEBUGMODE = (boolean);                   //是否允许打印日志
//        DialogSettings.blurAlpha = (int);                       //开启模糊后的透明度（0~255）
//        DialogSettings.systemDialogStyle = (styleResId);        //自定义系统对话框style，注意设置此功能会导致原对话框风格和动画失效
//        DialogSettings.dialogLifeCycleListener = (DialogLifeCycleListener);  //全局Dialog生命周期监听器
//        DialogSettings.defaultCancelButtonText = (String);      //设置 BottomDialog 和 ShareDialog 默认“取消”按钮的文字
//        DialogSettings.tipBackgroundResId = (drawableResId);    //设置 TipDialog 和 WaitDialog 的背景资源
//        DialogSettings.tipTextInfo = (InputInfo);               //设置 TipDialog 和 WaitDialog 文字样式
    }
}

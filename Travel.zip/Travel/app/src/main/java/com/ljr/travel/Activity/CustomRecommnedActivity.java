package com.ljr.travel.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.ljr.travel.Adapter.CardPagerAdapter;
import com.ljr.travel.Adapter.RecommendAdapter;
import com.ljr.travel.Bean.MyHeader;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.MainActivity;
import com.ljr.travel.R;
import com.ljr.travel.Util.HttpUtil;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import lib.kingja.switchbutton.SwitchMultiButton;
import me.yuqirong.cardswipelayout.CardConfig;
import me.yuqirong.cardswipelayout.CardItemTouchHelperCallback;
import me.yuqirong.cardswipelayout.CardLayoutManager;
import me.yuqirong.cardswipelayout.OnSwipeListener;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
public class CustomRecommnedActivity extends AppCompatActivity {
    @BindView(R.id.recm_recyclerview)
    RecyclerView recmRecyclerview;
    @BindView(R.id.switch_btn)
    SwitchMultiButton switchBtn;
    private ArrayList<Scene> userscenes;
    private ArrayList<Scene> itemscenes;
    private ArrayList<Scene> slopescenes;
    private ArrayList<Scene> showScenes;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String username;
    private String[] provinces = new String[]{"全国", "浙江", "上海", "江苏", "广东", "山东"};
    private MyHeader header;
    private int flag;
    private static final String TAG = "CustomRecommnedActivity";
    private RecommendAdapter adapter;
    private boolean customLocation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_recommend2);
        ButterKnife.bind(this);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        username = sharedPreferences.getString("username", "");
        customLocation = sharedPreferences.getBoolean("customlocation", false);
        initialRefreshLayout();
        initialUserRecommendData();
        initialItemRecommendData();
        initialSlopeoneRecommendData();
        initialSwitchBtn();
    }
    private void initialRefreshLayout() {
        if (userscenes == null) {
            userscenes = new ArrayList<>();
        }
        if (itemscenes == null) {
            itemscenes = new ArrayList<>();
        }
        if (slopescenes == null) {
            slopescenes = new ArrayList<>();
        }
        if (showScenes == null) {
            showScenes = new ArrayList<>();
        }
        if (adapter == null) {
            adapter = new RecommendAdapter(customLocation, showScenes, CustomRecommnedActivity.this);
        }
        recmRecyclerview.setItemAnimator(new DefaultItemAnimator());
        recmRecyclerview.setAdapter(adapter);
        CardItemTouchHelperCallback cardCallback = new CardItemTouchHelperCallback(adapter, showScenes);
        cardCallback.setOnSwipedListener(new OnSwipeListener<Scene>() {
            @Override
            public void onSwiping(RecyclerView.ViewHolder viewHolder, float ratio, int direction) {
                RecommendAdapter.ViewHolder myHolder = (RecommendAdapter.ViewHolder) viewHolder;
                viewHolder.itemView.setAlpha(1 - Math.abs(ratio) * 0.2f);
                if (direction == CardConfig.SWIPING_LEFT) {
//                    myHolder.dislikeImageView.setAlpha(Math.abs(ratio));
                } else if (direction == CardConfig.SWIPING_RIGHT) {
//                    myHolder.likeImageView.setAlpha(Math.abs(ratio));
                } else {
//                    myHolder.dislikeImageView.setAlpha(0f);
//                    myHolder.likeImageView.setAlpha(0f);
                }
            }
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, Scene o, int direction) {
                RecommendAdapter.ViewHolder myHolder = (RecommendAdapter.ViewHolder) viewHolder;
                viewHolder.itemView.setAlpha(1f);
//                myHolder.dislikeImageView.setAlpha(0f);
//                myHolder.likeImageView.setAlpha(0f);
                Toast.makeText(CustomRecommnedActivity.this, direction == CardConfig.SWIPED_LEFT ? "swiped left" : "swiped right", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onSwipedClear() {
                Toast.makeText(CustomRecommnedActivity.this, "data clear", Toast.LENGTH_SHORT).show();
                recmRecyclerview.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        int tab = switchBtn.getSelectedTab();
                        if (tab == 0) {
                            showScenes.addAll(userscenes);
                        }
                        else if (tab == 1) {
                            showScenes.addAll(itemscenes);

                        }
                        else if (tab == 2) {
                            showScenes.addAll(slopescenes);
                        }
                        recmRecyclerview.getAdapter().notifyDataSetChanged();
                    }
                }, 3000L);
            }
        });
        final ItemTouchHelper touchHelper = new ItemTouchHelper(cardCallback);
        final CardLayoutManager cardLayoutManager = new CardLayoutManager(recmRecyclerview, touchHelper);
        recmRecyclerview.setLayoutManager(cardLayoutManager);
        touchHelper.attachToRecyclerView(recmRecyclerview);
    }
    private void initialSwitchBtn() {
    }
    private void initialItemRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.queryItemRecommend(App.queryItemRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    double predictscore, longitude, latitude;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    itemscenes.clear();
                    itemscenes.addAll(datas);
                    Collections.sort(itemscenes, new PredictScoreComparator());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }
    private void initialSlopeoneRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.querySlopeRecommend(App.querySlopeoneRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    double predictscore, longitude, latitude;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    slopescenes.clear();
                    slopescenes.addAll(datas);
                    Collections.sort(slopescenes, new PredictScoreComparator());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }
    private void initialUserRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.queryUserRecommend(App.queryUserRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    double predictscore, longitude, latitude;
                    StringBuilder builder = new StringBuilder();
                    Log.d(TAG, "onResponse: size"+array.length());
                    for (int i = 0; i < 10; i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        builder.append(name);
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    Log.d(TAG, "onResponse: finish" + builder.toString());
                    userscenes.clear();
                    userscenes.addAll(datas);
                    Collections.sort(userscenes, new PredictScoreComparator());
                    showScenes.clear();
                    showScenes.addAll(userscenes);
                    Collections.sort(showScenes, new PredictScoreComparator());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }
}

package com.ljr.travel.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.kongzue.dialog.v3.TipDialog;
import com.kongzue.dialog.v3.WaitDialog;
import com.ljr.travel.Adapter.StringTagAdapter;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.RTextView;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;
import zhouyou.flexbox.interfaces.OnFlexboxSubscribeListener;
import zhouyou.flexbox.widget.TagFlowLayout;
public class MyTagActivity extends AppCompatActivity {
    @BindView(R.id.choose_tag)
    RTextView chooseTag;
    private StringTagAdapter adapter;
    private ArrayList<String> tags;
    private ArrayList<String> selecttags;
    private TagFlowLayout flowLayout;
    private static final String TAG = "MyTagActivity";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tag);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        String source = sharedPreferences.getString("tag","[]");
        Log.d(TAG, "onCreate: initial"+source);
        ButterKnife.bind(this);
//        WaitDialog.show(MyTagActivity.this, "正在初始化数据");
        initialAdapter();
        initialData();


    }
    private void initialAdapter() {
        if (tags == null) {
            tags = new ArrayList<>();
        }
        if (selecttags == null) {
            selecttags = new ArrayList<>();
        }
        flowLayout = (TagFlowLayout) findViewById(R.id.flow_layout);
        if (adapter == null) {
            adapter = new StringTagAdapter(MyTagActivity.this, tags, selecttags);
        }
        adapter.setOnSubscribeListener(new OnFlexboxSubscribeListener<String>() {
            @Override
            public void onSubscribe(List<String> selectedItem) {
                selecttags.clear();
                selecttags.addAll(selectedItem);
                chooseTag.setText(parseList(selectedItem));
            }
        });
        flowLayout.setAdapter(adapter);
    }
    public void initialData() {
        String[] tagarray = BaseUtil.tagStr.split(" ");
        for (int i = 0; i < tagarray.length; i++) {
            tags.add(tagarray[i]);
        }
        String source = sharedPreferences.getString("tag","[]");
        try {
            JSONArray array = new JSONArray(source);
            for(int i=0;i<array.length()  ;i++){
                selecttags.add(array.getString(i));
            }
            chooseTag.setText(parseList(selecttags));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        WaitDialog.show(MyTagActivity.this,"加载数据中");

        adapter.notifyDataSetChanged();
        BaseUtil.showCustomTipDialog(MyTagActivity.this,"success", TipDialog.TYPE.SUCCESS);

    }



    public String parseList(List<String> selectitems){
        StringBuilder builder = new StringBuilder();
        for (String string:selectitems) {
            builder.append(string+ " ");
        }
        return builder.toString();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    private void saveTag() {
        JSONArray array = new JSONArray(selecttags);
        editor.putString("tag",array.toString());
        Log.d(TAG, "saveTag: "+array.toString());
        editor.apply();
    }
    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: "+selecttags.size());
        super.onBackPressed();
        saveTag();
        Intent intent = new Intent(this, MyActivity.class);
        startActivity(intent);
    }
    //    private Button btnCount;
//
//    private List<String> sourceData;
//    private List<String> selectItems;
//    private void initData() {
//        sourceData = new ArrayList<>();
//        sourceData.add("程序员");
//        sourceData.add("设计师");
//        sourceData.add("产品经理");
//        sourceData.add("运营");
//        sourceData.add("商务");
//        sourceData.add("人事经理");
//        sourceData.add("项目经理");
//        sourceData.add("客户代表");
//        sourceData.add("技术主管");
//        sourceData.add("测试工程师");
//        sourceData.add("前端工程师");
//        sourceData.add("Java工程师");
//        sourceData.add("Android工程师");
//        sourceData.add("iOS工程师");
//
//        selectItems = new ArrayList<>();
//        selectItems.add("客户代表");
//        selectItems.add("Java工程师");
//    }
//    private void initViews() {
//        TagFlowLayout flowLayout = (TagFlowLayout) findViewById(R.id.flow_layout);
//        btnCount = (Button) findViewById(R.id.btn_get_count);
//        adapter = new StringTagAdapter(this, sourceData, selectItems);
//        adapter.setOnSubscribeListener(new OnFlexboxSubscribeListener<String>() {
//            @Override
//            public void onSubscribe(List<String> selectedItem) {
//                btnCount.setText("已选择" + selectedItem.size() + "个");
//            }
//        });
//        flowLayout.setAdapter(adapter);
//        btnCount.setText("已选择" + adapter.getSelectedList().size() + "个");
//        findViewById(R.id.btn_switch_data).setOnClickListener(this);
//    }
//    @Override
//    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.btn_switch_data:
//                List<String> data = new ArrayList<>();
//                data.add("客户代表");
//                data.add("Java工程师");
//
//                List<String> selectList = new ArrayList<>();
//                selectList.add("客户代表");
//                adapter.setSource(data);
//                adapter.setSelectItems(selectList);
//                adapter.notifyDataSetChanged();
//                break;
//            default:
//                break;
//        }
//    }
}

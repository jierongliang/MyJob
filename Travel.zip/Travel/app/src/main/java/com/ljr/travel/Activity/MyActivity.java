package com.ljr.travel.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.amap.api.maps.AMapUtils;
import com.amap.api.maps.model.LatLng;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.R;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MyActivity extends AppCompatActivity {

    @BindView(R.id.my_usericon)
    RImageView myUsericon;
    @BindView(R.id.my_username)
    RTextView myUsername;

    @BindView(R.id.img_scene)
    ImageView imgScene;
    @BindView(R.id.txt_scene)
    TextView txtScene;
    @BindView(R.id.img_my)
    ImageView imgMy;
    @BindView(R.id.txt_my)
    TextView txtMy;
//    @BindView(R.id.my_collection)
//    RTextView myCollection;
    @BindView(R.id.my_score)
    RTextView myScore;
//    @BindView(R.id.my_share)
//    RTextView myShare;
    @BindView(R.id.my_tag)
    RTextView myTag;
    @BindView(R.id.my_recommend)
    RTextView myRecommend;
    @BindView(R.id.my_logouti)
    RImageView myLogouti;
    @BindView(R.id.my_logoutt)
    RTextView myLogoutt;
    @BindView(R.id.img_recommend)
    ImageView imgRecommend;
    @BindView(R.id.txt_recommend)
    TextView txtRecommend;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String TAG = "MyActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        ButterKnife.bind(this);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        initialColor();
        initialName();
        initial();
    }
    public void initial(){
        boolean flag = sharedPreferences.getBoolean("initialLat",false);
        if (flag) return;
        InputStream inputStream = null;
        try {
            inputStream = getAssets().open("latlng.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String source = reader.readLine();
            JSONObject object = new JSONObject(source);
            Iterator<String> iterator = object.keys();
            String sceneid;
            JSONObject dict;
            double latitude,longitude;
            while (iterator.hasNext()) {
                sceneid = iterator.next();
                dict = object.getJSONObject(sceneid);
                latitude = dict.getDouble("la");
                longitude = dict.getDouble("ln");
                editor.putString(sceneid,latitude+"A"+longitude);
                Log.d(TAG, "initial: "+sceneid+ " la"+latitude+" ln"+longitude);
            }
            editor.putBoolean("initialLat",true);
            editor.apply();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            Log.d(TAG, "initial: "+e.toString());
        }
    }

    public void initialColor() {
        int primary = Color.parseColor("#0980C3");
        int selected = Color.parseColor("#0000CD");
        imgMy.setColorFilter(selected);
        txtMy.setTextColor(selected);
    }

    public void initialName() {
        String name = sharedPreferences.getString("username", "");
        if (!TextUtils.isEmpty(name)) {
            myUsername.setText(name);
            String iconUrl = "http://" + App.ipaddress + ":80/" + name + "/usericon.jpg";
            Glide.with(this)
                    .load(iconUrl)
                    .override(70, 70)
                    .placeholder(R.drawable.default_usericon)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(myUsericon);
        }
    }

    @OnClick(R.id.my_usericon)
    public void onMyUsericonClicked() {
        Intent intent = new Intent(this, ChangeInformationActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.my_username)
    public void onMyUsernameClicked() {
        Intent intent = new Intent(this, ChangeInformationActivity.class);
        startActivity(intent);
    }

//    @OnClick(R.id.my_collection)
//    public void onMyCollectionClicked() {
////        Intent intent = new Intent(this, MapActivity.class);
////        startActivity(intent);
//        Intent intent = new Intent(this, CustomRecommnedActivity.class);
//        startActivity(intent);
//    }

    @OnClick(R.id.my_score)
    public void onMyScoreClicked() {
        Intent intent = new Intent(this, MyScoreActivity.class);
        startActivity(intent);
    }

//    @OnClick(R.id.my_share)
//    public void onMyShareClicked() {
//        LatLng latLng1 = new LatLng(29.748242, 105.765002),
//                latLng2 = new LatLng(43.771340, 125.450845);
//        float distance = AMapUtils.calculateLineDistance(latLng1, latLng2);
//        Toast.makeText(this, "distance " + distance, Toast.LENGTH_SHORT).show();
//    }

    @OnClick(R.id.my_tag)
    public void onMyTagClicked() {
        Intent intent = new Intent(this, MyTagActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.my_recommend)
    public void onMyRecommendClicked() {
    }

    @OnClick(R.id.my_logouti)
    public void onMyLogoutiClicked() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        editor.putBoolean("isLogin", false);
        editor.apply();
        finish();
    }

    @OnClick(R.id.my_logoutt)
    public void onMyLogouttClicked() {
    }

    @OnClick(R.id.img_scene)
    public void onImgSceneClicked() {
        Intent intent = new Intent(this, SceneActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.txt_scene)
    public void onTxtSceneClicked() {
        Intent intent = new Intent(this, SceneActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.img_recommend)
    public void onImgRecommendClicked() {
        Intent intent = new Intent(this, CustomRecommendActivity2.class);
        startActivity(intent);
    }

    @OnClick(R.id.txt_recommend)
    public void onTxtRecommendClicked() {
        Intent intent = new Intent(this, CustomRecommendActivity2.class);
        startActivity(intent);
    }
}

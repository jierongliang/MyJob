package com.ljr.travel.Adapter;

import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.ljr.travel.Bean.TC;
import com.ljr.travel.R;
import com.ruffian.library.widget.RTextView;

import java.util.List;

public class MyPagerAdapter extends PagerAdapter {
    private List<TC> recommends;

    public MyPagerAdapter(List<TC> recommends) {
        this.recommends = recommends;
    }

    @Override
    public int getCount() {
        return recommends==null? 0:recommends.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }
    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.rc_item, null, false);
        RTextView name = (RTextView) view.findViewById(R.id.tagr_name),
                address = (RTextView) view.findViewById(R.id.tagr_address),
                tags = (RTextView) view.findViewById(R.id.tagr_tags);
        TC tc = recommends.get(position);
        name.setText(tc.getName());
        address.setText(tc.getProvincename()+"省 "+tc.getCityname()+"市\n"+tc.getAddress());
        StringBuilder builder = new StringBuilder();
        for (String t:tc.getTags()) {
            builder.append(t+" |");
        }
        tags.setText(builder.toString());
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getItemPosition(Object object) {
        TextView textView = (TextView) object;
        String text = textView.getText().toString();
        int index = recommends.indexOf(text);
        if (index >= 0) {
            return index;
        }
        return POSITION_NONE;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return recommends.get(position).getName();
    }
}

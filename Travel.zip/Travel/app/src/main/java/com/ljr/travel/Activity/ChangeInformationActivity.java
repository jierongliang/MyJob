package com.ljr.travel.Activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.REditText;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.UCropActivity;

import java.io.File;
import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
public class ChangeInformationActivity extends AppCompatActivity {
    @BindView(R.id.change_username)
    RTextView changeUsername;
    @BindView(R.id.change_usericon)
    RImageView changeUsericon;
    @BindView(R.id.change_userbg)
    RImageView changeUserbg;
    @BindView(R.id.change_usertext)
    REditText changeUsertext;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String username = "";
    protected static final int REQUEST_STORAGE_READ_ACCESS_PERMISSION = 101;
    protected static final int REQUEST_STORAGE_WRITE_ACCESS_PERMISSION = 102;
    private int requestModeBg = 1;
    private int requestModeIcon = 2;
    private boolean flag = true;//true icon false bg
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";
    private static final String TAG = "ChangeInformationActivi";
    private AlertDialog mAlertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);//distributionUrl=https/://services.gradle.org/distributions/gradle-5.1.1-all.zip
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_information);
        ButterKnife.bind(this);
        initial();
    }
    public void initial(){
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        username = sharedPreferences.getString("username", "");
        changeUsertext.setText(username);
        String iconUrl = "http://" + App.ipaddress + ":80/" + username + "/usericon.jpg";
        Glide.with(this)
                .load(iconUrl)
                .override(70,70)
                .placeholder(R.drawable.default_usericon)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(changeUsericon);
        String bgUrl = "http://" + App.ipaddress + ":80/" + username + "/userbg.jpg";
        Glide.with(this)
                .load(bgUrl)
                .placeholder(R.drawable.default_userbg)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(changeUserbg)
                ;
    }
    @OnClick(R.id.change_username)
    public void onChangeUsernameClicked() {
        String text = changeUsername.getText().toString();
        if (text.equals("修改")) {
            changeUsername.setText("保存");
            changeUsertext.setEnabled(true);
        } else {
            String after = changeUsertext.getText().toString();
            HttpUtil.changeUsername(App.changeusernameadd, this.username,after , new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    BaseUtil.showDialog(ChangeInformationActivity.this,"提示","保存失败");
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String res = response.body().string();
                    if (res.startsWith("success")) {
                        BaseUtil.showDialog(ChangeInformationActivity.this,"提示","保存成功");
                        editor.putString("username",after);
                        ChangeInformationActivity.this.username = after;
                        editor.apply();
                    }
                    else if (res.startsWith("fail")) {
                        BaseUtil.showDialog(ChangeInformationActivity.this,"提示","保存失败");
                    }
                }
            });
            changeUsername.setText("修改");
            changeUsertext.setEnabled(false);
        }
    }
    @OnClick(R.id.change_usericon)
    public void onChangeUsericonClicked() {
        flag = true;
        pickFromGallery(requestModeIcon);
    }
    @OnClick(R.id.change_userbg)
    public void onChangeUserbgClicked() {
        flag = false;
        pickFromGallery(requestModeBg);

    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == requestModeBg) {
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    startCrop(selectedUri,1);
                } else {
                    Toast.makeText(ChangeInformationActivity.this, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show();
                }
            }
            else if (requestCode == requestModeIcon){
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    startCrop(selectedUri,2);
                } else {
                    Toast.makeText(ChangeInformationActivity.this, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show();
                }
            }
            else if (requestCode == UCrop.REQUEST_CROP) {
                handleCropResult(data);
            }
        }
        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }
    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            Log.e(TAG, "handleCropError: ", cropError);
            Toast.makeText(ChangeInformationActivity.this, cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(ChangeInformationActivity.this, R.string.toast_unexpected_error, Toast.LENGTH_SHORT).show();
        }
    }
    private void handleCropResult(@NonNull Intent result) {
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null) {
            if(flag){
                ResultActivity.startWithUri(ChangeInformationActivity.this, resultUri,0);
            }
            else{
                ResultActivity.startWithUri(ChangeInformationActivity.this, resultUri,1);
            }
        } else {
            Toast.makeText(ChangeInformationActivity.this, R.string.toast_cannot_retrieve_cropped_image, Toast.LENGTH_SHORT).show();
        }
    }
    private void startCrop(@NonNull Uri uri,int i) {
        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;
        destinationFileName += ".jpg";
//        getCacheDir()
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(Environment.getExternalStorageDirectory(), destinationFileName)));
//                 uCrop = uCrop.withMaxResultSize(800, 800);
//        uCrop = basisConfig(uCrop);
//        uCrop = advancedConfig(uCrop);
//        options.setShowCropFrame(true);
//        options.setCompressionQuality(50);
        if (i==2) {
            UCrop.Options options = new UCrop.Options();

            options.setAllowedGestures(UCropActivity.SCALE, UCropActivity.ROTATE, UCropActivity.ALL);
            options.setCircleDimmedLayer(true);
            uCrop.withOptions(options)
                    .withAspectRatio(1,1);
        }

        uCrop.start(ChangeInformationActivity.this);
    }

    private void pickFromGallery(int requestcode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE,
                    getString(R.string.permission_read_storage_rationale),
                    REQUEST_STORAGE_READ_ACCESS_PERMISSION);
        } else {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT)
                    .setType("image/*")
                    .addCategory(Intent.CATEGORY_OPENABLE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                String[] mimeTypes = {"image/jpeg", "image/png"};
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            }
            startActivityForResult(Intent.createChooser(intent, getString(R.string.label_select_picture)), requestcode);
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        if (mAlertDialog != null && mAlertDialog.isShowing()) {
            mAlertDialog.dismiss();
        }
    }
    protected void requestPermission(final String permission, String rationale, final int requestCode) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            showAlertDialog(getString(R.string.permission_title_rationale), rationale,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(ChangeInformationActivity.this,
                                    new String[]{permission}, requestCode);
                        }
                    }, getString(R.string.label_ok), null, getString(R.string.label_cancel));
        } else {
            ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
        }
    }
    protected void showAlertDialog(@Nullable String title, @Nullable String message,
                                   @Nullable DialogInterface.OnClickListener onPositiveButtonClickListener,
                                   @NonNull String positiveText,
                                   @Nullable DialogInterface.OnClickListener onNegativeButtonClickListener,
                                   @NonNull String negativeText) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(positiveText, onPositiveButtonClickListener);
        builder.setNegativeButton(negativeText, onNegativeButtonClickListener);
        mAlertDialog = builder.show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_STORAGE_READ_ACCESS_PERMISSION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickFromGallery(requestCode);
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
    //    private UCrop basisConfig(@NonNull UCrop uCrop) {
//        switch (mRadioGroupAspectRatio.getCheckedRadioButtonId()) {
//            case R.id.radio_origin:
//                uCrop = uCrop.useSourceImageAspectRatio();
//                break;
//            case R.id.radio_square:
//                uCrop = uCrop.withAspectRatio(1, 1);
//                break;
//            case R.id.radio_dynamic:
//                // do nothing
//                break;
//            default:
//                try {
//                    float ratioX = Float.valueOf(mEditTextRatioX.getText().toString().trim());
//                    float ratioY = Float.valueOf(mEditTextRatioY.getText().toString().trim());
//                    if (ratioX > 0 && ratioY > 0) {
//                        uCrop = uCrop.withAspectRatio(ratioX, ratioY);
//                    }
//                } catch (NumberFormatException e) {
//                    Log.i(TAG, String.format("Number please: %s", e.getMessage()));
//                }
//                break;
//        }
//
//        if (mCheckBoxMaxSize.isChecked()) {
//            try {
//                int maxWidth = Integer.valueOf(mEditTextMaxWidth.getText().toString().trim());
//                int maxHeight = Integer.valueOf(mEditTextMaxHeight.getText().toString().trim());
//                if (maxWidth > UCrop.MIN_SIZE && maxHeight > UCrop.MIN_SIZE) {
//                    uCrop = uCrop.withMaxResultSize(maxWidth, maxHeight);
//                }
//            } catch (NumberFormatException e) {
//                Log.e(TAG, "Number please", e);
//            }
//        }
//
//        backk uCrop;
//    }
//    private UCrop advancedConfig(@NonNull UCrop uCrop) {
//        UCrop.Options options = new UCrop.Options();
//
//        switch (mRadioGroupCompressionSettings.getCheckedRadioButtonId()) {
//            case R.id.radio_png:
//                options.setCompressionFormat(Bitmap.CompressFormat.PNG);
//                break;
//            case R.id.radio_jpeg:
//            default:
//                options.setCompressionFormat(Bitmap.CompressFormat.JPEG);
//                break;
//        }
//        options.setCompressionQuality(mSeekBarQuality.getProgress());
//
//        options.setHideBottomControls(mCheckBoxHideBottomControls.isChecked());
//        options.setFreeStyleCropEnabled(mCheckBoxFreeStyleCrop.isChecked());
//
//        /*
//        If you want to configure how gestures work for all UCropActivity tabs
//
//        options.setAllowedGestures(UCropActivity.SCALE, UCropActivity.ROTATE, UCropActivity.ALL);
//        * */
//
//        /*
//        This sets max size for bitmap that will be decoded from source Uri.
//        More size - more memory allocation, default implementation uses screen diagonal.
//
//        options.setMaxBitmapSize(640);
//        * */
//
//
//       /*
//
//        Tune everything (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧
//
//        options.setMaxScaleMultiplier(5);
//        options.setImageToCropBoundsAnimDuration(666);
//        options.setDimmedLayerColor(Color.CYAN);
//        options.setCircleDimmedLayer(true);
//        options.setCropGridStrokeWidth(20);
//        options.setCropGridColor(Color.GREEN);
//        options.setCropGridColumnCount(2);
//        options.setCropGridRowCount(1);
//        options.setToolbarCropDrawable(R.drawable.your_crop_icon);
//        options.setToolbarCancelDrawable(R.drawable.your_cancel_icon);
//
//        // Color palette
//        options.setToolbarColor(ContextCompat.getColor(this, R.color.your_color_res));
//        options.setStatusBarColor(ContextCompat.getColor(this, R.color.your_color_res));
//        options.setActiveWidgetColor(ContextCompat.getColor(this, R.color.your_color_res));
//        options.setToolbarWidgetColor(ContextCompat.getColor(this, R.color.your_color_res));
//        options.setRootViewBackgroundColor(ContextCompat.getColor(this, R.color.your_color_res));
//
//        // Aspect ratio options
//        options.setAspectRatioOptions(1,
//            new AspectRatio("WOW", 1, 2),
//            new AspectRatio("MUCH", 3, 4),
//            new AspectRatio("RATIO", CropImageView.DEFAULT_ASPECT_RATIO, CropImageView.DEFAULT_ASPECT_RATIO),
//            new AspectRatio("SO", 16, 9),
//            new AspectRatio("ASPECT", 1, 1));
//
//       */
//
//        backk uCrop.withOptions(options);
//    }
}

package com.ljr.travel.Bean;


import android.content.Context;

import com.scwang.smartrefresh.layout.header.ClassicsHeader;

public class MyHeader extends ClassicsHeader {
    public MyHeader(Context context) {
        super(context);
    }
    public void setmTextRefreshing(String text){
        mTextRefreshing = text;
    }
    public void setmTextFinish(String text){
        mTextFinish = text;
    }
    public void setmTextFailed(String text){
        mTextFailed = text;
    }
}

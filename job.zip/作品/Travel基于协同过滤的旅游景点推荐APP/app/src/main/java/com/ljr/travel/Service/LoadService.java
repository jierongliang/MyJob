package com.ljr.travel.Service;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.ljr.travel.Adapter.CardPagerAdapter;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class LoadService extends Service {
    public LoadService() {
    }
    private List<String> likescenes,dislikescenes;
    private CardPagerAdapter adapter;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private TimerTask task;
    private Timer timer;

    public LoadService(CardPagerAdapter adapter) {
        this.adapter = adapter;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        init();
        loadData();
    }

    private static final String TAG = "LoadService";
    private void init() {
        likescenes = adapter.getLikescenes();
        dislikescenes = adapter.getDislikescenes();
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        task = new TimerTask() {
            @Override
            public void run() {
                String likes,dislikes;
                likes = JSON.toJSONString(likescenes);
                dislikes = JSON.toJSONString(dislikescenes);
                editor.putString("likescenes",likes);
                editor.putString("dislikescenes",dislikes);
                editor.apply();
                Log.d(TAG, "run: like"+likes+" \ndislikes"+dislikes);
            }
        };
        timer = new Timer();
    }

    public void loadData(){

        timer.scheduleAtFixedRate(task,0,5000);
    }
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}

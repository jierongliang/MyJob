package com.ljr.travel.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.ljr.travel.Adapter.CommentAdapter;
import com.ljr.travel.Bean.Comment;
import com.ljr.travel.R;
import com.ljr.travel.Util.HttpUtil;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
public class MyScoreActivity extends AppCompatActivity {
    @BindView(R.id.comment_recyclerview)
    RecyclerView commentRecyclerview;
    private ArrayList<Comment> commentArrayList;
    private CommentAdapter adapter;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String username;
    private static final String TAG = "MyScoreActivity";
    private   HashMap<Integer,String> nameMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_score);
        ButterKnife.bind(this);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        username = sharedPreferences.getString("username", "");
        initialName();
        initialRecyclerview();
        initialComment();

    }
    private void initialComment() {
        HttpUtil.queryComment(App.queryComment, this.username, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                String sceneid, name, time, commenttext;
                double score;
                String imgStr;
                ArrayList<String> imgs;
                Comment comment;
                try {
                    ArrayList<Comment> comments = new ArrayList<>();
                    JSONArray array = new JSONArray(res);
                    JSONObject object;
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        sceneid = object.getString("sceneid");
                        name = object.getString("name");
                        time = object.getString("time");
                        imgStr = object.getString("imgs");
                        imgs = parseImg(imgStr);
                        commenttext = object.getString("commenttext");
                        score = object.getDouble("score");
                        comment = new Comment(sceneid,name,time,commenttext,score,imgs);
                        comments.add(comment);
                    }
                    commentArrayList.clear();
                    commentArrayList.addAll(comments);
                    for(int i = 0; i< commentArrayList.size() ; i++){
                        Log.d(TAG, "onResponse: "+commentArrayList.get(i));
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                            Log.d(TAG, "run: "+MyScoreActivity.this.commentArrayList.size());
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: "+e.toString());
                }
                catch (Exception e){
                    Log.d(TAG, "onResponse: "+e.toString());
                }
            }
        });
    }
    public ArrayList<String> parseImg(String imgs) {
        ArrayList<String> res = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(imgs);
            for (int i = 0; i < array.length(); i++) {
                res.add(array.getString(i));
            }
            return res;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return res;
    }
    private void initialRecyclerview() {
        if (commentArrayList == null) {
            commentArrayList = new ArrayList<>();
        }
        if (adapter == null) {
            adapter = new CommentAdapter(commentArrayList, MyScoreActivity.this);
            adapter.setNameMap(nameMap);
        }
        LinearLayoutManager manager = new LinearLayoutManager(this);
        commentRecyclerview.setLayoutManager(manager);
        commentRecyclerview.setAdapter(adapter);
    }
    public void initialName(){
        nameMap = new HashMap<>();
        InputStream inputStream = null;
        try {
            inputStream = getAssets().open("name.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            JSONObject object = new JSONObject(reader.readLine());
            for (Iterator<String> it = object.keys(); it.hasNext(); ) {
                String id = it.next();
                String name = object.getString(id);
                nameMap.put(Integer.parseInt(id),name);
            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}

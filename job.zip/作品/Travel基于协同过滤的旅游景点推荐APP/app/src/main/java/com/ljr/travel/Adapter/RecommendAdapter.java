package com.ljr.travel.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;

import java.util.List;

public class RecommendAdapter extends RecyclerView.Adapter<RecommendAdapter.ViewHolder> {

    private boolean customlocation;
    private List<Scene> scenes;
    private Activity activity;

    public RecommendAdapter(boolean customlocation, List<Scene> scenes, Activity activity) {
        this.customlocation = customlocation;
        this.scenes = scenes;
        this.activity = activity;
    }

    public boolean isCustomlocation() {
        return customlocation;
    }

    public void setCustomlocation(boolean customlocation) {
        this.customlocation = customlocation;
    }

    public List<Scene> getScenes() {
        return scenes;
    }

    public void setScenes(List<Scene> scenes) {
        this.scenes = scenes;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recommend_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Scene scene = scenes.get(position);
        Glide.with(activity)
                .load(scene.getThumbimg())
                .into(holder.sceneimg);
    }

    @Override
    public int getItemCount() {
        return scenes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView sceneimg;
//        public ImageView likeImageView;
//        public ImageView dislikeImageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            sceneimg = (ImageView) itemView.findViewById(R.id.sceneimg);
//            likeImageView = (ImageView) itemView.findViewById(R.id.iv_like);
//            dislikeImageView = (ImageView) itemView.findViewById(R.id.iv_dislike);
        }
    }
}

package com.ljr.travel.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.guoxiaoxing.phoenix.core.PhoenixOption;
import com.guoxiaoxing.phoenix.core.model.MediaEntity;
import com.guoxiaoxing.phoenix.core.model.MimeType;
import com.guoxiaoxing.phoenix.picker.Phoenix;
import com.ljr.travel.Adapter.MediaAdapter;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.REditText;
import com.unstoppable.submitbuttonview.SubmitButton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WriteCommentActivity extends AppCompatActivity implements MediaAdapter.OnAddMediaListener {
    @BindView(R.id.provincename)
    REditText provincename;
    @BindView(R.id.cityname)
    REditText cityname;
    @BindView(R.id.scenename)
    REditText scenename;
    @BindView(R.id.commentscore)
    REditText commentscore;
    @BindView(R.id.commenttext)
    REditText commenttext;
    @BindView(R.id.commentimg)
    RecyclerView commentimg;
    @BindView(R.id.publish_comment)
    SubmitButton publishComment;
    private MediaAdapter mediaAdapter;
    private int REQUEST_CODE = 0x000111;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String name = "", district = "", province = "", sceneid = "";
    private String username;
    private static final String TAG = "WriteCommentActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_comment);
        ButterKnife.bind(this);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        Intent intent = getIntent();
        if (intent != null) {
            name = intent.getStringExtra("scenename");
            district = intent.getStringExtra("district");
            province = intent.getStringExtra("province");
            sceneid = intent.getStringExtra("sceneid");
        }
        initial();
    }

    private void initial() {
        username = sharedPreferences.getString("username", "");
        provincename.setText(this.province);
        cityname.setText(this.district);
        scenename.setText(this.name);
        commentimg.setLayoutManager(new GridLayoutManager(WriteCommentActivity.this, 4, RecyclerView.VERTICAL, false));
        if (mediaAdapter == null) {
            mediaAdapter = new MediaAdapter(WriteCommentActivity.this);
        }
        commentimg.setAdapter(mediaAdapter);
        mediaAdapter.setOnItemClickListener(new MediaAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                if (mediaAdapter.getData().size() > 0) {
                    //预览
                    Phoenix.with()
                            .pickedMediaList(mediaAdapter.getData())
                            .start(WriteCommentActivity.this, PhoenixOption.TYPE_BROWSER_PICTURE, 0);
                }
            }
        });
    }

    @Override
    public void onaddMedia() {
        Phoenix.with()
                .theme(PhoenixOption.THEME_BLUE)// 主题
                .fileType(MimeType.ofImage())//显示的文件类型图片、视频、图片和视频
                .maxPickNumber(10)// 最大选择数量
                .minPickNumber(0)// 最小选择数量
                .spanCount(4)// 每行显示个数
                .enablePreview(true)// 是否开启预览
                .enableCamera(true)// 是否开启拍照
                .enableAnimation(true)// 选择界面图片点击效果
                .enableCompress(true)// 是否开启压缩
                .compressPictureFilterSize(1024)//多少kb以下的图片不压缩
                .compressVideoFilterSize(2018)//多少kb以下的视频不压缩
                .thumbnailHeight(160)// 选择界面图片高度
                .thumbnailWidth(160)// 选择界面图片宽度
                .enableClickSound(false)// 是否开启点击声音
                .pickedMediaList(mediaAdapter.getData())// 已选图片数据
                .videoFilterTime(30)//显示多少秒以内的视频
                .mediaFilterSize(10000)//显示多少kb以下的图片/视频，默认为0，表示不限制
                .start(WriteCommentActivity.this, PhoenixOption.TYPE_PICK_MEDIA, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            //返回的数据
            List<MediaEntity> result = Phoenix.result(data);
            mediaAdapter.setData(result);
        }
    }

    //    @OnClick(R.id.comment_publish)
//    public void onCommentPublishClicked() {
//        Log.d(TAG, "onCommentPublishClicked: " + this.username);
//        Calendar calendar = Calendar.getInstance();
//        long time = calendar.getTime().getTime() / 1000;
//        ArrayList<String> imgLists = new ArrayList<String>();
//        List<MediaEntity> results = mediaAdapter.getData();
//        String path;
//        File file;
//        String fileName;
//        MediaEntity mediaEntity;
//        int fileType;
//        for (int i = 0; i < results.size(); i++) {
//            mediaEntity = results.get(i);
//            path = mediaEntity.getFinalPath();
//            file = new File(path);
//            fileName = file.getName();
//            fileType = mediaEntity.getFileType();
//            if (fileType == 1) {
//                imgLists.add(fileName);
//            }
//            RequestBody requestBody = new MultipartBody.Builder()
//                    .setType(MultipartBody.FORM)
//                    .addFormDataPart("username", username)
//                    .addFormDataPart("filename", fileName,
//                            RequestBody.create(MediaType.parse(mediaEntity.getMimeType()), file))
//                    .build();
//            Request request = new Request.Builder().url(App.uploadImgadd).post(requestBody).build();
//            OkHttpClient client = new OkHttpClient();
//            client.newCall(request).enqueue(new Callback() {
//                @Override
//                public void onFailure(Call call, IOException e) {
//                    Log.d(TAG, "onFailure: " + e.toString());
//
//                }
//
//                @Override
//                public void onResponse(Call call, Response response) throws IOException {
//
//                }
//            });
//        }
//        String commenttext = this.commenttext.getText().toString(),
//                score = this.commentscore.getText().toString();
//        double s = Double.parseDouble(score);
//        JSONArray array = new JSONArray(imgLists);
////        Comment comment = new Comment(this.sceneid,this.username, BaseUtil.formatTime(time),commenttext,s,imgLists);
//        HttpUtil.uploadComment(App.uploadCommentAddress, this.sceneid, s, this.username, "" + time
//                , commenttext, array.toString(), new Callback() {
//                    @Override
//                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
//                        Log.d(TAG, "onFailure: " + e.toString());
//                        BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分失败");
//
//                    }
//
//                    @Override
//                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
//                        String res = response.body().string();
//                        if (res.equals("success")) {
//                            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分成功");
//                        } else if (res.equals("fail")) {
//                            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分失败");
//
//                        }
//                    }
//                });
//    }
    @OnClick(R.id.commentimg)
    public void onCommentimgClicked() {
    }

    @OnClick(R.id.publish_comment)
    public void onPublishCommentClicked() {
        Log.d(TAG, "onCommentPublishClicked: " + this.username);
        Calendar calendar = Calendar.getInstance();
        long time = calendar.getTime().getTime() / 1000;
        ArrayList<String> imgLists = new ArrayList<String>();
        List<MediaEntity> results = mediaAdapter.getData();
        String path;
        File file;
        String fileName;
        MediaEntity mediaEntity;
        int fileType;
        for (int i = 0; i < results.size(); i++) {
            mediaEntity = results.get(i);
            path = mediaEntity.getFinalPath();
            file = new File(path);
            fileName = file.getName();
            fileType = mediaEntity.getFileType();
            if (fileType == 1) {
                imgLists.add(fileName);
            }
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("username", username)
                    .addFormDataPart("filename", fileName,
                            RequestBody.create(MediaType.parse(mediaEntity.getMimeType()), file))
                    .build();
            Request request = new Request.Builder().url(App.uploadImgadd).post(requestBody).build();
            OkHttpClient client = new OkHttpClient();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.d(TAG, "onFailure: " + e.toString());
                    BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分失败");
                    publishComment.doResult(false);
                    return;
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                }
            });
        }
        String commenttext = this.commenttext.getText().toString(),
                score = this.commentscore.getText().toString();
        if (score==null ||score.length()==0) {
            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "评分不能为空，发表失败");
            publishComment.reset();

            return ;
        }
        double s = Double.parseDouble(score);
        if ((s<0||s>5)) {
            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "评分不能小于0或大于5，发表失败");
            publishComment.reset();
            return ;
        }
        JSONArray array = new JSONArray(imgLists);
        HttpUtil.uploadComment(App.uploadCommentAddress, this.sceneid, s, this.username, "" + time
                , commenttext, array.toString(), new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Log.d(TAG, "onFailure: " + e.toString());
                        BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分失败",publishComment);
                        publishComment.doResult(false);
//                        setBtnState(false);

                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        String res = response.body().string();
                        if (res.equals("success")) {
                            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分成功",publishComment);
//                            publishComment.doResult(true);
                            setBtnState(true);

                        } else if (res.equals("fail")) {
                            BaseUtil.showDialog(WriteCommentActivity.this, "提示", "发表评分失败",publishComment);
//                            publishComment.doResult(false);
                            setBtnState(false);

                        } else if (res.equals("exist")) {
                            BaseUtil.showDialog(WriteCommentActivity.this, "提示"
                                    , "只能对同一景点评论一次，评论失败",publishComment);
//                            publishComment.doResult(false);
                            setBtnState(false);
                        }
                    }
                });
    }

    public void setBtnState(boolean flag) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                publishComment.doResult(flag);

            }
        });
    }
}

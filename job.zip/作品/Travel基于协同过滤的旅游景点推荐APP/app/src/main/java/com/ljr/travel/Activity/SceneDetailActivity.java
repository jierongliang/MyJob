package com.ljr.travel.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.assionhonty.lib.assninegridview.AssNineGridView;
import com.assionhonty.lib.assninegridview.AssNineGridViewClickAdapter;
import com.assionhonty.lib.assninegridview.ImageInfo;
import com.ljr.travel.Adapter.CommentAdapter;
import com.ljr.travel.Adapter.MyPagerAdapter;
import com.ljr.travel.Bean.Comment;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.Bean.TC;
import com.ljr.travel.R;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class SceneDetailActivity extends AppCompatActivity {
    private static final String TAG = "SceneDetailActivity";
    @BindView(R.id.scene_provincename)
    RTextView sceneProvincename;
    @BindView(R.id.scene_name)
    RTextView sceneName;
    @BindView(R.id.scene_cityname)
    RTextView sceneCityname;
    @BindView(R.id.scene_img)
    AssNineGridView sceneImg;
    @BindView(R.id.scene_address)
    RTextView sceneAddress;
    @BindView(R.id.scene_star)
    RTextView sceneStar;
    @BindView(R.id.scene_score)
    RTextView sceneScore;
    @BindView(R.id.scene_commentNum)
    RTextView sceneCommentNum;
    @BindView(R.id.scene_price)
    RTextView scenePrice;

    @BindView(R.id.scene_time)
    RTextView sceneTime;
    @BindView(R.id.scene_traffic)
    RTextView sceneTraffic;
    @BindView(R.id.scene_web_phone)
    RTextView sceneWebPhone;
    @BindView(R.id.scene_description)
    RTextView sceneDescription;
    @BindView(R.id.scene_tags)
    RTextView sceneTags;
    @BindView(R.id.write_comment)
    RImageView writeComment;
    @BindView(R.id.commentRecyclerview)
    RecyclerView commentRecyclerview;
    @BindView(R.id.magic_indicator)
    MagicIndicator magicIndicator;
    @BindView(R.id.recommend_viewpager)
    ViewPager recommendViewpager;
    private ArrayList<TC> recommends;
    private String sceneid;
    private Scene scenedata = new Scene();
    private ArrayList<Comment> commentArrayList ;
    private CommentAdapter adapter;
    private MyPagerAdapter pagerAdapter;
    private CommonNavigator mCommonNavigator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scene_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        if (intent != null) {
            sceneid = intent.getStringExtra("sceneid");
//            Log.d(TAG, "onCreate: " + sceneid);
        }
        initialData();
        initialComment();
        initialRecommend();
    }

    public void initialRecommend() {
        if (recommends == null) {
            recommends = new ArrayList<>();
        }
        if (pagerAdapter == null) {
            pagerAdapter = new MyPagerAdapter(recommends);
        }
        if (mCommonNavigator == null) {
            mCommonNavigator = new CommonNavigator(this);
        }
        magicIndicator.setBackgroundColor(Color.parseColor("#5F9EA0"));
        recommendViewpager.setAdapter(pagerAdapter);
        mCommonNavigator.setAdapter(new CommonNavigatorAdapter() {

            @Override
            public int getCount() {
                return recommends.size();
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ColorTransitionPagerTitleView(context);
                simplePagerTitleView.setNormalColor(Color.parseColor("#7FFFAA"));
                simplePagerTitleView.setSelectedColor(Color.parseColor("#4169E1"));
                simplePagerTitleView.setText(recommends.get(index).getName());
                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recommendViewpager.setCurrentItem(index);
                    }
                });
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator linePagerIndicator = new LinePagerIndicator(context);
                linePagerIndicator.setMode(LinePagerIndicator.MODE_MATCH_EDGE);
                linePagerIndicator.setColors(Color.parseColor("#7B68EE"));
                return linePagerIndicator;
            }
        });
        magicIndicator.setNavigator(mCommonNavigator);
        ViewPagerHelper.bind(magicIndicator, recommendViewpager);
        HttpUtil.queryRecommend(App.queryTagRecommend, this.sceneid, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: "+e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    JSONObject object ;
                    String name,address,cityname,provincename,tagsStr;
                    ArrayList<String> tags;
                    TC tc;
                    ArrayList<TC> tcs = new ArrayList<>();
                    for(int i=0;i<array.length()  ;i++){
                        object = array.getJSONObject(i);
                        name = object.getString("name");
                        address = object.getString("address");
                        cityname = object.getString("cityname");
                        provincename = object.getString("provincename");
                        tagsStr = object.getString("tags");
                        tags = parseStrtoArray(tagsStr);
                        tc = new TC(name,cityname,provincename,address,tags);
                        tcs.add(tc);
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "run: asf123 "+recommends.size());
                            recommends.clear();
                            recommends.addAll(tcs);
                            mCommonNavigator.notifyDataSetChanged();
                            recommendViewpager.getAdapter().notifyDataSetChanged();
//                            pagerAdapter.notifyDataSetChanged();
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: "+e.toString());
                }

            }
        });
    }
    public ArrayList<String> parseStrtoArray(String source){
        try {
            JSONArray array = new JSONArray(source);
            ArrayList<String> res = new ArrayList<>();
            for(int i=0;i<array.length()  ;i++){
                res.add(array.getString(i));
            }
            return res;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;

    }
    public void initialComment() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        commentRecyclerview.setLayoutManager(manager);
        DividerItemDecoration divider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        divider.setDrawable(ContextCompat.getDrawable(this, R.drawable.custom_divider));
        commentRecyclerview.addItemDecoration(divider);
        if (commentArrayList == null) {
            commentArrayList = new ArrayList<>();
        }
        if (adapter == null) {
            adapter = new CommentAdapter(commentArrayList, SceneDetailActivity.this);

        }
        commentRecyclerview.setAdapter(adapter);
        HttpUtil.querySceneComment(App.querySceneCommentadd, this.sceneid, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String result = response.body().string();
                String name, commenttext, imgs, time;
                double score;
                Comment comment;
                ArrayList<String> img;
                ArrayList<Comment> comments = new ArrayList<>();
                try {
                    JSONArray array = new JSONArray(result);
                    Log.d(TAG, "onResponse: 333" + array.length());
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        name = object.getString("name");
                        commenttext = object.getString("commenttext");
//                        Log.d(TAG, "onResponse: 1111");
//                        imgs = object.getString("imgs");
                        imgs = object.optString("imgs");
//                        Log.d(TAG, "onResponse: img+ljr+"+imgs);
                        img = parseImg(imgs);
//                        Log.d(TAG, "onResponse: 222");
                        time = object.getString("time");
                        score = object.getDouble("score");
                        comment = new Comment(name, time, commenttext, score, img);
                        comments.add(comment);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            commentArrayList.clear();
                            commentArrayList.addAll(comments);
//                            Log.d(TAG, "run: add" + commentArrayList.size());
                            adapter.notifyDataSetChanged();
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }


            }
        });

    }

    public ArrayList<String> parseImg(String imgs) {
        ArrayList<String> res = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(imgs);
            for (int i = 0; i < array.length(); i++) {
                res.add(array.getString(i));
            }
            return res;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return res;
    }

    public void initialData() {
        HttpUtil.querySceneData(App.querySceneDetailadd, this.sceneid, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                Log.d(TAG, "onResponse: 123" + res);
                String name, address, star, time, traffic, price, score,
                        officialweb, phone, cityname, provincename, description;
                int commentNum;
                String temp;
                ArrayList<String> imgUrl = new ArrayList<>(), tags = new ArrayList<>(),
                        features = new ArrayList<>();
                Scene scene;
                JSONArray array;
                try {
                    JSONObject object = new JSONObject(res);
                    name = object.getString("name");
                    address = object.getString("address");
                    star = object.getString("star");
                    time = object.getString("time");
                    traffic = object.getString("traffic");
                    score = object.getString("score");
                    price = object.getString("price");
                    officialweb = object.getString("officialweb");
                    phone = object.getString("phone");
                    cityname = object.getString("cityname");
                    provincename = object.getString("provincename");
                    description = object.getString("description");
                    commentNum = object.getInt("commentNum");
                    array = object.getJSONArray("imgUrl");
                    for (int i = 0; i < array.length(); i++) {
                        imgUrl.add(array.getString(i));
                    }
                    array = object.getJSONArray("tags");
                    for (int i = 0; i < array.length(); i++) {
                        tags.add(array.getString(i));
                    }
//                    array = object.getJSONArray("features");
//                    if (array.length()==0) {
//                        features.add("无特色");
//                    }
//                    else{
//                        for(int i=0;i<array.length()  ;i++){
//                            features.add(array.getString(i));
//                        }
//                    }

                    scene = new Scene(name, address, star, time, traffic,
                            price, score, officialweb, phone, cityname, provincename,
                            description, sceneid, commentNum, imgUrl, tags);
                    scenedata = scene;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            sceneName.setText(scenedata.getName());
                            sceneCityname.setText(scenedata.getCityname());
                            sceneProvincename.setText(scenedata.getProvincename());
                            sceneAddress.setText(scenedata.getAddress());
                            sceneStar.setText("星级:" + scenedata.getStar());
                            sceneScore.setText(scenedata.getScore() + "分");
                            sceneCommentNum.setText(scenedata.getCommentNum() + "条评论");
                            scenePrice.setText(scenedata.getPrice() + "元");
                            sceneTime.setText("开放时间:" + scenedata.getTime());
                            sceneTraffic.setText("交通:" + scenedata.getTraffic());
                            sceneDescription.setText("详细介绍:" + scenedata.getDescription());
                            sceneWebPhone.setText("电话|官网:" + scenedata.getPhone() + " | " + scenedata.getOfficialweb());
                            StringBuilder builder = new StringBuilder();
                            for (String s : scenedata.getTags()) {
                                builder.append(s + " | ");
                            }
                            sceneTags.setText("标签:" + builder.toString());
                            sceneImg.setAdapter(new AssNineGridViewClickAdapter(SceneDetailActivity.this, getImageInfos(scenedata)));
                        }
                    });
                    Log.d(TAG, "onResponse: 489787" + scene);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }

            }
        });

    }

    public List<ImageInfo> getImageInfos(Scene scene) {
        ArrayList<String> imgs = scene.getImgUrl();
        List<ImageInfo> imageInfos = new ArrayList<>();
        for (String url : imgs) {
            ImageInfo imageInfo = new ImageInfo();
            imageInfo.setBigImageUrl(url);
            imageInfo.setThumbnailUrl(url);
            imageInfos.add(imageInfo);
        }
        return imageInfos;
    }


    @OnClick(R.id.write_comment)
    public void onWriteCommentClicked() {
        Intent intent = new Intent(this, WriteCommentActivity.class);
        intent.putExtra("scenename", this.sceneName.getText());
        intent.putExtra("province", this.sceneProvincename.getText());
        intent.putExtra("district", this.sceneCityname.getText());
        intent.putExtra("sceneid", this.sceneid);
        startActivity(intent);
    }
}

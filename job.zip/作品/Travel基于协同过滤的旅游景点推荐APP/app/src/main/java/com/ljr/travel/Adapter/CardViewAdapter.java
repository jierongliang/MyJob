package com.ljr.travel.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ruffian.library.widget.RImageView;
import com.ruffian.library.widget.RTextView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CardViewAdapter extends BaseAdapter {
    private ArrayList<Scene> scenes;
    private Activity activity;

    public CardViewAdapter(ArrayList<Scene> scenes) {
        this.scenes = scenes;
    }

    public CardViewAdapter(ArrayList<Scene> scenes, Activity activity) {
        this.scenes = scenes;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return scenes == null ? 0 : scenes.size();
    }

    @Override
    public Object getItem(int position) {
        return scenes == null ? null : scenes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Scene scene = (Scene) getItem(position); // 获取当前项的Fruit实例
        View view;
        ViewHolder viewHolder;
        if (convertView == null) {
            view = LayoutInflater.from(activity).inflate(R.layout.cardview_item, parent, false);
            viewHolder = new ViewHolder(view);
            viewHolder.cardThumbimg = (RImageView) view.findViewById(R.id.card_thumbimg);
            viewHolder.cardName = (RTextView) view.findViewById(R.id.card_name);
            viewHolder.cardAddress = (RTextView) view.findViewById(R.id.card_address);
            viewHolder.cardScore = (RTextView) view.findViewById(R.id.card_score);
            viewHolder.cardCommentNum = (RTextView) view.findViewById(R.id.card_commentNum);
            viewHolder.cardDistance = (RTextView) view.findViewById(R.id.card_distance);
            viewHolder.cardNumber = (RTextView) view.findViewById(R.id.card_number);
            view.setTag(viewHolder); // 将ViewHolder存储在View中
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag(); // 重新获取ViewHolder
        }
        Glide.with(activity)
                .load(scene.getThumbimg())
                .override(200, 100)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(viewHolder.cardThumbimg);
        viewHolder.cardName.setText(scene.getName());
        viewHolder.cardAddress.setText(scene.getAddress());
        viewHolder.cardScore.setText(scene.getScore() + "分");
        viewHolder.cardCommentNum.setText(scene.getCommentNum() + "条评论");
        viewHolder.cardDistance.setText("距离市中心" + BaseUtil.formadDistance(scene.getDistanceDis())+"\n距离省中心" + BaseUtil.formadDistance(scene.getDistancePro()));
        int temp = position+1;
        viewHolder.cardNumber.setText(temp+"/"+scenes.size());
        return view;
    }




    class ViewHolder {
        @BindView(R.id.card_thumbimg)
        RImageView cardThumbimg;
        @BindView(R.id.card_name)
        RTextView cardName;
        @BindView(R.id.card_address)
        RTextView cardAddress;
        @BindView(R.id.card_score)
        RTextView cardScore;
        @BindView(R.id.card_commentNum)
        RTextView cardCommentNum;
        @BindView(R.id.card_distance)
        RTextView cardDistance;
        @BindView(R.id.card_number)
        RTextView cardNumber;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}

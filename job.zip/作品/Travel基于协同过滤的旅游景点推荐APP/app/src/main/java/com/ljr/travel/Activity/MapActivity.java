package com.ljr.travel.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.kongzue.dialog.v3.Notification;
import com.kongzue.dialog.v3.TipDialog;
import com.ljr.travel.MainActivity;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.unstoppable.submitbuttonview.SubmitButton;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
public class MapActivity extends AppCompatActivity {
    @BindView(R.id.map)
    MapView mMapView;
    @BindView(R.id.save_btn)
    SubmitButton saveBtn;
    private AMap aMap = null;
    private static final String TAG = "MapActivity";
    private Marker marker;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private LatLng location;
    private int data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Intent intent = getIntent();
        if (intent != null) {
            this.data = intent.getIntExtra("data", 0);
        }
        ButterKnife.bind(this);
        mMapView.onCreate(savedInstanceState);
        if (aMap == null) {
            aMap = mMapView.getMap();
        }
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        initialLocation();
        marker = addMarker();
        MyLocationStyle myLocationStyle;
        myLocationStyle = new MyLocationStyle();//初始化定位蓝点样式类myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);//连续定位、且将视角移动到地图中心点，定位点依照设备方向旋转，并且会跟随设备移动。（1秒1次定位）如果不设置myLocationType，默认也会执行此种模式。
        myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATE);
        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
        aMap.setMyLocationEnabled(true);

//        MyLocationStyle myLocationStyle;
//        myLocationStyle = new MyLocationStyle();
//        myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATE);
//        myLocationStyle.showMyLocation(true);
//        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
//        aMap.setMyLocationEnabled(true);
        aMap.moveCamera(CameraUpdateFactory.changeLatLng(location));
        aMap.moveCamera(CameraUpdateFactory.zoomTo(15));
    }
    public void initialLocation() {
        float f1 = sharedPreferences.getFloat("latitude", 39.906901f);
        float f2 = sharedPreferences.getFloat("longitude", 116.397972f);
        location = new LatLng(f1, f2);
    }
    public Marker addMarker() {
        MarkerOptions markerOption = new MarkerOptions();
//        LatLng latLng = new LatLng(39.906901, 116.397972);
        markerOption.position(location);
        markerOption.title("自定义位置");
        markerOption.draggable(true);//设置Marker可拖动
        markerOption.icon(BitmapDescriptorFactory.fromBitmap(BitmapFactory
                .decodeResource(getResources(), R.drawable.custom_marker)));
        // 将Marker设置为贴地显示，可以双指下拉地图查看效果
        markerOption.setFlat(true);//设置marker平贴地图效果
        Marker marker = aMap.addMarker(markerOption);
//        Animation animation = new RotateAnimation(marker.getRotateAngle(), marker.getRotateAngle() + 180, 0, 0, 0);
//        long duration = 1000L;
//        animation.setDuration(duration);
//        animation.setInterpolator(new LinearInterpolator());
//        marker.setAnimation(animation);
//        marker.startAnimation();
        AMap.OnMarkerDragListener markerDragListener = new AMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {
            }
            @Override
            public void onMarkerDrag(Marker marker) {
            }
            @Override
            public void onMarkerDragEnd(Marker marker) {
                LatLng latLng1 = marker.getPosition();
                Log.d(TAG, "onMarkerDragEnd: latitude" + latLng1.latitude + " longitude" + latLng1.longitude);
            }
        };
        aMap.setOnMarkerDragListener(markerDragListener);
        aMap.getUiSettings().setMyLocationButtonEnabled(true);
        return marker;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，销毁地图
        mMapView.onDestroy();
        if (data == 1) {
            Intent intent = new Intent(this, CustomRecommendActivity2.class);
            startActivity(intent);
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (data == 1) {
            Intent intent = new Intent(this, CustomRecommendActivity2.class);
            startActivity(intent);
            finish();
        } else if (data == 2) {
            Intent intent = new Intent(this, LocateActivity.class);
            startActivity(intent);
            finish();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView.onResume ()，重新绘制加载地图
        mMapView.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView.onPause ()，暂停地图的绘制
        mMapView.onPause();
    }
    public void saveLatlng() {
        LatLng latLng1 = marker.getPosition();
        double latitude = latLng1.latitude,
                longitude = latLng1.longitude;
        editor.putFloat("latitude", (float) latitude);
        editor.putFloat("longitude", (float) longitude);
        editor.apply();
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //在activity执行onSaveInstanceState时执行mMapView.onSaveInstanceState (outState)，保存地图当前的状态
        mMapView.onSaveInstanceState(outState);
    }
    @OnClick(R.id.save_btn)
    public void onSaveBtnClicked() {
        saveLatlng();
        BaseUtil.showCustomTipDialog(MapActivity.this, "保存自定义位置成功", TipDialog.TYPE.SUCCESS);
        saveBtn.doResult(true);
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        saveBtn.reset();
                    }
                });
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, 2000);
    }
//    MyLocationStyle myLocationStyle;
//    myLocationStyle = new MyLocationStyle();//初始化定位蓝点样式类myLocationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATION_ROTATE);//连续定位、且将视角移动到地图中心点，定位点依照设备方向旋转，并且会跟随设备移动。（1秒1次定位）如果不设置myLocationType，默认也会执行此种模式。
//        myLocationStyle.interval(2000); //设置连续定位模式下的定位间隔，只在连续定位模式下生效，单次定位模式下不会生效。单位为毫秒。
//        aMap.setMyLocationStyle(myLocationStyle);//设置定位蓝点的Style
//        aMap.setMyLocationEnabled(true);//
//    Marker locationMarker;
//    private LocationSource.OnLocationChangedListener mListener;
//    boolean useMoveToLocationWithMapMode = true;
//    Projection projection;
//    private AMapLocationClient mlocationClient;
//    private AMapLocationClientOption mLocationOption;
//    @Override
//    public void onLocationChanged(AMapLocation amapLocation) {
//        Log.e("amap", "onMyLocationChange 定位成功， lat: " + amapLocation.getLatitude() + " lon: " + amapLocation.getLongitude());
//        if (mListener != null && amapLocation != null) {
//            if (amapLocation != null
//                    && amapLocation.getErrorCode() == 0) {
//                LatLng latLng = new LatLng(amapLocation.getLatitude(), amapLocation.getLongitude());
//                //展示自定义定位小蓝点
//                if(locationMarker == null) {
//                    //首次定位
//                    locationMarker = aMap.addMarker(new MarkerOptions().position(latLng)
//                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.location_marker))
//                            .anchor(0.5f, 0.5f));
//                    //首次定位,选择移动到地图中心点并修改级别到15级
//                    aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
//                } else {
//                    if(useMoveToLocationWithMapMode) {
//                        //二次以后定位，使用sdk中没有的模式，让地图和小蓝点一起移动到中心点（类似导航锁车时的效果）
//                        startMoveLocationAndMap(latLng);
//                    } else {
//                        startChangeLocation(latLng);
//                    }
//                }
//            } else {
//                String errText = "定位失败," + amapLocation.getErrorCode()+ ": " + amapLocation.getErrorInfo();
//                Log.e("AmapErr",errText);
//            }
//        }
//    }
//    private void startMoveLocationAndMap(LatLng latLng) {
//        //将小蓝点提取到屏幕上
//        if(projection == null) {
//            projection = aMap.getProjection();
//        }
//        if(locationMarker != null && projection != null) {
//            LatLng markerLocation = locationMarker.getPosition();
//            Point screenPosition = aMap.getProjection().toScreenLocation(markerLocation);
//            locationMarker.setPositionByPixels(screenPosition.x, screenPosition.y);
//        }
//        //移动地图，移动结束后，将小蓝点放到放到地图上
//        myCancelCallback.setTargetLatlng(latLng);
//        //动画移动的时间，最好不要比定位间隔长，如果定位间隔2000ms 动画移动时间最好小于2000ms，可以使用1000ms
//        //如果超过了，需要在myCancelCallback中进行处理被打断的情况
//        aMap.animateCamera(CameraUpdateFactory.changeLatLng(latLng),1000,myCancelCallback);
//    }
//    private void startChangeLocation(LatLng latLng) {
//        if(locationMarker != null) {
//            LatLng curLatlng = locationMarker.getPosition();
//            if(curLatlng == null || !curLatlng.equals(latLng)) {
//                locationMarker.setPosition(latLng);
//            }
//        }
//    }
//    MyCancelCallback myCancelCallback = new MyCancelCallback();
//    @Override
//    public void onTouch(MotionEvent motionEvent) {
//        Log.i("amap","onTouch 关闭地图和小蓝点一起移动的模式");
//        useMoveToLocationWithMapMode = false;
//    }
//    /**
//     * 监控地图动画移动情况，如果结束或者被打断，都需要执行响应的操作
//     */
//    class MyCancelCallback implements AMap.CancelableCallback {
//        LatLng targetLatlng;
//        public void setTargetLatlng(LatLng latlng) {
//            this.targetLatlng = latlng;
//        }
//        @Override
//        public void onFinish() {
//            if(locationMarker != null && targetLatlng != null) {
//                locationMarker.setPosition(targetLatlng);
//            }
//        }
//        @Override
//        public void onCancel() {
//            if(locationMarker != null && targetLatlng != null) {
//                locationMarker.setPosition(targetLatlng);
//            }
//        }
//    };
//    /**
//     * 激活定位
//     */
//    @Override
//    public void activate(OnLocationChangedListener listener) {
//        mListener = listener;
//        if (mlocationClient == null) {
//            mlocationClient = new AMapLocationClient(this);
//            mLocationOption = new AMapLocationClientOption();
//            //设置定位监听
//            mlocationClient.setLocationListener(this);
//            //设置为高精度定位模式
//            mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
//            //是指定位间隔
//            mLocationOption.setInterval(2000);
//            //设置定位参数
//            mlocationClient.setLocationOption(mLocationOption);
//            // 此方法为每隔固定时间会发起一次定位请求，为了减少电量消耗或网络流量消耗，
//            // 注意设置合适的定位时间的间隔（最小间隔支持为2000ms），并且在合适时间调用stopLocation()方法来取消定位请求
//            // 在定位结束后，在合适的生命周期调用onDestroy()方法
//            // 在单次定位情况下，定位无论成功与否，都无需调用stopLocation()方法移除请求，定位sdk内部会移除
//            mlocationClient.startLocation();
//        }
//    }
//    /**
//     * 停止定位
//     */
//    @Override
//    public void deactivate() {
//        mListener = null;
//        if (mlocationClient != null) {
//            mlocationClient.stopLocation();
//            mlocationClient.onDestroy();
//        }
//        mlocationClient = null;
//    }
}

package com.ljr.travel.Bean;
import java.util.ArrayList;
public class Scene {
  private String name,address,star,time,traffic,price,score,
          officialweb,phone,cityname,thumbimg,provincename,description,sceneid;
  private int commentNum;
  private double distanceDis,distancePro,longitude,latitude;
  private ArrayList<String> imgUrl,tags,features;
  private double predictscore;
  public Scene() {
  }
  public Scene(String name, String address, String score, String thumbimg, String provincename, String sceneid,
               int commentNum, double distanceDis, double distancePro, double ppscore,double latitude,double longitude) {
    super();
    this.name = name;
    this.address = address;
    this.score = score;
    this.thumbimg = thumbimg;
    this.provincename = provincename;
    this.sceneid = sceneid;
    this.commentNum = commentNum;
    this.distanceDis = distanceDis;
    this.distancePro = distancePro;
    this.predictscore = ppscore;
    this.latitude = latitude;
    this.longitude = longitude;
  }
  public Scene(String name, String address, String score, String thumbimg, String provincename, String sceneid,
               int commentNum, double distanceDis, double distancePro, double ppscore) {
    super();
    this.name = name;
    this.address = address;
    this.score = score;
    this.thumbimg = thumbimg;
    this.provincename = provincename;
    this.sceneid = sceneid;
    this.commentNum = commentNum;
    this.distanceDis = distanceDis;
    this.distancePro = distancePro;
    this.predictscore = ppscore;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getPredictscore() {
    return predictscore;
  }

  public void setPredictscore(double predictscore) {
    this.predictscore = predictscore;
  }

  public Scene(String name, String address, String score, String thumbimg, String provincename, String sceneid, int commentNum, double distanceDis, double distancePro) {
    this.name = name;
    this.address = address;
    this.score = score;
    this.thumbimg = thumbimg;
    this.sceneid = sceneid;
    this.provincename = provincename;
    this.commentNum = commentNum;
    this.distanceDis = distanceDis;
    this.distancePro = distancePro;
  }

  public Scene(String name, String address, String star, String time, String traffic, String price, String score,
               String officialweb, String phone, String cityname, String provincename, String description, String sceneid,
               int commentNum, ArrayList<String> imgUrl, ArrayList<String> tags) {
    super();
    this.name = name;
    this.address = address;
    this.star = star;
    this.time = time;
    this.traffic = traffic;
    this.price = price;
    this.score = score;
    this.officialweb = officialweb;
    this.phone = phone;
    this.cityname = cityname;
    this.provincename = provincename;
    this.description = description;
    this.sceneid = sceneid;
    this.commentNum = commentNum;
    this.imgUrl = imgUrl;
    this.tags = tags;

  }
  public double getDistanceDis() {
    return distanceDis;
  }
  public void setDistanceDis(double distanceDis) {
    this.distanceDis = distanceDis;
  }
  public double getDistancePro() {
    return distancePro;
  }
  public void setDistancePro(double distancePro) {
    this.distancePro = distancePro;
  }
  public Scene(String name, String star, String score, String thumbimg, int commentNum, double distanceDis,
               double distancePro,String sceneid) {
    super();
    this.name = name;
    this.star = star;
    this.score = score;
    this.thumbimg = thumbimg;
    this.commentNum = commentNum;
    this.distanceDis = distanceDis;
    this.distancePro = distancePro;
    this.sceneid = sceneid;
  }
  public Scene(String name, String star, String score, String thumbimg, int commentNum, double distanceDis,
               double distancePro,String sceneid,double latitude,double longitude) {
    super();
    this.name = name;
    this.star = star;
    this.score = score;
    this.thumbimg = thumbimg;
    this.commentNum = commentNum;
    this.distanceDis = distanceDis;
    this.distancePro = distancePro;
    this.sceneid = sceneid;
    this.latitude = latitude;
    this.longitude = longitude;
  }
  public String getPrice() {
    return price;
  }
  public void setPrice(String price) {
    this.price = price;
  }
  public String getScore() {
    return score;
  }
  public void setScore(String score) {
    this.score = score;
  }

  @Override
  public String toString() {
    return "Scene{" +
            "name='" + name + '\'' +
            ", address='" + address + '\'' +
            ", star='" + star + '\'' +
            ", time='" + time + '\'' +
            ", traffic='" + traffic + '\'' +
            ", price='" + price + '\'' +
            ", score='" + score + '\'' +
            ", officialweb='" + officialweb + '\'' +
            ", phone='" + phone + '\'' +
            ", cityname='" + cityname + '\'' +
            ", thumbimg='" + thumbimg + '\'' +
            ", provincename='" + provincename + '\'' +
            ", description='" + description + '\'' +
            ", sceneid='" + sceneid + '\'' +
            ", commentNum=" + commentNum +
            ", distanceDis=" + distanceDis +
            ", distancePro=" + distancePro +
            ", longitude=" + longitude +
            ", latitude=" + latitude +
            ", imgUrl=" + imgUrl +
            ", tags=" + tags +
            ", features=" + features +
            ", predictscore=" + predictscore +
            '}';
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getStar() {
    return star;
  }
  public void setStar(String star) {
    this.star = star;
  }
  public String getTime() {
    return time;
  }
  public void setTime(String time) {
    this.time = time;
  }
  public String getTraffic() {
    return traffic;
  }
  public void setTraffic(String traffic) {
    this.traffic = traffic;
  }
  public String getOfficialweb() {
    return officialweb;
  }
  public void setOfficialweb(String officialweb) {
    this.officialweb = officialweb;
  }
  public String getPhone() {
    return phone;
  }
  public void setPhone(String phone) {
    this.phone = phone;
  }
  public String getCityname() {
    return cityname;
  }
  public void setCityname(String cityname) {
    this.cityname = cityname;
  }
  public String getThumbimg() {
    return thumbimg;
  }
  public void setThumbimg(String thumbimg) {
    this.thumbimg = thumbimg;
  }
  public String getProvincename() {
    return provincename;
  }
  public void setProvincename(String provincename) {
    this.provincename = provincename;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public int getCommentNum() {
    return commentNum;
  }
  public void setCommentNum(int commentNum) {
    this.commentNum = commentNum;
  }
  public String getSceneid() {
    return sceneid;
  }
  public void setSceneid(String sceneid) {
    this.sceneid = sceneid;
  }
  public ArrayList<String> getImgUrl() {
    return imgUrl;
  }
  public void setImgUrl(ArrayList<String> imgUrl) {
    this.imgUrl = imgUrl;
  }
  public ArrayList<String> getTags() {
    return tags;
  }
  public void setTags(ArrayList<String> tags) {
    this.tags = tags;
  }
}

//package com.ljr.travel.Bean;
//import java.util.ArrayList;
//public class Scene {
//    private String name,address,star,time,traffic,price,score,
//            officialweb,phone,cityname,thumbimg,provincename,description,sceneid;
//    private int commentNum;
//    private double distanceDis,distancePro;
//    private ArrayList<String> imgUrl,tags,features;
//    public Scene() {
//    }
//    public Scene(String name, String address, String star, String time, String traffic, String price, String score,
//                 String officialweb, String phone, String cityname, String provincename, String description, String sceneid,
//                 int commentNum, ArrayList<String> imgUrl, ArrayList<String> tags, ArrayList<String> features) {
//        super();
//        this.name = name;
//        this.address = address;
//        this.star = star;
//        this.time = time;
//        this.traffic = traffic;
//        this.price = price;
//        this.score = score;
//        this.officialweb = officialweb;
//        this.phone = phone;
//        this.cityname = cityname;
//        this.provincename = provincename;
//        this.description = description;
//        this.sceneid = sceneid;
//        this.commentNum = commentNum;
//        this.imgUrl = imgUrl;
//        this.tags = tags;
//        this.features = features;
//    }
//    public double getDistanceDis() {
//        backk distanceDis;
//    }
//    public void setDistanceDis(double distanceDis) {
//        this.distanceDis = distanceDis;
//    }
//    public double getDistancePro() {
//        backk distancePro;
//    }
//    public void setDistancePro(double distancePro) {
//        this.distancePro = distancePro;
//    }
//    public Scene(String name, String star, String score, String thumbimg, int commentNum, double distanceDis,
//                 double distancePro,String sceneid) {
//        super();
//        this.name = name;
//        this.star = star;
//        this.score = score;
//        this.thumbimg = thumbimg;
//        this.commentNum = commentNum;
//        this.distanceDis = distanceDis;
//        this.distancePro = distancePro;
//        this.sceneid = sceneid;
//    }
//    public String getPrice() {
//        backk price;
//    }
//    public void setPrice(String price) {
//        this.price = price;
//    }
//    public String getScore() {
//        backk score;
//    }
//    public void setScore(String score) {
//        this.score = score;
//    }
//    @Override
//    public String toString() {
//        backk "Scene{" +
//                "name='" + name + '\'' +
//                ", address='" + address + '\'' +
//                ", star='" + star + '\'' +
//                ", time='" + time + '\'' +
//                ", feactures='" + features + '\'' +
//                ", traffic='" + traffic + '\'' +
//                ", officialweb='" + officialweb + '\'' +
//                ", phone='" + phone + '\'' +
//                ", cityname='" + cityname + '\'' +
//                ", thumbimg='" + thumbimg + '\'' +
//                ", provincename='" + provincename + '\'' +
//                ", description='" + description + '\'' +
//                ", commentNum=" + commentNum +
//                ", sceneid=" + sceneid +
//                ", score=" + score +
//                ", price=" + price +
//                ", imgUrl=" + imgUrl +
//                ", tags=" + tags +
//                '}';
//    }
//    public String getName() {
//        backk name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public String getAddress() {
//        backk address;
//    }
//    public void setAddress(String address) {
//        this.address = address;
//    }
//    public String getStar() {
//        backk star;
//    }
//    public void setStar(String star) {
//        this.star = star;
//    }
//    public String getTime() {
//        backk time;
//    }
//    public void setTime(String time) {
//        this.time = time;
//    }
//    public String getTraffic() {
//        backk traffic;
//    }
//    public void setTraffic(String traffic) {
//        this.traffic = traffic;
//    }
//    public String getOfficialweb() {
//        backk officialweb;
//    }
//    public void setOfficialweb(String officialweb) {
//        this.officialweb = officialweb;
//    }
//    public String getPhone() {
//        backk phone;
//    }
//    public void setPhone(String phone) {
//        this.phone = phone;
//    }
//    public String getCityname() {
//        backk cityname;
//    }
//    public void setCityname(String cityname) {
//        this.cityname = cityname;
//    }
//    public String getThumbimg() {
//        backk thumbimg;
//    }
//    public void setThumbimg(String thumbimg) {
//        this.thumbimg = thumbimg;
//    }
//    public String getProvincename() {
//        backk provincename;
//    }
//    public void setProvincename(String provincename) {
//        this.provincename = provincename;
//    }
//    public String getDescription() {
//        backk description;
//    }
//    public void setDescription(String description) {
//        this.description = description;
//    }
//    public int getCommentNum() {
//        backk commentNum;
//    }
//    public void setCommentNum(int commentNum) {
//        this.commentNum = commentNum;
//    }
//    public String getSceneid() {
//        backk sceneid;
//    }
//    public void setSceneid(String sceneid) {
//        this.sceneid = sceneid;
//    }
//    public ArrayList<String> getImgUrl() {
//        backk imgUrl;
//    }
//    public void setImgUrl(ArrayList<String> imgUrl) {
//        this.imgUrl = imgUrl;
//    }
//    public ArrayList<String> getTags() {
//        backk tags;
//    }
//    public void setTags(ArrayList<String> tags) {
//        this.tags = tags;
//    }
//}
///*package com.ljr.travel.Bean;
//import java.util.ArrayList;
//import java.util.Comparator;
//public class Scene  {
//    private String name,address,star,time,feactures,traffic,price,score,
//            officialweb,phone,cityname,thumbimg,provincename,description,sceneid;
//    private int commentNum;
//    private double distanceDis,distancePro;
//    private ArrayList<String> imgUrl,tags;
//    public Scene() {
//    }
//    public double getDistanceDis() {
//        backk distanceDis;
//    }
//    public void setDistanceDis(double distanceDis) {
//        this.distanceDis = distanceDis;
//    }
//    public double getDistancePro() {
//        backk distancePro;
//    }
//    public void setDistancePro(double distancePro) {
//        this.distancePro = distancePro;
//    }
//    public Scene(String name, String star, String score, String thumbimg, int commentNum, double distanceDis,
//                 double distancePro,String sceneid) {
//        super();
//        this.name = name;
//        this.star = star;
//        this.score = score;
//        this.thumbimg = thumbimg;
//        this.commentNum = commentNum;
//        this.distanceDis = distanceDis;
//        this.distancePro = distancePro;
//        this.sceneid = sceneid;
//    }
//    public String getPrice() {
//        backk price;
//    }
//    public void setPrice(String price) {
//        this.price = price;
//    }
//    public String getScore() {
//        backk score;
//    }
//    public void setScore(String score) {
//        this.score = score;
//    }
//    @Override
//    public String toString() {
//        backk "Scene{" +
//                "name='" + name + '\'' +
//                ", address='" + address + '\'' +
//                ", star='" + star + '\'' +
//                ", time='" + time + '\'' +
//                ", feactures='" + feactures + '\'' +
//                ", traffic='" + traffic + '\'' +
//                ", officialweb='" + officialweb + '\'' +
//                ", phone='" + phone + '\'' +
//                ", cityname='" + cityname + '\'' +
//                ", thumbimg='" + thumbimg + '\'' +
//                ", provincename='" + provincename + '\'' +
//                ", description='" + description + '\'' +
//                ", commentNum=" + commentNum +
//                ", sceneid=" + sceneid +
//                ", score=" + score +
//                ", price=" + price +
//                ", imgUrl=" + imgUrl +
//                ", tags=" + tags +
//                '}';
//    }
//    public String getName() {
//        backk name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public String getAddress() {
//        backk address;
//    }
//    public void setAddress(String address) {
//        this.address = address;
//    }
//    public String getStar() {
//        backk star;
//    }
//    public void setStar(String star) {
//        this.star = star;
//    }
//    public String getTime() {
//        backk time;
//    }
//    public void setTime(String time) {
//        this.time = time;
//    }
//    public String getFeactures() {
//        backk feactures;
//    }
//    public void setFeactures(String feactures) {
//        this.feactures = feactures;
//    }
//    public String getTraffic() {
//        backk traffic;
//    }
//    public void setTraffic(String traffic) {
//        this.traffic = traffic;
//    }
//    public String getOfficialweb() {
//        backk officialweb;
//    }
//    public void setOfficialweb(String officialweb) {
//        this.officialweb = officialweb;
//    }
//    public String getPhone() {
//        backk phone;
//    }
//    public void setPhone(String phone) {
//        this.phone = phone;
//    }
//    public String getCityname() {
//        backk cityname;
//    }
//    public void setCityname(String cityname) {
//        this.cityname = cityname;
//    }
//    public String getThumbimg() {
//        backk thumbimg;
//    }
//    public void setThumbimg(String thumbimg) {
//        this.thumbimg = thumbimg;
//    }
//    public String getProvincename() {
//        backk provincename;
//    }
//    public void setProvincename(String provincename) {
//        this.provincename = provincename;
//    }
//    public String getDescription() {
//        backk description;
//    }
//    public void setDescription(String description) {
//        this.description = description;
//    }
//    public int getCommentNum() {
//        backk commentNum;
//    }
//    public void setCommentNum(int commentNum) {
//        this.commentNum = commentNum;
//    }
//    public String getSceneid() {
//        backk sceneid;
//    }
//    public void setSceneid(String sceneid) {
//        this.sceneid = sceneid;
//    }
//    public ArrayList<String> getImgUrl() {
//        backk imgUrl;
//    }
//    public void setImgUrl(ArrayList<String> imgUrl) {
//        this.imgUrl = imgUrl;
//    }
//    public ArrayList<String> getTags() {
//        backk tags;
//    }
//    public void setTags(ArrayList<String> tags) {
//        this.tags = tags;
//    }
//}*/

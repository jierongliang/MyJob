package com.ljr.travel.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.alibaba.fastjson.JSON;
import com.amap.api.maps.model.LatLng;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.ljr.travel.Adapter.CardPagerAdapter;
import com.ljr.travel.Bean.MyHeader;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;
import com.ljr.travel.Util.HttpUtil;
import com.ocnyang.pagetransformerhelp.cardtransformer.RotateDownPageTransformer;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.suke.widget.SwitchButton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import lib.kingja.switchbutton.SwitchMultiButton;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class CustomRecommendActivity2 extends AppCompatActivity {
    @BindView(R.id.card_viewpager)
    ViewPager cardViewpager;
    @BindView(R.id.province_spinner)
    MaterialSpinner provinceSpinner;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.switch_show)
    SwitchButton switchShow;
    private ArrayList<Scene> userscenes;
    private ArrayList<Scene> itemscenes;
    private ArrayList<Scene> slopescenes;
    private ArrayList<Scene> showScenes;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String username;
    private boolean flag1;
    private int flag;
    private static final String TAG = "CustomRecommend2";
    private CardPagerAdapter adapter;
    private String[] provinces = new String[]{"全国", "浙江", "上海", "江苏", "广东", "山东"};
    private SwitchMultiButton switchMultiButton;
    private SwitchMultiButton locationButton;
    private MyHeader header;
    private boolean customLocation;
    private LatLng customLatlng;
    private double customlat;
    private double customlng;
    public List<String> likescenes, dislikescenes;
    private TimerTask task;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_recommend);
        ButterKnife.bind(this);
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        locationButton = (SwitchMultiButton) findViewById(R.id.switch_location);
        switchMultiButton = (SwitchMultiButton) findViewById(R.id.switch_btn);
        initData();
        initialViewPager();
        initialUserRecommendData();
        initialItemRecommendData();
        initialSlopeoneRecommendData();
        initialSwitchBtn();
        initialSpinner();
        initialRefreshLayout();
        loadData();
    }

    private void loadData() {
        task = new TimerTask() {
            @Override
            public void run() {
                String likes, dislikes;
                likes = JSON.toJSONString(likescenes);
                dislikes = JSON.toJSONString(dislikescenes);
                editor.putString("likescenes", likes);
                editor.putString("dislikescenes", dislikes);
                editor.apply();
                Log.d(TAG, "run: like" + likes + " \ndislikes" + dislikes);
                Log.d(TAG, "run: dislikescenes" + dislikescenes);
            }
        };
        timer = new Timer();
        timer.scheduleAtFixedRate(task, 2000, 5000);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        timer.cancel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    public void initData() {
        username = sharedPreferences.getString("username", "");
        customLocation = sharedPreferences.getBoolean("customlocation", false);
        this.customlat = sharedPreferences.getFloat("latitude", 39.906901f);
        this.customlng = sharedPreferences.getFloat("longitude", 116.397972f);
        this.customLatlng = new LatLng(customlat, customlng);
        flag1 = true;
        if (customLocation) {
            locationButton.setSelectedTab(1);
        }
        String temp;
        temp = sharedPreferences.getString("likescenes", "[]");
        likescenes = JSON.parseArray(temp, String.class);
        temp = sharedPreferences.getString("dislikescenes", "[]");
        dislikescenes = JSON.parseArray(temp, String.class);
    }

    public void initialRefreshLayout() {
        refreshLayout.setEnableRefresh(true);//是否启用下拉刷新功能
        refreshLayout.setEnableLoadMore(false);//是否启用上拉加载功能
//        ClassicsHeader.REFRESH_HEADER_REFRESHING = "正在请求刷新基于物品推荐数据....";
//        ClassicsHeader.REFRESH_HEADER_FINISH = "请求刷新基于物品推荐成功，请等待5-15分钟";
//        ClassicsHeader.REFRESH_HEADER_FAILED = "请求刷新基于物品推荐失败";//"刷新失败";
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishRefresh(true);
                int tab = switchMultiButton.getSelectedTab();
                Log.d(TAG, "onRefresh: " + tab);
                if (tab == 0) {
                    Log.d(TAG, "onRefresh: " + tab);
                    HttpUtil.updateDetailUserRecommend(App.updateUserRecommend, CustomRecommendActivity2.this.username, new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            Log.d(TAG, "onFailure: " + e.toString());
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(false);
                                }
                            }, 1000);
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            String res = response.body().string();
                            Log.d(TAG, "onResponse: " + res);
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(true);
                                }
                            }, 1000);
                        }
                    });
                } else if (tab == 1) {
                    HttpUtil.updateDetailItemRecommend(App.updateItemRecommend, CustomRecommendActivity2.this.username, new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            Log.d(TAG, "onFailure: " + e.toString());
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(false);
                                }
                            }, 1000);
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            String res = response.body().string();
                            Log.d(TAG, "onResponse: " + res);
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(true);
                                }
                            }, 1000);
                        }
                    });
                } else if (tab == 2) {
                    HttpUtil.updateDetailSlopeoneRecommend(App.updateSlopeoneRecommend, CustomRecommendActivity2.this.username, new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            Log.d(TAG, "onFailure: " + e.toString());
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(false);
                                }
                            }, 1000);
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            String res = response.body().string();
                            Log.d(TAG, "onResponse: " + res);
                            refreshLayout.getLayout().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    refreshLayout.finishRefresh(true);
                                }
                            }, 1000);
                        }
                    });
                }
            }
        });
        header = new MyHeader(CustomRecommendActivity2.this);
        header.setmTextRefreshing("正在请求刷新基于用户推荐数据....");
        header.setmTextFinish("请求刷新基于用户推荐成功，请等待5-15分钟");
        header.setmTextFailed("请求刷新基于用户推荐失败");
        header.setAccentColor(Color.parseColor("#AAFFEE"));
        header.setPrimaryColor(Color.parseColor("#009FCC"));
        header.setFinishDuration(2500);
        refreshLayout.setRefreshHeader(header);//设置Header
//        refreshLayout.setRefreshFooter(new ClassicsFooter(CustomRecommendActivity2.this));//
    }

    private void initialSwitchBtn() {
        locationButton.setText("默认位置", "自定义位置").setOnSwitchListener(new SwitchMultiButton.OnSwitchListener() {
            @Override
            public void onSwitch(int position, String tabText) {
                if (position == 0) {
                    editor.putBoolean("customlocation", false);
                    editor.apply();
                    adapter.setFlag(false);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                } else if (position == 1) {
                    editor.putBoolean("customlocation", true);
                    editor.apply();
                    adapter.setFlag(true);
                    Intent intent = new Intent(CustomRecommendActivity2.this, MapActivity.class);
                    intent.putExtra("data", 1);
                    startActivity(intent);
                    finish();
                }
            }
        });
        switchMultiButton.setText("基于用户", "基于物品", "Slopeone").setOnSwitchListener(new SwitchMultiButton.OnSwitchListener() {
            @Override
            public void onSwitch(int position, String tabText) {
                if (position == 1) {
//                    flag1 = false;
                    header.setmTextRefreshing("正在请求刷新基于物品推荐数据....");
                    header.setmTextFinish("请求刷新基于物品推荐成功，请等待5-15分钟");
                    header.setmTextFailed("请求刷新基于物品推荐失败");
                    flag = 1;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showScenes.clear();
                            showScenes.addAll(itemscenes);
                            adapter.notifyDataSetChanged();
                            cardViewpager.setCurrentItem(0);
                            provinceSpinner.setSelectedIndex(0);
                        }
                    });
                } else if (position == 0) {
//                    flag1 = true;
                    header.setmTextRefreshing("正在请求刷新基于用户推荐数据....");
                    header.setmTextFinish("请求刷新基于用户推荐成功，请等待5-15分钟");
                    header.setmTextFailed("请求刷新基于用户推荐失败");
                    flag = 2;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showScenes.clear();
                            showScenes.addAll(userscenes);
                            adapter.notifyDataSetChanged();
                            cardViewpager.setCurrentItem(0);
                            provinceSpinner.setSelectedIndex(0);
                        }
                    });
                } else if (position == 2) {
//                    flag1 = true;
                    header.setmTextRefreshing("正在请求刷新Slopeone推荐数据....");
                    header.setmTextFinish("请求刷新Slopeone推荐成功，请等待5-15分钟");
                    header.setmTextFailed("请求刷新Slopeone推荐失败");
                    flag = 3;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showScenes.clear();
                            showScenes.addAll(slopescenes);
                            adapter.notifyDataSetChanged();
                            cardViewpager.setCurrentItem(0);
                            provinceSpinner.setSelectedIndex(0);
                        }
                    });
                }
            }
        });
    }

    private void initialSpinner() {
        provinceSpinner.setItems(provinces);
        provinceSpinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                showScenes.clear();
                Scene scene;
                ArrayList<Scene> temp = new ArrayList<>();

                if (flag == 2) {
                    temp.addAll(userscenes);
                } else if (flag == 1) {
                    temp.addAll(itemscenes);
                } else if (flag == 3) {
                    temp.addAll(slopescenes);
                }
                if (item.equals("全国")) {
                    showScenes.addAll(temp);
                } else {
                    if (switchShow.isChecked()) {
                        for (int i = 0; i < temp.size(); i++) {
                            scene = temp.get(i);
                            if (scene.getProvincename().equals(item) && (!dislikescenes.contains(scene.getSceneid()))) {
                                showScenes.add(scene);
                            }
                        }
                    } else {
                        for (int i = 0; i < temp.size(); i++) {
                            scene = temp.get(i);
                            if (scene.getProvincename().equals(item)) {
                                showScenes.add(scene);
                            }
                        }
                    }

                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                        cardViewpager.setCurrentItem(0);

                    }
                });
            }
        });
    }

    private void initialSlopeoneRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.querySlopeRecommend(App.querySlopeoneRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    double predictscore, longitude, latitude;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    slopescenes.clear();
                    slopescenes.addAll(datas);
                    Collections.sort(slopescenes, new PredictScoreComparator());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }

    public void initialItemRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.queryItemRecommend(App.queryItemRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    double predictscore, longitude, latitude;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    itemscenes.clear();
                    itemscenes.addAll(datas);
                    Collections.sort(itemscenes, new PredictScoreComparator());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }

    public void initialViewPager() {
        cardViewpager.setOffscreenPageLimit(5);
        cardViewpager.setPageMargin(5);
//        cardViewpager.setPageTransformer(true, new AlphaPageTransformer());
        cardViewpager.setPageTransformer(true, new RotateDownPageTransformer());
        if (userscenes == null) {
            userscenes = new ArrayList<>();
        }
        if (itemscenes == null) {
            itemscenes = new ArrayList<>();
        }
        if (slopescenes == null) {
            slopescenes = new ArrayList<>();
        }
        if (showScenes == null) {
            showScenes = new ArrayList<>();
        }
        if (adapter == null) {
            adapter = new CardPagerAdapter(showScenes, CustomRecommendActivity2.this);
        }
        adapter.setShowdislike(!switchShow.isChecked());
        switchShow.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                if (isChecked) {
                    Log.d(TAG, "onCheckedChanged:  before showscenes" + showScenes.size() + "dislikescenes size " + dislikescenes.size());
                    ArrayList<Scene> temp = new ArrayList<>();
                    for (int i = 0; i < showScenes.size(); i++) {
                        Scene scene = showScenes.get(i);
                        String sceneid = scene.getSceneid();
                        if (!dislikescenes.contains(sceneid)) {
                            temp.add(scene);
                        }

                    }
                    showScenes.clear();
                    showScenes.addAll(temp);
                    Log.d(TAG, "onCheckedChanged:  after showscenes" + showScenes.size() + "dislikescenes size " + dislikescenes.size());
                    adapter.notifyDataSetChanged();
                } else {
                    int tab = switchMultiButton.getSelectedTab();
                    if (tab == 0) {
                        showScenes.clear();
                        showScenes.addAll(userscenes);
                        adapter.notifyDataSetChanged();
                        cardViewpager.setCurrentItem(0);
                        provinceSpinner.setSelectedIndex(0);
                    } else if (tab == 1) {
                        showScenes.clear();
                        showScenes.addAll(itemscenes);
                        adapter.notifyDataSetChanged();
                        cardViewpager.setCurrentItem(0);
                        provinceSpinner.setSelectedIndex(0);

                    } else if (tab == 2) {
                        showScenes.clear();
                        showScenes.addAll(slopescenes);
                        adapter.notifyDataSetChanged();
                        cardViewpager.setCurrentItem(0);
                        provinceSpinner.setSelectedIndex(0);

                    }
                }
            }
        });
//        ArrayList<String> temp = new ArrayList<>();
//        temp.addAll(likescenes);
        adapter.setLikescenes(likescenes);
//        ArrayList<String> temp2 = new ArrayList<>();
//
//        temp2.addAll(dislikescenes);
        adapter.setDislikescenes(dislikescenes);
        adapter.setFlag(customLocation);
        adapter.setLatLng(customLatlng);
        cardViewpager.setAdapter(adapter);
        cardViewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    public void initialUserRecommendData() {
        String temp = sharedPreferences.getString("username", "");
        HttpUtil.queryUserRecommend(App.queryUserRecommend, temp, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String res = response.body().string();
                try {
                    JSONArray array = new JSONArray(res);
                    String thumbimg, name, address, score, provincename, sceneid;
                    int commentNum;
                    double citydis, prodis;
                    Scene scene;
                    ArrayList<Scene> datas = new ArrayList<>();
                    JSONObject object;
                    double predictscore, longitude, latitude;
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < array.length(); i++) {
                        object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        builder.append(name);
                        provincename = object.getString("provincename");
                        sceneid = object.getString("sceneid");
                        address = object.getString("address");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        predictscore = object.getDouble("predictscore");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, address, score, thumbimg, provincename, sceneid, commentNum, citydis, prodis, predictscore, latitude, longitude);
                        datas.add(scene);
                    }
                    Log.d(TAG, "onResponse: finish" + builder.toString());
                    userscenes.clear();
                    userscenes.addAll(datas);
                    Collections.sort(userscenes, new PredictScoreComparator());
                    showScenes.clear();
                    showScenes.addAll(userscenes);
                    Collections.sort(showScenes, new PredictScoreComparator());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }

    public List<String> getLikescenes() {
        return likescenes;
    }

    public void setLikescenes(List<String> likescenes) {
        this.likescenes = likescenes;
    }

    public List<String> getDislikescenes() {
        return dislikescenes;
    }

    public void setDislikescenes(List<String> dislikescenes) {
        this.dislikescenes = dislikescenes;
    }
}

class PredictScoreComparator implements Comparator<Scene> {
    @Override
    public int compare(Scene o1, Scene o2) {
        double score1 = o1.getPredictscore(),
                score2 = o2.getPredictscore();
        if (score1 < score2) {
            return 1;
        } else if (score2 < score1) {
            return -1;
        }
        return 0;
    }
}
//    private CardViewAdapter adapter;
//    @BindView(R.id.cardview)
//    InfiniteCardView cardview;
//    private int[] resId = {R.mipmap.pic1, R.mipmap.pic2, R.mipmap.pic3, R.mipmap
//            .pic4, R.mipmap.pic5};
//        initialCardView();
//        mAdapter1 = new MyAdapter(resId);
//        mAdapter2 = new MyAdapter(resId);
//        cardview.setAdapter(mAdapter1);
//        setStyle1();
//
//    private void setStyle1() {
//        cardview.setClickable(true);
//        cardview.setAnimType(InfiniteCardView.ANIM_TYPE_FRONT);
//        cardview.setAnimInterpolator(new LinearInterpolator());
//        cardview.setTransformerToFront(new DefaultTransformerToFront());
//        cardview.setTransformerToBack(new DefaultTransformerToBack());
//        cardview.setZIndexTransformerToBack(new DefaultZIndexTransformerCommon());
//    }
//
//    private BaseAdapter mAdapter1, mAdapter2;
//
//    private static class MyAdapter extends BaseAdapter {
//        private int[] resIds = {};
//
//        MyAdapter(int[] resIds) {
//            this.resIds = resIds;
//        }
//
//        @Override
//        public int getCount() {
//            backk resIds.length;
//        }
//
//        @Override
//        public Integer getItem(int position) {
//            backk resIds[position];
//        }
//
//        @Override
//        public long getItemId(int position) {
//            backk position;
//        }
//
//        @Override
//        public View getView(int position, View convertView, ViewGroup parent) {
//            if (convertView == null) {
//                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout
//                        .item_card, parent, false);
//            }
//            convertView.setBackgroundResource(resIds[position]);
//            backk convertView;
//        }
//    }
//
//    private void setStyle2() {
//        mCardView.setClickable(true);
//        mCardView.setAnimType(InfiniteCardView.ANIM_TYPE_SWITCH);
//        mCardView.setAnimInterpolator(new OvershootInterpolator(-18));
//        mCardView.setTransformerToFront(new DefaultTransformerToFront());
//        mCardView.setTransformerToBack(new AnimationTransformer() {
//            @Override
//            public void transformAnimation(View view, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                int positionCount = fromPosition - toPosition;
//                float scale = (0.8f - 0.1f * fromPosition) + (0.1f * fraction * positionCount);
//                view.setScaleX(scale);
//                view.setScaleY(scale);
//                if (fraction < 0.5) {
//                    view.setRotationX(180 * fraction);
//                } else {
//                    view.setRotationX(180 * (1 - fraction));
//                }
//            }
//
//            @Override
//            public void transformInterpolatedAnimation(View view, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                int positionCount = fromPosition - toPosition;
//                float scale = (0.8f - 0.1f * fromPosition) + (0.1f * fraction * positionCount);
//                view.setTranslationY(-cardHeight * (0.8f - scale) * 0.5f - cardWidth * (0.02f *
//                        fromPosition - 0.02f * fraction * positionCount));
//            }
//        });
//        mCardView.setZIndexTransformerToBack(new ZIndexTransformer() {
//            @Override
//            public void transformAnimation(CardItem card, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                if (fraction < 0.4f) {
//                    card.zIndex = 1f + 0.01f * fromPosition;
//                } else {
//                    card.zIndex = 1f + 0.01f * toPosition;
//                }
//            }
//
//            @Override
//            public void transformInterpolatedAnimation(CardItem card, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//
//            }
//        });
//    }
//
//    private void setStyle3() {
//        mCardView.setClickable(false);
//        mCardView.setAnimType(InfiniteCardView.ANIM_TYPE_FRONT_TO_LAST);
//        mCardView.setAnimInterpolator(new OvershootInterpolator(-8));
//        mCardView.setTransformerToFront(new DefaultCommonTransformer());
//        mCardView.setTransformerToBack(new AnimationTransformer() {
//            @Override
//            public void transformAnimation(View view, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                int positionCount = fromPosition - toPosition;
//                float scale = (0.8f - 0.1f * fromPosition) + (0.1f * fraction * positionCount);
//                view.setScaleX(scale);
//                view.setScaleY(scale);
//                if (fraction < 0.5) {
//                    view.setTranslationX(cardWidth * fraction * 1.5f);
//                    view.setRotationY(-45 * fraction);
//                } else {
//                    view.setTranslationX(cardWidth * 1.5f * (1f - fraction));
//                    view.setRotationY(-45 * (1 - fraction));
//                }
//            }
//
//            @Override
//            public void transformInterpolatedAnimation(View view, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                int positionCount = fromPosition - toPosition;
//                float scale = (0.8f - 0.1f * fromPosition) + (0.1f * fraction * positionCount);
//                view.setTranslationY(-cardHeight * (0.8f - scale) * 0.5f - cardWidth * (0.02f *
//                        fromPosition - 0.02f * fraction * positionCount));
//            }
//        });
//        mCardView.setZIndexTransformerToBack(new ZIndexTransformer() {
//            @Override
//            public void transformAnimation(CardItem card, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//                if (fraction < 0.5f) {
//                    card.zIndex = 1f + 0.01f * fromPosition;
//                } else {
//                    card.zIndex = 1f + 0.01f * toPosition;
//                }
//            }
//
//            @Override
//            public void transformInterpolatedAnimation(CardItem card, float fraction, int cardWidth, int cardHeight, int fromPosition, int toPosition) {
//
//            }
//        });
//    }

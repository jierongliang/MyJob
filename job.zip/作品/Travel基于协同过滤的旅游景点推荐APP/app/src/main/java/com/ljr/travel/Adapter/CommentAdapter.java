package com.ljr.travel.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.assionhonty.lib.assninegridview.AssNineGridView;
import com.assionhonty.lib.assninegridview.AssNineGridViewClickAdapter;
import com.assionhonty.lib.assninegridview.ImageInfo;
import com.ljr.travel.Activity.App;
import com.ljr.travel.Bean.Comment;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ruffian.library.widget.RTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {
    private List<Comment> comments;
    private AppCompatActivity activity;
    private HashMap<Integer,String> nameMap;
    public CommentAdapter(List<Comment> comments, AppCompatActivity activity) {
        this.comments = comments;
        this.activity = activity;
        nameMap = null;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Comment comment = comments.get(position);
            if(nameMap!=null){
                holder.commentName.setText(nameMap.get(Integer.parseInt(comment.getSceneid())));
            }
            else {
                holder.commentName.setText(comment.getName());
            }
            holder.commentScore.setText("评分:"+comment.getScore());
            long time = Long.parseLong(comment.getTime());
            holder.commentTime.setText(BaseUtil.formatTime(time));
            String text = comment.getCommenttext();
            if (text.length() == 0) {
                holder.commentText.setVisibility(View.GONE);
            }
            else{
                holder.commentText.setVisibility(View.VISIBLE);
                holder.commentText.setText("评语:"+text);
            }
            ArrayList<String> imgs = comment.getImgs();
            if (imgs.size() > 0) {
                holder.commentImg.setAdapter(new AssNineGridViewClickAdapter(activity,getImageInfos(imgs,comment.getName())));
            }
            else{
                holder.commentImg.setVisibility(View.GONE);
            }
    }
    @Override
    public int getItemCount() {
        return comments.size();
    }
    public List<ImageInfo> getImageInfos(ArrayList<String> imgs,String username) {
        String temp = "http://"+ App.ipaddress+":80/"+username+"/";
        List<ImageInfo> imageInfos = new ArrayList<>();
        for (String url : imgs) {
            ImageInfo imageInfo = new ImageInfo();
            imageInfo.setBigImageUrl(temp+url);
            imageInfo.setThumbnailUrl(temp+url);
            imageInfos.add(imageInfo);
        }
        return imageInfos;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        private AssNineGridView commentImg;
        private RTextView commentName,commentTime,commentScore,commentText;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            commentImg = (AssNineGridView) itemView.findViewById(R.id.comment_image);

            commentName = (RTextView) itemView.findViewById(R.id.comment_name);
            commentTime = (RTextView) itemView.findViewById(R.id.comment_time);
            commentScore = (RTextView) itemView.findViewById(R.id.comment_score);
            commentText = (RTextView) itemView.findViewById(R.id.comment_text);
        }
    }

    public HashMap<Integer, String> getNameMap() {
        return nameMap;
    }

    public void setNameMap(HashMap<Integer, String> nameMap) {
        this.nameMap = nameMap;
    }
}

package com.ljr.travel.Bean;

import java.util.ArrayList;

public class TC {
    private String name;
    private String sceneid;
    private String cityname;
    private String provincename;
    private String address;
    private ArrayList<String> tags;



    public TC(String name, String cityname, String provincename, String address, ArrayList<String> tags) {
        this.name = name;
        this.cityname = cityname;
        this.provincename = provincename;
        this.address = address;
        this.tags = tags;
    }

    public ArrayList<String> getTags() {
        return tags;
    }

    public void setTags(ArrayList<String> tags) {
        this.tags = tags;
    }

    public TC(String name, String sceneid, String tags, String cityname, String provincename, String address) {
        super();
        this.name = name;
        this.sceneid = sceneid;
        this.cityname = cityname;
        this.provincename = provincename;
        this.address = address;
    }

    public TC() {
        super();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSceneid() {
        return sceneid;
    }

    public void setSceneid(String sceneid) {
        this.sceneid = sceneid;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getProvincename() {
        return provincename;
    }

    public void setProvincename(String provincename) {
        this.provincename = provincename;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

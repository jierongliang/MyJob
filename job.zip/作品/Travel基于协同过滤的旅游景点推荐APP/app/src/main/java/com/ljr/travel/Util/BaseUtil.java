package com.ljr.travel.Util;
import android.app.Activity;
import android.content.DialogInterface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.amap.api.maps.AMapUtils;
import com.amap.api.maps.model.LatLng;
import com.kongzue.dialog.v3.MessageDialog;
import com.kongzue.dialog.v3.TipDialog;
import com.ljr.travel.Activity.RegisterActivity;
import com.unstoppable.submitbuttonview.SubmitButton;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
public class BaseUtil {
    public static void showDialog(AppCompatActivity activity, String title, String message){
        AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
        dialog.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.show();
            }
        });
    }
    public static void showDialog(AppCompatActivity activity, String title, String message,SubmitButton btn){
        AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
        dialog.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        btn.reset();
                    }
                });
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.show();
            }
        });
    }
    public static float calculateDistance(float f1,float f2,float f3,float f4){
        LatLng latLng1 = new LatLng(f1,f2),
                latLng2 = new LatLng(f3,f4);
        float distance = AMapUtils.calculateLineDistance(latLng1,latLng2);
        return distance;
    }
    public static String formadDistance(double distance){
        if (distance<=1000.0d) {
            int t = (int)distance;
            return t+"米";
        }
        else if(distance<=10000.0d){
            distance = distance/1000;
            BigDecimal d = new BigDecimal(distance);
            double d1 = d.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
            return d1+"千米";
        }
        else {
            distance = distance/10000;
            BigDecimal d = new BigDecimal(distance);
            double d1 = d.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
            return d1+"万米";
        }
    }
    public static String formatTime(long time){
        Calendar c1 = Calendar.getInstance();
        long current = c1.getTime().getTime()/1000;
        Calendar c2 = Calendar.getInstance();
        c2.set(c1.get(Calendar.YEAR),c1.get(Calendar.MONTH),c1.get(Calendar.DATE),
                0,0,0);
        long time2 = c2.getTime().getTime()/1000;
        Calendar c3 = Calendar.getInstance();
        c3.set(c1.get(Calendar.YEAR),c1.get(Calendar.MONTH),1,
                0,0,0);
        long time3 = c3.getTime().getTime()/1000;
        Calendar c4 = Calendar.getInstance();
        c4.set(c1.get(Calendar.YEAR),0,1,
                0,0,0);
        long time4 = c4.getTime().getTime()/1000;
        long gap;
        String res = "";
        //1小时
        if ((current-time)<3600) {
            gap = (current-time)/60;
            res = ""+gap+"分钟前";
        }
        //大于一小时 在今天之内 显示今天的时间 17:32
        else if (time>time2) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
            Date date = new Date();
            date.setTime(time*1000);
            res = dateFormat.format(date);
        }
        //大于1天 在本月内
        else if(time>time3){
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd");
            Date date = new Date();
            date.setTime(time*1000);
            res = dateFormat.format(date);
        }
        //这一年内
        else{
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            date.setTime(time*1000);
            res = dateFormat.format(date);
        }
        return res;
    }
    protected static AlertDialog showAlertDialog(Activity activity, @Nullable String title, @Nullable String message,
                                                 @Nullable DialogInterface.OnClickListener onPositiveButtonClickListener,
                                                 @NonNull String positiveText,
                                                 @Nullable DialogInterface.OnClickListener onNegativeButtonClickListener,
                                                 @NonNull String negativeText) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(positiveText, onPositiveButtonClickListener);
        builder.setNegativeButton(negativeText, onNegativeButtonClickListener);
        return  builder.show();
    }
    public static String tagStr = "自然景观 观光 自然风光 摄影 休闲 建筑人文 名胜古迹 山岳/山岭 古迹 亲子同乐 4A景区 场馆院所 城市公园 国家级文物保护单位 展馆展览 赏花 踏青 森林 温泉 城市观光 宗教场所 湖泊 避暑 寺庙 科普 童趣 主题乐园 古建筑 博物馆 主题公园 历史建筑 娱乐 徒步 特色街区 玩水 地质地貌 登山 度假村 山川 美食 瀑布 动植物园 朝拜 5A景区 休闲公园 峡谷 运动 园林 国家级风景名胜区 洞穴 国家级森林公园 3A景区 演出演艺 国家公园 赏枫 名人故居 漂流 植物园 购物 展览馆 广场 游轮游船 农家乐 优秀旅游城市 乡村 美食街 水上乐园 高空景观 红色旅游 购物街 国家级地质公园 海洋馆 草原 民俗村 动物园 纪念馆 情侣约会 滑雪 海滨 世界文化遗产 桥 赏梅花 现代建筑 水族馆 古城 国家级自然保护区 学府 遗址 泡吧 SPA 历史文化名城 文化旅游区 赏樱花 江河 观景台 古镇 疗养 会议 游乐园 道观/道场 历史文化名村（镇） 古塔 影视基地 自然保护区 滑雪场 海岛 食蟹 梦幻休闲 礁石/岩石 农场 宫殿 赏桃花 泉 陵墓 采摘 湿地公园 酒吧街 探险 郊野公园 儿童乐园 教堂 祠堂 影视城 省会城市 科技馆 池塘 省/市级文物保护单位 小镇 水上运动 古城墙 艺术区 省/市级风景名胜区 石刻 图书馆 古楼 骑马 世界级地质公园 海滨城市 赏油菜花 创意园区 港口/港湾 雪山 2A景区 美术馆 运动场馆 世界自然遗产 喷泉 军事遗址 赏鱼 火山 省/市级自然保护区 夜玩推荐 冰川 赏荷花 花园/庭院 骑行 冲浪 水利工程 缆车/索道 大学 早订优惠 塔林 夜生活 石碑 现代都市 古道 极限 酒庄/酒厂 文化 古都 清真寺 丹霞地貌 纪念碑 浮潜 蜡像馆 摩天轮 体育馆 世界生态圈保护区 灯塔 白鲸表演 时尚购物都市 公交直达 石窟 其他 沙漠 音乐厅 岩溶地貌 世界文化与自然双重遗产 电视塔 休闲度假城市 歌剧院 异域建筑 军事基地 宋城千古情 骑马场 室内乐园 赏花踏青 大熊猫 冰雪世界 体育场 海底隧道 会馆 孔家府邸 古代军事博物馆 赌场 明清建筑 动物表演 雅丹地貌 前卫建筑 团队拓展 电影院 透明观光廊 养生温泉 机器人世界 仿古建筑 历史 十里银滩 世界文化景观 江岸美景 海洋科普 俯瞰上海 市级森林公园 海蚀地貌 海峡/峡湾 清明上河图 冰川遗迹 热带雨林 酒吧 海洋温泉 超现实情景 山间漫步 水利景观 恒温水乐园 深海体验 骑楼建筑 唯美海岛 水上汇演 星光夜场 盛唐风貌 四色旅游 大片拍摄 壁画艺术 天然温泉 大水法遗址 赏郁金香 赏红叶 满洲里国门 佛教胜地 特色体验 江南风情 园林式温泉 自然之旅 五岳独秀 城市地标 徒步大自然 文化名楼 露天温泉 摩崖石刻 茅盾故居 龙泉探梅 人文景观 大屿山景观 码头文化 蜿蜒湿地 桂林山水 佛教圣地 海上观光 露营地 竹林风光 热播剧取景 城堡 实景演出 世界之最 电影主题体验 七星灵石 热带天堂 升旗仪式 赛车场 农家乐主题 投影盛演 傣民俗文化 消暑胜地 帝王别宫 武大赏樱 奇峰秀水 婚纱摄影 海滨风光 千瀑奇观 重庆夜景 隐身石蛙 观赏活珊瑚 1A景区 喀斯特地貌 散步 梦幻花谷 世外桃源 汉城堡 主席雕像 奇石遍布 汉唐风格 岩洞景观 金山寺 露天浴场 奇峰怪石 沈万三故居 小桥流水 洋人街 地主庄园 观光潜艇 以险名天下 餐饮娱乐 四大梅园之首 奇树异葩 陶然亭 巴厘岛风情 名人陵寝 自然灾害教育 精彩马戏 黄教寺院 湿地鸟类 深海探秘 洞天福地 花卉培育 恐龙遗址 铭记历史 赏枫胜地 滟湖 测试数据 氧吧温泉 神奇龟峰 梯田景观 沙滩排球 玻璃温室 奇山怪石 美女大熊猫 火山流纹岩 珍稀动植物 海景轿箱 高台建筑 峰岩树影 恐龙欢乐王国 动物表演团 定向越野 石林奇观 环溪观鱼 西山石景 百里丹霞 电影主题 炎黄子孙圣坛 荷塘月色 民俗展示 奇山灵水 江南韵味 唐风建筑 江南古庙 远足 啤酒工艺 雷峰夕照 千瀑之乡 地中海风情 蹦极 卧龙岗 侗族村寨 山园交融 逛店 瓯江蓬莱 白堤 花精灵城堡 庙岛妈祖 沙雕故乡 洗肺健身游 航海文明 明清风情 上海滩传奇 孔子鸟 民国风基地 禅宗禅意 地下古民居 一窝三龙 漓江风光 名人诗刻 京杭运河 文教建筑群 醉翁亭 美龄宫 珊瑚海 民族药物区 高原明珠 冰火两重天 杭州之肾 88米大佛 行宫遗址 赏梅圣地 金陵四大名胜 帝王别苑 古蜀文化 医疗卤水 百合公园 人工湖 绿色明珠 空气干净 岭南风格 东南第一山 佛教建筑 丝绸古道 清朝古街 中西合璧 民国风情 水上游览 盛唐风采 四季恒温 山水实景演出 名陵之首 村落 文化古街 恢弘殿宇 世界遗产 花车巡演 老子峰 古城地标 微型世界 重回大唐 天南锁钥 农业观光 徽州文化 城镇 绿色淡水湖 古老缆车 水月岩云 魅力古城 胡杨古树 爱情圣地 园林艺术 浪漫风情温泉 珠江夜景 商旅公园 展览演出 百年企业 再现圆明园 湖景温泉 恬适雅阁 客家名镇 大漠风光 沙白滩平 瀑布风景 驼峰夕照 紫香花田 千山大佛 岭南名汤 密林探险 梦想生活方式展 睦南道 阿拉伯公园 高科技互动 红色人文 龙泉寺 射电望远镜 漂流之乡 凭栏阅江 商业中心 国画产业 活水温泉 玉关天堑 地质遗迹 环境安宁 观音道场 山海相融 鲸豚表演 美人潭 猕猴岛屿 溥仪展馆 四大名园 动漫体验 五重塔 基辅航母 返璞归真 蝴蝶奇观 海上浮动游泳池 恒温水公园 赏牡丹 十大名山 郊野森林 大关帝庙 帆船运动 汉代建筑 冰川地貌 大冰瀑布 宋朝胜景 蚕丝名镇 看明星 道教建筑群 科幻探险 观潮胜地 谯望楼 互动式体验 生物标本 仿古乐园 火山生态 惊奇洞穴 中原小九寨 空气疗场 文化遗产 魔幻表演 贝壳标本 石竹寺 职业体验 山水结合 古董车 另类文化 皇家陵墓 舞台建筑 秦始皇射雕 帝王御苑 梅花天下奇 影视取景地 特色建筑 历史名楼 岩溶山水 耒水水源 金愿桥 瀑布群落 文化古镇 画里乡村 环流河 红楼荣国府 峡谷山石 意大利建筑 禅修 赏樱 室内滑雪场 滑板冲浪 河畔风光 虢山岛 海豚表演 张艺谋作品 一港两岛 省/市级地质公园 古河护城 人工天河 百年金街 古寨遗风 喀斯特景观 古老寺庙 宫殿建筑 土法筑湖 空中漫步 花木休闲 桂林水上游 极速漂流 彩虹游乐园 姜太公垂钓 帝师故居 衲田花海 生态温泉 侨村风采 皇宫故址 地下暗河 名人蜡像 省级森林公园 佛教文化 梨园胜地 大肚弥勒 观景勇士漂 明皇陵之首 碧浪金沙 中外荧幕经典 宜兴三洞 竹叶碑 水上迷宫 民族英雄 神奇地貌 大盂鼎 悬空栈道 气模城堡 鲜花之旅 上川岛飞沙滩 垒土之台 湖中生花 庭院建筑 英雄之山 清官文化 东方画卷 划船 盛世风韵 水下剧场 热带风情 百花齐放 童梦奇泉 道教名山 艺术 山水相依 世界湿地 王者鲸鲨 火车文化 赛马场 藏品丰富 丹麦风情 远眺中原 农家乐趣 牛郎织女 乾隆墨迹 深切峡谷 迎客松 仿古建筑群 填海造地 还原红楼梦 古城标志 武侠文化 黎苗文化 扬子鳄主题 塞上明珠 诗人旧居 健康能量场 拱形大坝 名人体验馆 深宫探幽 梦幻刺激 向日葵公园 真沙海滩 夜景迷人 特色泡池 欧式风情 人文分界线 赏花胜地 地下漂流 玻璃迷宫 珍禽名兽 三峡文化 水母观赏 龙洞琪林 建筑遗产 自由采摘区 帝王陵寝 巨大水族馆 球幕体验 薰衣草花田 观赏竹海 海滩绵长 狮牛斗 十大文化 渔村古厝 象鼻山形 风沙地貌 古长城遗址 五亭桥 滨海湿地 戒坛 戏曲艺术 仙女瀑布 明代园林 道教文化 白鹭盘旋 书法艺术 蒙古风情 古迹寻觅 花溪 吴文化 众山之王 古意盎然 逼真石景 竞技滑雪 禅宗文化 仙山佛国 腾云驾雾 金色地毯 薰衣草 六朝文化 台州府城墙 酒文化博物馆 崇祯自缢 将军林 剑池 勇士全程漂 百兽狂欢 北国水乡 高原水库 抗美援朝 草原风情 名人祠堂 双铧犁海 鸟类天堂 广州之肾 高空观海 土司文化 道家圣地 老牌公园 避暑圣地 温泉度假 绝美瀑布 慈寿塔 海鲜市场 泛舟湖上 梦幻竹海 释迦摩尼像 森林氧吧 度假式小镇 养生 皇家寺院 三国古街 实景舞台 巴人文化 佛像雕刻 国内首辆 历史名居 科幻体验 攀岩 贝聿铭作品 苏州四大 礼佛圣地 金色垛田 四季雪场 奇险第一山 亚热带植物 欧式建筑 峰石峻秀 自然村寨 玻璃天桥 潘安祠 清代民宅 海浪冲击 竹筏漂流 净月神秀 高空飞翔 腾飞武汉 三教名山 苗族建筑 独特湖景 峰会主场馆 雪的盛宴 石湖串月 深圳地标 震天雷瀑布 科技体验 歪脖老母 科举考场 异域风情 鱼类天堂 观潮圣地 岭南园林 空中田园 假山王国 馆藏丰富 北国江南 四季花海 “福”字碑 周文化 客家美食 民族图腾 道教圣地 水域表演 大佛瀑布 玉柱潭 长安寺 长城博物馆 都市花海 聪明泉 专业级体验 天下雄关 文人荟萃 海底风光 地势险要 地热资源 赏凌空峭壁 阳光海洋馆 历史名巷 天河飞瀑 观赏草海龙 奇石怪岩 雪岭云杉林 漂浮体验 沙漠奇观 军事码头 气势雄伟 泰山文化 儿童游艺 丹霞奇峰 猛兽投食 奇迹花海 武强古城 海浪池 秦陵历险 情景体验 五月的凤 奇幻海洋 美人鱼表演 夜游体验 佛教古刹 瀑布山景 高原训练场 古代城垣 报晓峰 寺庙遗址 郁金香花海 木筏漂流 石佛雕刻 三星堆文化 充水溶洞 跨国景观 臻品紫薇园 山林动物园 革命纪念地 吴越文化 南海观音 香草王国 吉尼斯纪录 古建筑群 探险王国 泉水文化节 华灯魅影 篝火和酒吧 御竹林 候鸟放飞 纪念建筑群 华夏精华 未来水母馆 清凉海水 珍禽异兽 赏银杏 温泉客栈 军事城防 海洋生物表演 五条瀑布 穿越黄浦江 瑞云寺 茂密森林 鬼国京都 火车西餐厅 瓜果故乡 情境体验 禅乐馆 海上明珠 梦幻水母宫 江边夜景 松鼠王国 溶洞景观 芦花湖 道教宫观 原始生态 植被密布 红尾护头鲿 其牌楼 跨江索道 珠澳夜景 美丽森林 踏水冲浪";
    public static float calculateDistance(LatLng latLng1,LatLng latLng2){
        return AMapUtils.calculateLineDistance(latLng1,latLng2);
    }
    public static void setBtnState(Activity activity,SubmitButton button,boolean flag){
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.doResult(flag);
            }
        });
    }
    public static void resetBtn(Activity activity,SubmitButton button,long delay){
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        button.reset();
                    }
                });
            }
        };
        Timer timer = new Timer();
        timer.schedule(task,delay);
    }
    public static void showCustomMessageDialog(AppCompatActivity activity,String  title,String message){
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                MessageDialog.show(activity,title,message,"确定");
            }
        });
    }
    public static void showCustomTipDialog(AppCompatActivity activity, String message, TipDialog.TYPE type){
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TipDialog.show(activity, message, type);
            }
        });
    }
}

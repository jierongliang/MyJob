package com.ljr.travel.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.amap.api.maps.model.LatLng;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.ljr.travel.Adapter.FruitAdapter;
import com.ljr.travel.Adapter.SceneAdapter;
import com.ljr.travel.Bean.Fruit;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.REditText;
import com.ruffian.library.widget.RImageView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class SceneActivity extends AppCompatActivity {
    @BindView(R.id.search_text)
    REditText searchText;
    @BindView(R.id.recyclerview)
    RecyclerView recyclerview;
    @BindView(R.id.scene_locate)
    RImageView sceneLocate;
    @BindView(R.id.order_sort_spinner)
    MaterialSpinner orderSortSpinner;
    @BindView(R.id.scene_search)
    RImageView sceneSearch;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String TAG = "SceneActivity";
    private String province, district;
    private String maintag, subtag;
    private ArrayList<Scene> scenes;
    private ArrayList<Scene> showscenes;
    private SceneAdapter adapter;
    private String[] orders = new String[]{"评分优先", "评论优先", "距离优先"};
    private boolean customlocation;
    private double customlat, customlng;
    private LatLng customLatlng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scene);
        ButterKnife.bind(this);
        searchText.clearFocus();
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        initialParam();
        initial();
        initialSpinner();
    }

    private void initialSpinner() {
        orderSortSpinner.setItems(orders);
        orderSortSpinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                if (item.equals("评分优先")) {
                    Collections.sort(showscenes, new ScoreComparator());
                    adapter.notifyDataSetChanged();
                } else if (item.equals("评论优先")) {
                    Collections.sort(showscenes, new CommentComparator());
                    adapter.notifyDataSetChanged();
                } else if (item.equals("距离优先")) {
                    Collections.sort(showscenes, new DistanceComparator(customlocation,customLatlng));
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    public void initialParam() {
        this.province = sharedPreferences.getString("province", "北京");
        this.district = sharedPreferences.getString("district", "北京");
        Log.d(TAG, "initialParam: " + province + " " + district);
        this.maintag = sharedPreferences.getString("maintag", "");
        this.subtag = sharedPreferences.getString("subtag", "");
        this.customlocation = sharedPreferences.getBoolean("customlocation", false);
        this.customlat = sharedPreferences.getFloat("latitude", 39.906901f);
        this.customlng = sharedPreferences.getFloat("longitude", 116.397972f);
        this.customLatlng = new LatLng(customlat, customlng);
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.customlocation = sharedPreferences.getBoolean("customlocation", false);
        this.customlat = sharedPreferences.getFloat("latitude", 39.906901f);
        this.customlng = sharedPreferences.getFloat("longitude", 116.397972f);
        this.customLatlng = new LatLng(customlat, customlng);
        Log.d(TAG, "onResume: " + customlocation);
        Log.d(TAG, "onResume: " + customlng);
        Log.d(TAG, "onResume: " + customlat);
        adapter.setLatLng(customLatlng);
        adapter.setFlag(customlocation);
        adapter.notifyDataSetChanged();
    }

    public void initialScene() {
        HttpUtil.queryScene(App.querySceneadd, province, district, maintag, subtag, new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String result = response.body().string();
                try {
                    JSONArray array = new JSONArray(result);
                    String thumbimg, name, star, score, sceneid;
                    int commentNum;
                    double citydis, prodis, longitude, latitude;
                    Scene scene;
                    ArrayList<Scene> datas = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        thumbimg = object.getString("thumbimg");
                        name = object.getString("name");
                        star = object.getString("star");
                        score = object.getString("score");
                        commentNum = object.getInt("commentNum");
                        citydis = object.getDouble("distanceDis");
                        prodis = object.getDouble("distancePro");
                        sceneid = object.getString("sceneid");
                        String[] a = sharedPreferences.getString(sceneid, "").split("A");
                        longitude = Double.parseDouble(a[1]);
                        latitude = Double.parseDouble(a[0]);
                        scene = new Scene(name, star, score, thumbimg, commentNum, citydis, prodis, sceneid, latitude, longitude);
//                        Log.d(TAG, "onResponse: add" + sceneid + " la" + latitude + "lo" + longitude);
                        datas.add(scene);
                    }
                    Log.d(TAG, "onResponse: size" + datas.size());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            scenes.clear();
                            scenes.addAll(datas);
                            showscenes.clear();
                            showscenes.addAll(scenes);
                            Collections.sort(showscenes, new ScoreComparator());
                            adapter.notifyDataSetChanged();
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d(TAG, "onResponse: " + e.toString());
                }
            }
        });
    }

    @OnClick(R.id.scene_locate)
    public void onSceneLocateClicked() {
        Intent intent = new Intent(this, LocateActivity.class);
        startActivity(intent);
        finish();
    }

    public void initial() {
        if (scenes == null) {
            scenes = new ArrayList<>();
        }
        if (showscenes == null) {
            showscenes = new ArrayList<>();
        }
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(manager);
        initialScene();
        adapter = new SceneAdapter(showscenes, SceneActivity.this, this.customlocation, this.customLatlng);
        recyclerview.setAdapter(adapter);
    }

    //        DividerItemDecoration divider = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
//        divider.setDrawable(ContextCompat.getDrawable(this, R.drawable.custom_divider));
//        recyclerview.addItemDecoration(divider);
    @OnClick(R.id.scene_search)
    public void onSceneSearchClicked() {
        String searchtext = searchText.getText().toString().trim();
        if (searchtext.length() == 0) {
            showscenes.clear();
            showscenes.addAll(scenes);
        } else {
            String name;
            int index;
            showscenes.clear();
            for (Scene scene : scenes) {
                name = scene.getName();
                index = name.indexOf(searchtext);
                if ((name.equals(searchtext)) || (index != -1)) {
                    showscenes.add(scene);
                }
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.notifyDataSetChanged();
            }
        });
    }
}

class ScoreComparator implements Comparator<Scene> {
    @Override
    public int compare(Scene o1, Scene o2) {
        double score1 = Double.parseDouble(o1.getScore()),
                score2 = Double.parseDouble(o2.getScore());
        if (score1 < score2) {
            return 1;
        } else if (score2 < score1) {
            return -1;
        } else {
            int commentNum1 = o1.getCommentNum(), commentNum2 = o2.getCommentNum();
            int m = commentNum2 - commentNum1;
            if (m != 0) return m;
        }
        return 0;
    }
}

class CommentComparator implements Comparator<Scene> {
    @Override
    public int compare(Scene o1, Scene o2) {
        int commentNum1 = o1.getCommentNum(), commentNum2 = o2.getCommentNum();
        int m = commentNum2 - commentNum1;
        if (m != 0) return m;
        double score1 = Double.parseDouble(o1.getScore()),
                score2 = Double.parseDouble(o2.getScore());
        double minus = score2 - score1;
        if (minus != 0) return (int) minus;
        return 0;
    }
}

class DistanceComparator implements Comparator<Scene> {
    private boolean customflag;
    private LatLng location;

    public boolean isCustomflag() {
        return customflag;
    }

    public void setCustomflag(boolean customflag) {
        this.customflag = customflag;
    }

    public LatLng getLocation() {
        return location;
    }

    public void setLocation(LatLng location) {
        this.location = location;
    }

    public DistanceComparator() {
    }

    public DistanceComparator(boolean customflag, LatLng location) {
        this.customflag = customflag;
        this.location = location;
    }

    @Override
    public int compare(Scene o1, Scene o2) {
        if (customflag) {
            LatLng l1, l2;
            l1 = new LatLng(o1.getLatitude(), o1.getLongitude());
            l2 = new LatLng(o2.getLatitude(), o2.getLongitude());
            double distance1 = BaseUtil.calculateDistance(location, l1);
            double distance2 = BaseUtil.calculateDistance(location, l2);
            double minus = distance1 - distance2;
            if (minus != 0) return (int) minus;
            return 0;
        } else {
            double d1 = o1.getDistanceDis(),
                    d2 = o2.getDistanceDis();
            double minus = d1 - d2;
            if (minus != 0) return (int) minus;
            d1 = o1.getDistancePro();
            d2 = o2.getDistancePro();
            minus = d1 - d2;
            if (minus != 0) return (int) minus;
            return 0;
        }
    }
}
//    private ArrayList<Fruit> fruitList = new ArrayList<>();
//    public void ii() {
//        LinearLayoutManager manager = new LinearLayoutManager(this);
//        recyclerview.setLayoutManager(manager);
//        initFruits();
//        FruitAdapter adapter = new FruitAdapter(fruitList);
//        recyclerview.setAdapter(adapter);
//    }
//    private void initFruits() {
//        for (int i = 0; i < 2; i++) {
//            Fruit apple = new Fruit(getRandomLengthName("Apple"), R.drawable.apple_pic);
//            fruitList.add(apple);
//            Fruit banana = new Fruit(getRandomLengthName("Banana"), R.drawable.banana_pic);
//            fruitList.add(banana);
//            Fruit orange = new Fruit(getRandomLengthName("Orange"), R.drawable.orange_pic);
//            fruitList.add(orange);
//            Fruit watermelon = new Fruit(getRandomLengthName("Watermelon"), R.drawable.watermelon_pic);
//            fruitList.add(watermelon);
//            Fruit pear = new Fruit(getRandomLengthName("Pear"), R.drawable.pear_pic);
//            fruitList.add(pear);
//            Fruit grape = new Fruit(getRandomLengthName("Grape"), R.drawable.grape_pic);
//            fruitList.add(grape);
//            Fruit pineapple = new Fruit(getRandomLengthName("Pineapple"), R.drawable.pineapple_pic);
//            fruitList.add(pineapple);
//            Fruit strawberry = new Fruit(getRandomLengthName("Strawberry"), R.drawable.strawberry_pic);
//            fruitList.add(strawberry);
//            Fruit cherry = new Fruit(getRandomLengthName("Cherry"), R.drawable.cherry_pic);
//            fruitList.add(cherry);
//            Fruit mango = new Fruit(getRandomLengthName("Mango"), R.drawable.mango_pic);
//            fruitList.add(mango);
//        }
//    }
//    private String getRandomLengthName(String name) {
//        Random random = new Random();
//        int length = random.nextInt(20) + 1;
//        StringBuilder builder = new StringBuilder();
//        for (int i = 0; i < length; i++) {
//            builder.append(name);
//        }
//        backk builder.toString();
//    }
package com.ljr.travel.Bean;

import java.util.ArrayList;

public class Comment {
    private String sceneid, name, time, commenttext;
    private double score;

    private ArrayList<String> imgs;

    @Override
    public String toString() {
        return "Comment{" +
                "sceneid='" + sceneid + '\'' +
                ", name='" + name + '\'' +
                ", time='" + time + '\'' +
                ", commenttext='" + commenttext + '\'' +
                ", score=" + score +
                ", imgs=" + imgs +
                '}';
    }

    public Comment(String sceneid, String name, double score) {
        super();
        this.sceneid = sceneid;
        this.name = name;
        this.score = score;
    }

    public Comment(String sceneid, String name, String time, String commenttext, double score, ArrayList<String> imgs) {
        this.sceneid = sceneid;
        this.name = name;
        this.time = time;
        this.commenttext = commenttext;
        this.score = score;
        this.imgs = imgs;
    }

    public Comment(String name, String time, String commenttext, double score, ArrayList<String> imgs) {
        this.name = name;
        this.time = time;
        this.commenttext = commenttext;
        this.score = score;
        this.imgs = imgs;
    }

    public String getSceneid() {
        return sceneid;
    }

    public void setSceneid(String sceneid) {
        this.sceneid = sceneid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCommenttext() {
        return commenttext;
    }

    public void setCommenttext(String commenttext) {
        this.commenttext = commenttext;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public ArrayList<String> getImgs() {
        return imgs;
    }

    public void setImgs(ArrayList<String> imgs) {
        this.imgs = imgs;
    }


}

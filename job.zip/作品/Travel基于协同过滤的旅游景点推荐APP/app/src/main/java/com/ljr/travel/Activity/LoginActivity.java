package com.ljr.travel.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.kongzue.dialog.v3.TipDialog;
import com.kongzue.dialog.v3.WaitDialog;
import com.ljr.travel.MainActivity;
import com.ljr.travel.R;
import com.ljr.travel.Util.BaseUtil;
import com.ljr.travel.Util.HttpCallbackListener;
import com.ljr.travel.Util.HttpUtil;
import com.ruffian.library.widget.REditText;
import com.unstoppable.submitbuttonview.SubmitButton;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
public class LoginActivity extends AppCompatActivity {
    @BindView(R.id.login_icon1)
    ImageView loginIcon1;
    @BindView(R.id.login_username)
    REditText loginUsername;
    @BindView(R.id.login_icon2)
    ImageView loginIcon2;
    @BindView(R.id.login_password)
    REditText loginPassword;
    @BindView(R.id.login_checkbox)
    CheckBox loginCheckbox;
//    @BindView(R.id.btn_login)
//    Button btnLogin;
    @BindView(R.id.btn_register)
    Button btnRegister;
    @BindView(R.id.login_rl)
    RelativeLayout loginRl;
    private static final String TAG = "LoginActivity";
    @BindView(R.id.btn_login2)
    SubmitButton btnLogin2;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        Glide.with(this)
                .load(R.drawable.login_bg)
                .into(new SimpleTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        loginRl.setBackground(resource);
                    }
                });
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        initial();
    }
    @OnClick(R.id.login_username)
    public void onLoginUsernameClicked() {
    }
    @OnClick(R.id.login_password)
    public void onLoginPasswordClicked() {
    }
    @OnClick(R.id.login_checkbox)
    public void onLoginCheckboxClicked() {
    }
    public void initial() {
        //确定是否记住密码
        boolean isRemember = sharedPreferences.getBoolean("remember_password", false);
        if (isRemember) {
            String username = sharedPreferences.getString("username", "");
            String password = sharedPreferences.getString("password", "");
            loginUsername.setText(username);
            loginPassword.setText(password);
            loginCheckbox.setChecked(true);
        }
        //是否已经登录 如果已经登录则直接跳转至登录界面
        boolean isLogin = sharedPreferences.getBoolean("isLogin", false);
        if (isLogin) {
            Intent intent = new Intent(LoginActivity.this, MyActivity.class);
            startActivity(intent);
            finish();
        }
    }
    public boolean validateLogin(String username, String password) {
        if ((!TextUtils.isEmpty(username)) && (!TextUtils.isEmpty(password)))
            return true;
        return false;
    }
    @OnClick(R.id.btn_register)
    public void onBtnRegisterClicked() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
    @OnClick(R.id.btn_login2)
    public void onBtnLogin2Clicked() {
        final String username = loginUsername.getText().toString(),
                password = loginPassword.getText().toString();
        //如果为空 提示用户
        if (!validateLogin(username, password)) {
            BaseUtil.showCustomTipDialog(LoginActivity.this,"用户名或密码不能为空", TipDialog.TYPE.WARNING);
            btnLogin2.reset();
//            AlertDialog.Builder dialog = new AlertDialog.Builder(LoginActivity.this);
//            dialog.setTitle("提示")
//                    .setMessage("用户名或密码不能为空")
//                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            btnLogin2.reset();
//                        }
//                    });
//            dialog.show();
            return;
        }
        WaitDialog.show(LoginActivity.this, "登录中...请等待");
        //否则 登录
        HttpUtil.login(App.loginadd, new HttpCallbackListener() {
            @Override
            public void onFinish(String response) {
                //用户名密码正确
                if (response.equals("success")) {
                    BaseUtil.showCustomTipDialog(LoginActivity.this,"登录成功", TipDialog.TYPE.SUCCESS);
                    Intent intent = new Intent(LoginActivity.this, MyActivity.class);
                    editor = sharedPreferences.edit();
                    editor.putBoolean("isLogin", true);
                    editor.putString("username", username);
                    editor.putString("province", "北京");
                    editor.putString("district", "北京");
                    editor.apply();
                    //根据是否记住账号密码
                    if (loginCheckbox.isChecked()) {
                        editor.putBoolean("remember_password", true);
                        editor.putString("password", password);
                    } else {
                        editor.putBoolean("remember_password", false);
                        editor.putString("password", "");
                    }
                    editor.apply();
                    startActivity(intent);
                    finish();
                }
                //用户名密码不正确
                else if (response.equals("fail")) {
                    BaseUtil.setBtnState(LoginActivity.this, btnLogin2, false);
                    BaseUtil.showCustomTipDialog(LoginActivity.this,"登录失败", TipDialog.TYPE.ERROR);
                    BaseUtil.resetBtn(LoginActivity.this, btnLogin2, 2000);
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            AlertDialog.Builder dialog = new AlertDialog.Builder(LoginActivity.this);
//                            dialog.setTitle("提示")
//                                    .setMessage("用户名或密码错误")
//                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                            btnLogin2.reset();
//                                        }
//                                    });
//                            dialog.show();
//                        }
//                    });
                }
            }
            @Override
            public void onError(Exception e) {
                Log.d(TAG, "onError: " + e.getMessage());
                BaseUtil.setBtnState(LoginActivity.this, btnLogin2, false);
                BaseUtil.showCustomTipDialog(LoginActivity.this,"登录失败", TipDialog.TYPE.ERROR);
                BaseUtil.resetBtn(LoginActivity.this, btnLogin2, 2000);
            }
        }, username, password);
    }
//    @OnClick(R.id.btn_login)
//    public void onBtnLoginClicked() {
//        final String username = loginUsername.getText().toString(),
//                password = loginPassword.getText().toString();
//        //如果为空 提示用户
//        if (!validateLogin(username, password)) {
//            AlertDialog.Builder dialog = new AlertDialog.Builder(LoginActivity.this);
//            dialog.setTitle("提示")
//                    .setMessage("用户名或密码不能为空")
//                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                        }
//                    });
//            dialog.show();
//            backk;
//        }
//        //否则 登录
//        HttpUtil.login(App.loginadd, new HttpCallbackListener() {
//            @Override
//            public void onFinish(String response) {
//                //用户名密码正确
//                if (response.equals("success")) {
//                    Intent intent = new Intent(LoginActivity.this, MyActivity.class);
//                    editor = sharedPreferences.edit();
//                    editor.putBoolean("isLogin", true);
//                    editor.putString("username", username);
//
//                    editor.putString("province", "北京");
//                    editor.putString("district", "北京");
//                    editor.apply();
//                    //根据是否记住账号密码
//                    if (loginCheckbox.isChecked()) {
//                        editor.putBoolean("remember_password", true);
//                        editor.putString("password", password);
//                    } else {
//                        editor.putBoolean("remember_password", false);
//                        editor.putString("password", "");
//                    }
//                    editor.apply();
//                    startActivity(intent);
//                    finish();
//                }
//                //用户名密码不正确
//                else if (response.equals("fail")) {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            AlertDialog.Builder dialog = new AlertDialog.Builder(LoginActivity.this);
//                            dialog.setTitle("提示")
//                                    .setMessage("用户名或密码错误")
//                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                        }
//                                    });
//                            dialog.show();
//                        }
//                    });
//                }
//            }
//
//            @Override
//            public void onError(Exception e) {
//                Log.d(TAG, "onError: " + e.getMessage());
//            }
//        }, username, password);
//    }
}

package com.ljr.travel.Activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.ljr.travel.Bean.Scene;
import com.ljr.travel.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import lib.kingja.switchbutton.SwitchMultiButton;

public class MyLikeActivity extends AppCompatActivity {


    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private List<String> likescenesid,dislikescenesid;

    private List<Scene> likescenes,dislikescenes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_like);
        ButterKnife.bind(this);
        init();
        initBtn();
    }

    private void init() {
        sharedPreferences = getSharedPreferences("Travel", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        String temp;
        temp = sharedPreferences.getString("likescenes", "[]");
        likescenesid = JSON.parseArray(temp, String.class);
        temp = sharedPreferences.getString("dislikescenes", "[]");
        dislikescenesid = JSON.parseArray(temp, String.class);
        if (likescenes == null) {
            likescenes = new ArrayList<>();
        }
        if (dislikescenes == null) {
            dislikescenes = new ArrayList<>();
        }
    }

    private void initBtn() {

    }
}

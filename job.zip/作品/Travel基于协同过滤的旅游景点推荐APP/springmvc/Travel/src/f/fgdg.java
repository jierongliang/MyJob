package f;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import org.json.JSONObject;
//import com.alibaba.fastjson.JSONObject;
import a.DatabaseUtil;
import a.PredictScoreComparator;
import a.Scene;
public class fgdg {
	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private  static String selectStr = "select * from user where username = 'iu' ";
	private static PreparedStatement select;
	public static void main(String[] args) {
		try {
			select = connection.prepareStatement(selectStr);
			ResultSet set = select.executeQuery();
			TreeMap<Double, String> scoremap = new TreeMap<>(new Comparator<Double>() {
				@Override
				public int compare(Double o1, Double o2) {
					// TODO �Զ����ɵķ������
					double d = o1-o2;
					if (d<0) {
						return 1;
					}
					else if (d>0) {
						return -1;
					}
					return 0;
				}
			});
			ArrayList<Scene> scenes = new ArrayList<>();
			Scene scene;
			if (set.next()) {
				String userrec = set.getString("itemrec");
//				JSONObject object = JSONObject.parseObject(userrec);
				JSONObject object = new JSONObject(userrec);
				for (String string : object.keySet()) {
					scene = new Scene(string,object.getDouble(string));
					scenes.add(scene);
//					System.out.println(string+" "+object.getDouble(string));
//					scoremap.put( object.getDouble(string),string);
				}
			}
			ArrayList<String> sceneids = new ArrayList<>();
			Collections.sort(scenes,new PredictScoreComparator());
			for (int i = 0; i < scenes.size(); i++) {
				scene = scenes.get(i);
				System.out.println(scene.getSceneid()+ " "+scene.getPredictscore());
				sceneids.add(scene.getSceneid());
			}
			File file = new File("g:/aaa.txt");
			FileWriter writer = new FileWriter(file);
			PrintWriter writer2 = new PrintWriter(writer);
			for (String string : sceneids) {
				writer2.print(" '"+string+ "', ");
				
			}
			writer2.flush();
			writer.close();
//			for (Double double1 : scoremap.keySet()) {
//				System.out.print(double1 + " "+ scoremap.get(double1));
//			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}

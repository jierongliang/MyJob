package f;

import java.util.ArrayList;

import org.json.JSONArray;

public class ghfh {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
			ArrayList<String> nArrayList = new ArrayList<>();
			JSONArray array = new JSONArray(nArrayList);
			System.out.println(array.toString());
			String aString = "[]";
			JSONArray array2 = new JSONArray(aString);
			System.out.println(array2.length());
	}

}

package dao;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import model.Scene100;
@Repository("scenedao")
public class SceneDao  implements Scene100Mapper{
	@Resource(name = "sqlSession")
	private SqlSession session;
	@Override
	public int deleteByPrimaryKey(String name, String cityname) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(Scene100 record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Scene100 selectByPrimaryKey(String name, String cityname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Scene100> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(Scene100 record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Scene100> selectItem(List<String> ids) {
		// TODO Auto-generated method stub
		return session.selectList("dao.Scene100Mapper.selectItem",ids);
	}

	@Override
	public List<Scene100> query(Map<String, String> param) {
		// TODO Auto-generated method stub
		return session.selectList("dao.Scene100Mapper.query",param);
	}

	@Override
	public Scene100 selectByID(String sceneid) {
		// TODO Auto-generated method stub
		return session.selectOne("dao.Scene100Mapper.selectByID",sceneid);
	}

}

package controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import dao.CityCentersDao;
import dao.CommentDao;
import model.Citycenters;

@RestController
public class CityController {
	@Resource(name="citydao")
	private CityCentersDao citydao;
	@GetMapping("/template1")
	public String function1() {
		return "";
	}
	@GetMapping("/ChangeDistrict")
	public List<String> changeDistrict(String provincename) {
		Citycenters citycenters = new Citycenters();
		citycenters.setProvincename(provincename);
		List<Citycenters> citycenters2 = citydao.select(citycenters);
		ArrayList<String> ans = new ArrayList<String>();
		for (Citycenters citycenters3 : citycenters2) {
			ans.add(citycenters3.getName());
		}
		return ans;
	}
}

package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import dao.CommentDao;
import dao.SceneDao;
import model.Scene100;

@RestController
public class SceneController {
	@Resource(name="scenedao")
	private SceneDao scenedao;
	@GetMapping("/template1")
	public String function1() {
		return "";
	}
	@GetMapping("/QueryScene")
	public List<Scene100> queryScene(String province,
			String district,
			String maintag,
			String subtag) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("district", district);
		param.put("subtag", subtag);
		param.put("maintag", maintag);
		param.put("province", province);
		return scenedao.query(param );
	}
	
	@GetMapping("/SceneDetail")
	public Scene100 sceneDetail(String sceneid) {
		
		return scenedao.selectByID(sceneid);
	}

	
	
}

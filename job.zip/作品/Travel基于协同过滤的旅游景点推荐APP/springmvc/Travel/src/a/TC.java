package a;

public class TC {
	private String name,sceneid,tags,cityname,provincename,address;

	public TC(String name, String tags, String cityname, String provincename, String address) {
		super();
		this.name = name;
		this.tags = tags;
		this.cityname = cityname;
		this.provincename = provincename;
		this.address = address;
	}

	public TC(String name, String sceneid, String tags, String cityname, String provincename, String address) {
		super();
		this.name = name;
		this.sceneid = sceneid;
		this.tags = tags;
		this.cityname = cityname;
		this.provincename = provincename;
		this.address = address;
	}

	public TC() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSceneid() {
		return sceneid;
	}

	public void setSceneid(String sceneid) {
		this.sceneid = sceneid;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getProvincename() {
		return provincename;
	}

	public void setProvincename(String provincename) {
		this.provincename = provincename;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
}

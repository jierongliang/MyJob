package a;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

/**
 * Servlet implementation class SceneComment
 */
@WebServlet("/SceneComment")
public class SceneComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SceneComment() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static Connection connection;
   	static {
   		connection = DatabaseUtil.getDBConnection();
   	}
   	private String selectStr = "select * from comment where sceneid = ?";
   			
   	private PreparedStatement select;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String sceneid = request.getParameter("sceneid");
		try {
			select = connection.prepareStatement(selectStr);
			select.setString(1, sceneid);
			ResultSet set = select.executeQuery();
			ArrayList<Comment> comments = new ArrayList<>();
			String name,commenttext,time,imgs;
			double score;
			Comment comment;
			while (set.next()) {
				name = set.getString("name");
				commenttext = set.getString("commenttext");
				time = set.getString("time");
				imgs = set.getString("imgs");
				System.out.println("ljrimg"+imgs);
				score = set.getDouble("score");
				comment = new Comment(name, time, commenttext, score, imgs);
				System.out.println(comment.getImgs());
				comments.add(comment);
			}
			PrintWriter writer = response.getWriter();
			JSONArray array = new JSONArray(comments);
			writer.write(array.toString());
			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

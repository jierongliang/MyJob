package a;

public class UC {
	private String name,address,score,thumbimg,province;
	private int commentNum;
	private double citydis,prodis;


	public String getThumbimg() {
		return thumbimg;
	}

	public void setThumbimg(String thumbimg) {
		this.thumbimg = thumbimg;
	}

	public UC(String name, String address, String score, String thumbimg, String provincename, int commentNum,
			double citydis, double prodis) {
		super();
		this.name = name;
		this.address = address;
		this.score = score;
		this.thumbimg = thumbimg;
		this.province = provincename;
		this.commentNum = commentNum;
		this.citydis = citydis;
		this.prodis = prodis;
	}

	public UC(String name, String address, String score, int commentNum, double citydis, double prodis) {
		super();
		this.name = name;
		this.address = address;
		this.score = score;
		this.commentNum = commentNum;
		this.citydis = citydis;
		this.prodis = prodis;
	}

	public UC(String name, String address, String score, String thumbimg, int commentNum, double citydis,
			double prodis) {
		super();
		this.name = name;
		this.address = address;
		this.score = score;
		this.thumbimg = thumbimg;
		this.commentNum = commentNum;
		this.citydis = citydis;
		this.prodis = prodis;
	}

	public int getCommentNum() {
		return commentNum;
	}

	public void setCommentNum(int commentNum) {
		this.commentNum = commentNum;
	}

	public double getCitydis() {
		return citydis;
	}

	public void setCitydis(double citydis) {
		this.citydis = citydis;
	}

	public double getProdis() {
		return prodis;
	}

	public void setProdis(double prodis) {
		this.prodis = prodis;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	
	

	
	public UC() {
		super();
	}
	
}

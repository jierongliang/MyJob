package a;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;

/**
 * Servlet implementation class QueryScene
 */
@WebServlet("/QueryScene")
public class QueryScene extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QueryScene() {
		super();
		// TODO Auto-generated constructor stub
	}

	private static Connection connection;
	static {
		connection = DatabaseUtil.getDBConnection();
	}
	private String selectStr = "SELECT a.`sceneid`,a.`name`,a.`thumbimg`,a.`tags`,"
			+ "a.`commentNum`,a.`score`,a.`star`" + ",b.`provincedis`,b.`citydis`,b.`latitude`,b.`longitude` "
			+ "FROM scene100 AS a,scenecenter AS b" + "WHERE a.`sceneid` = b.`sceneid` AND a.`cityname` = ? "
			+ "AND a.`provincename` = ? AND a.`tags` IS NOT NULL  ",
			selectStr2 = "SELECT a.`sceneid`,a.`hotrank`,a.`name`,"
					+ "a.`thumbimg`,a.`tags`,a.`commentNum`,a.`score`,a.`star`,"
					+ "b.`provincedis`,b.`citydis`   FROM scene100 AS a,scenecenter AS b"
					+ "WHERE a.`sceneid` = b.`sceneid`  AND a.`provincename` = ? " + " AND a.`tags` IS NOT NULL",
			selectStr3 = "SELECT * FROM scenecenter,scene100\r\n" + "WHERE scenecenter.`sceneid`=scene100.`sceneid` "
					+ "AND scene100.`provincename`=?   \r\n" + "AND scene100.`cityname` = ? ",
			selectStr4 = "SELECT * FROM scenecenter,scene100\r\n" + "WHERE scenecenter.`sceneid`=scene100.`sceneid` "
					+ "AND scene100.`provincename`=? ";
	private PreparedStatement select;

	public static boolean containTags(String scenetags, ArrayList<String> contains) {
		JSONArray array = new JSONArray(scenetags);
		ArrayList<String> source = new ArrayList<>();
		for (int i = 0; i < array.length(); i++) {
			String temp = array.getString(i);
			source.add(temp);
		}
		for (String string : contains) {
			if (source.contains(string))
				return true;
		}
		return false;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String province = request.getParameter("province");
		String city = request.getParameter("district");
		String maintag = request.getParameter("maintag");
		String subtag = request.getParameter("subtag");
		System.out.println(province+city+maintag+subtag);
		ArrayList<String> tags = new ArrayList<>();
		if (!maintag.equals("")) {
			String[] temp = maintag.split("&");
			for (String string : temp) {
				tags.add(string);
			}
		}
		if (!subtag.equals("")) {
			tags.add(subtag);
		}
		if (city == null && city.length() == 0)
			return;
		try {
			if (!city.equals("全省")) {
				// select = connection.prepareStatement(selectStr);
				select = connection.prepareStatement(selectStr3);
				select.setString(1, city);
				select.setString(2, province);
			} else {
				// select = connection.prepareStatement(selectStr2);
				select = connection.prepareStatement(selectStr4);
				select.setString(1, province);
			}
			ResultSet set = select.executeQuery();
			String thumbimg, name, star, score;
			double latitude;
			String longitude;
			int commentNum;
			double citydis, prodis;
			Scene scene;
			String scenetags;
			String sceneid;
			ArrayList<Scene> scenes = new ArrayList<>();
			while (set.next()) {
				scenetags = set.getString("tags");
				if ((tags.size() > 0) && !containTags(scenetags, tags))
					continue;
				thumbimg = set.getString("thumbimg");
				name = set.getString("name");
				star = set.getString("star");
				score = set.getString("score");
				sceneid = set.getString("sceneid");

				commentNum = Integer.parseInt(set.getString("commentNum"));
				citydis = Double.parseDouble(set.getString("citydis"));
				prodis = Double.parseDouble(set.getString("provincedis"));
				scene = new Scene(name, star, score, thumbimg, commentNum, citydis, prodis, sceneid);
				scenes.add(scene);
			}
			System.out.println("length" + scenes.size());
			JSONArray array = new JSONArray(scenes);
			PrintWriter writer = response.getWriter();
			writer.write(array.toString());
			writer.flush();
			writer.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

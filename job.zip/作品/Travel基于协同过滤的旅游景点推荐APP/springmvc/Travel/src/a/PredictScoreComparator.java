package a;

import java.util.Comparator;

public class PredictScoreComparator implements Comparator<Scene>{

    @Override
    public int compare(Scene o1, Scene o2) {
        double score1 = o1.getPredictscore(),
                score2 = o2.getPredictscore();

        if (score1<score2) {
            return 1;
        }
        else if (score2<score1) {
            return -1;
        }
        return 0;
    }
}
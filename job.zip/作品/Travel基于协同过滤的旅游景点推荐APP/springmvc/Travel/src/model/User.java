package model;

public class User {
    private String username;

    private String password;

    private String phonenumber;

    private String userrec;

    private String itemrec;

    private String sloperec;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber == null ? null : phonenumber.trim();
    }

    public String getUserrec() {
        return userrec;
    }

    public void setUserrec(String userrec) {
        this.userrec = userrec == null ? null : userrec.trim();
    }

    public String getItemrec() {
        return itemrec;
    }

    public void setItemrec(String itemrec) {
        this.itemrec = itemrec == null ? null : itemrec.trim();
    }

    public String getSloperec() {
        return sloperec;
    }

    public void setSloperec(String sloperec) {
        this.sloperec = sloperec == null ? null : sloperec.trim();
    }
}